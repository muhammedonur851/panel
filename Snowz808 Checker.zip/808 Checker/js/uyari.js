// SweetAlert uyarısı fonksiyonu
function showSweetAlert() {
    Swal.fire({
        title: 'Hatırlatma!',
        text: 'Günde 2 kez bu sayfayı ziyaret etmeyi unutma! Telegram kanalımıza katılmayı unutma!',
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Telegram Kanalına Katıl',
        cancelButtonText: 'Kapat',
    }).then((result) => {
        if (result.isConfirmed) {
            // Telegram kanalına yönlendirme veya diğer işlemler burada yapılabilir
            window.location.href = 'https://t.me/kanal_adresiniz';
        }
    });
}

// Uyarı saatleri
const notificationTimes = ['00:58', '18:00'];

// Sayfa yüklendiğinde kontrolü gerçekleştir
document.addEventListener('DOMContentLoaded', function () {
    checkNotification();
});

// Uyarı kontrolü
function checkNotification() {
    const currentTime = new Date();
    const currentHour = currentTime.getHours();
    const currentMinute = currentTime.getMinutes();

    const currentTimeString = `${currentHour}:${currentMinute < 10 ? '0' + currentMinute : currentMinute}`;

    // Eğer şu anki zaman uyarı saatlerinden biriyse uyarıyı göster
    if (notificationTimes.includes(currentTimeString)) {
        showSweetAlert();
    }
}
