<!-- CODED BY BOZO808 -->   <!-- NE ARIYON BURDA EŞŞEK -->
<?php
require 'server/connect.php';
ini_set("display_errors", 0);
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $db);

// Bağlantı hatası kontrolü
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$panel_query = $conn->query("SELECT panel_name FROM settings");
$panel_name = $panel_query->fetch(PDO::FETCH_ASSOC)['panel_name'];

$social_query = $conn->query("SELECT social_link FROM settings");
$social_link = $social_query->fetch(PDO::FETCH_ASSOC)['social_link'];

$social_kısa = $conn->query("SELECT social_kısa FROM settings");
$socialkısa = $social_kısa->fetch(PDO::FETCH_ASSOC)['social_kısa'];

$yetkili_query = $conn->query("SELECT yetkili FROM settings");
$yetkili = $yetkili_query->fetch(PDO::FETCH_ASSOC)['yetkili'];

$yetkiliurl_query = $conn->query("SELECT yetkili_tg FROM settings");
$yetkili_tg = $yetkiliurl_query->fetch(PDO::FETCH_ASSOC)['yetkili_tg'];
?>
<!doctype html>
<html lang="en" dir="ltr">
	
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>  
    
<meta name="robots" content="noindex">
		<!-- META DATA -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="LOGİN!">

                <!-- FAVICON -->
        <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
 <!-- Google Recaptcha -->
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <!-- TITLE -->
        <title>---</title>

        <!-- BOOTSTRAP CSS -->
        <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

        <!-- STYLE CSS -->
        <link href="assets/css/style.css" rel="stylesheet"/>
        <link href="assets/css/skin-modes.css" rel="stylesheet"/>
        <link href="assets/css/dark-style.css" rel="stylesheet"/>

        <!-- SINGLE-PAGE CSS -->
	<link href="assets/plugins/single-page/css/main.css" rel="stylesheet" type="text/css">

        <!-- P-scroll bar css-->
        <link href="assets/plugins/p-scroll/perfect-scrollbar.css" rel="stylesheet" />

        <!--- FONT-ICONS CSS -->
        <link href="assets/css/icons.css" rel="stylesheet"/>

        
		
        <!-- COLOR SKIN CSS -->
        <link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/colors/color1.css" />

        <!-- SWITCHER SKIN CSS -->
        <link href="assets/switcher/css/switcher.css" rel="stylesheet">
        <link href="assets/switcher/demo.css" rel="stylesheet">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />

    </head>

	<body class="login-img dark-mode">

		<!-- /GLOABAL LOADER -->

			
				<!-- PAGE -->
				<div class="page"style="background-color: black;">
					<div class="">
						<!-- CONTAINER OPEN -->
						<div class="col col-login mx-auto">
						</div>
						<div class="container-login100">
							<div class="wrap-login100 p-6"style="background-color: #1C2833; box-shadow: 0 0 30px rgba(0, 206, 209, 0.5); margin: 10px;"
>
								<div class="login100-form validate-form">
									<center>
									<img src="img/logo.png" style="width: 150px;">
									<br><br>
                                     </center>
									<span class="login100-form-title">
                              <strong>  <?php echo $panel_name ?>
							</strong>		</span>
									<div class="wrap-input100 validate-input">
										<input class="input100" type="text" name="user" style="background-color: #2A3C4D;" placeholder="Kullanıcı Adı">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fe fe-user" aria-hidden="true"></i>
										</span>
									</div>
									<div class="wrap-input100 validate-input">
										<input class="input100" type="password" name="pass" style="background-color: #2A3C4D;"  placeholder="Şifre">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fe fe-lock" aria-hidden="true"></i>
										</span>
									</div>
                                    <style>
                                    .g-recaptcha {
    transform:scale(0.90);
    transform-origin:1 10;
}
</style>
									<div class="g-recaptcha" data-sitekey="6LcX-YMqAAAAAErc-Y9dU5OoOU5x_0v7EyQPoHiD"></div>

									
									<div class="container-login100-form-btn">
										<button type="submit" id="btnSentinel" class="login100-form-btn btn-primary">
                                        <i class="fa fa-sign-in"></i>&nbsp;Giriş Yap
                                     </button>
									</div>
									<div class="text-center pt-3">
										<p class="text-dark mb-0">Telegram kanalımıza gelmeyi unutmayın.<a href="<?php echo $social_link ?>" class="text-primary ms-1"> 
										<?php echo $socialkısa; ?></a></p>
									</div>
							</div>
						</div>
					
					</div>
				</div>
          <script type="text/javascript">
    $('#btnSentinel').click(function(){

        var keyad = $("[name=user]").val();
        var key = $("[name=pass]").val();
        var recaptchaResponse = grecaptcha.getResponse(); 

        if (key == "" && keyad == "") {

            Swal.fire ({
                icon : "error",
                title : "Oopss...",
                text : "Kullanıcı Adı Ve Şifre Boş Bırakılamaz!",
                footer: '	<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a>	</center>',
                showConfirmButton: false,
                timer: 1500
            })
            
        } else if (recaptchaResponse == "") {
            Swal.fire ({
                icon : "error",
                title : "Lütfen Doğrulamayı Yapın",
                text : "Ben robot değilim doğrulamasını yapın!",
                footer: '	<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a>	</center>',
                showConfirmButton: false,
                timer: 1500
            })
        } else {
            $.ajax({
                type : "POST",
                url : "api/login/api.php",
                data : {
                    keyad: keyad,
                    key: key,
                    "g-recaptcha-response": recaptchaResponse 
                },
                success : function(data){
                    var json = data;
                    if (json.status === "false" && json.error === "deleted") {
                        Swal.fire({
                            icon : "error",
                            title : "Oopss...",
                            text : "Üyeliğiniz silinmiştir. Eğer herhangi bir hata yapmadığınızı düşünüyorsanız satın aldığınız admin ile iletişime geçiniz.",
                            footer: '<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a><center>',
                            confirmButtonText: 'Tamam'
                        });
                    } else if (json.login === "success") {
                        Swal.fire({
                            position: 'center',
                            icon : "success",
                            title : ' <?php echo $panel_name ?>',
                            text: 'Giriş Başarılı Yönlendiriliyorsunuz...',
                            footer: '<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a></center>',
                            showConfirmButton: false,
                            timer: 1000
                        })
                        window.setTimeout(function() {
                            window.location.href = '/check.js';
                        }, 1000);
                    }
                    if (json.error === "banned") {

                        Swal.fire({
                            icon : "error",
                            title : "Oopss...",
                            text : "Banlandınız! Banlanma Sebebi : Birden fazla ip'den giriş. Yönetici ile iletişime geçiniz.",
                            footer: '<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a><center>',
                            confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.error === "deleted") {

                        Swal.fire({
                            icon : "error",
                            title : "Oopss...",
                            text : "Üyeliğiniz silinmiştir. Eğer herhangi bir hata yapmadığınızı düşünüyorsanız satın aldığınız admin ile iletişime geçiniz.",
                            footer: '<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a><center>',
                            confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.error === "endkey") {

                        Swal.fire({
                            icon : "error",
                            title : "Oopss...",
                            text : "Üyeliğinizin Süresi Bitmiştir Tekrar Satın Almak İçin Lütfen Yöneticiye Başvurunuz !",
                            footer: '<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a></center>',
                            confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.login === "error") {

                        Swal.fire({
                            icon : "error",
                            title : "Oopss...",
                            text : "Kullanıcı Bulunamadı Lütfen Kullanıcı Adını ve Şifreni Kontrol Et...",
                            footer: '<center><a href="<?php echo $social_link; ?>">Şifreni mi Unuttun ?</a></center>',
                            confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.error === "recaptcha") { 
                        Swal.fire({
                            icon : "error",
                            title : "reCAPTCHA Doğrulaması Başarısız",
                            text : "Sayfayı yenileyip robot değilim doğrulamasını tekrar yapın.",
                            footer: '<center><a href="<?php echo $social_link; ?>"><?php echo $socialkısa; ?></a></center>',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                }
            });
        }
    });
</script>

  
</div>
</div>
</div>

<center>
  <footer class="footer"style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
  Copyright © 2024   <a href="<?php echo $social_link; ?>"><strong><?php echo $panel_name ?>er</strong><br></a> Developed by <a href="<?php echo $yetkili_tg ?>"> <strong><?php echo $yetkili ?>&nbsp;<i class="fa fa-code" aria-hidden="true"></i></strong></a>
</footer></center>
</div>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

			
        <script src="assets/js/jquery.min.js"></script>

        <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

        <script src="assets/plugins/rating/jquery.rating-stars.js"></script>
        <script src="assets/plugins/input-mask/jquery.mask.min.js"></script>
        <script src="assets/plugins/p-scroll/perfect-scrollbar.js"></script>
        <script src="assets/switcher/js/switcher.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>

<script>
    // Sağ tıklama olayını yakalama
    window.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        alert("Login secure var klavyeni kullan ");
    });
	
</script>
<script>
    // Klavyeden kısayol tuşlarını yakalama
    window.addEventListener('keydown', function(e) {
        // Klavyeden F12 tuşuna basılırsa
        if (e.keyCode == 123) {
            e.preventDefault(); // Tuşun varsayılan işlevini engelle
        }
    });
</script>
<script type="text/javascript">
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.onkeydown = function(e) {
    if (e.keyCode == 123) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
}
</script>
<script id="Protection">
    // Sağ tıklama engelle
    document.addEventListener('contextmenu', event => event.preventDefault());

    document.onkeydown = function(e) {

        // F12 Engelle
        if (e.keyCode == 123) {
            return false;
        }

        // CTRL+I Engelle
        if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
            return false;
        }

        // CTRL+J Engelle
        if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
            return false;
        }

        // CTRL+S Engelle
        if (e.ctrlKey && e.keyCode == 83) {
            return false;
        }

        // CTRL+U Engelle
        if (e.ctrlKey && e.keyCode == 85) {
            return false;
        }
    }
</script>
