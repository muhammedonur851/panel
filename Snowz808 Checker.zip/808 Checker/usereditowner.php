<?php
$page_title = 'OWNER Kullanıcı Düzenle ';
include("inc/sidebar.php");
include("server/owner.php");
$url_query = $conn->query("SELECT url FROM settings");
$urls = $url_query->fetch(PDO::FETCH_ASSOC)['url'];
if ($sentinel['role'] == 1) {

    if (isset($_POST['gonder'])) {

        $keyad = $_POST['key_ad'];
        $kkey = $_POST['key_pas'];
        $bitistarih = $_POST['enddate'];
        $multi = $_POST['ipadres'];
        $guvenli = 1;
        $role = $_POST['role'];
        $id = htmlspecialchars($_GET['id']);

 
        $checkUsername = $conn->prepare("SELECT id FROM users WHERE key_ad = ? AND id != ?");
        $checkUsername->execute([$keyad, $id]);
        $existingUser = $checkUsername->fetch(PDO::FETCH_ASSOC);


        $checkPassword = $conn->prepare("SELECT id FROM users WHERE key_pas = ? AND id != ?");
        $checkPassword->execute([$kkey, $id]);
        $existingPassword = $checkPassword->fetch(PDO::FETCH_ASSOC);


        if (strlen($kkey) < 6) {
            $message = "<div class='alert alert-danger'>Hata : Şifre en az 6 karakter uzunluğunda olmalıdır!</div>";
        } elseif (strlen($keyad) > 15) {
            $message = "<div class='alert alert-danger'>Hata : Kullanıcı adı 15 karakterden uzun olamaz!</div>";
        } elseif ($existingUser) {
            $message = "<div class='alert alert-danger'>Hata : Bu kullanıcı adı zaten kullanımda, lütfen başka bir kullanıcı adı seçin!</div>";
        } elseif ($existingPassword) {
            $message = "<div class='alert alert-danger'>Hata : Lütfen başka bir şifre seçin!</div>";
        } else {
     
            if ($bitistarih !== '0' && !preg_match("/^\d{2}\.\d{2}.\d{4}$/", $bitistarih)) {
                $message = "<div class='alert alert-danger'>Hata : Geçerli bir tarih formatı girin (örn: 01.01.2023) sınırsız için 0 yazın!</div>";
            } elseif ($bitistarih !== '0' && strtotime($bitistarih) <= strtotime(date('d.m.Y'))) {
                $message = "<div class='alert alert-danger'>Hata : Geçerli bir tarih girin (bugünden ileri bir tarih) sınırsız için 0 yazın!</div>";
            } else {
           
                $guncelle = $conn->prepare("UPDATE users SET key_ad='$keyad',key_pas='$kkey',role='$role',enddate='$bitistarih',ipadres='$multi',security='$guvenli',endkey='0',owner='0',banned='0' WHERE id='$id'");
                $guncelle->execute();

                $message = "<div class='alert alert-primary'>Bilgilendirme : Başarılı Kullanıcı Düzenlendi !  <br> Kullanıcı Adı : " . $keyad . " <br> Kullanıcı Şifresi : " . $kkey . " <br> Bitiş Tarihi : " . $bitistarih . " <br> Url: $urls <br> Uyarı! Üyeliğinizi başkasıyla paylaşmayın ban yersiniz.</div>";
            }
        }
    }
}

$sql = "SELECT * from users WHERE id = ?";
$sentinel = $conn->prepare($sql);
$sentinel->execute([$_GET['id']]);
$satir = $sentinel->fetch(PDO::FETCH_ASSOC);
?>








                   <div class="row">
                            <div class="col-12">
                                <div class="card"style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                                    <div class="card-body">
        
                      <form method="POST">
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-name">Kullanıcı Adı</label>
                          <div class="col-sm-10">
                            <input type="text"style="background-color: #2A3C4D;" class="form-control" name="key_ad" id="basic-default-name" placeholder="" value="<?=$satir['key_ad']?>">
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Kullanıcı Şifresi</label>
                          <div class="col-sm-10">
                            <input type="text"style="background-color: #2A3C4D;" class="form-control" name="key_pas" id="basic-default-company" placeholder="" value="<?=$satir['key_pas']?>">
                          </div>
                        </div>
                         <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Bitiş Tarihi</label>
                          <div class="col-sm-10">
                            <input type="text" style="background-color: #2A3C4D;"class="form-control" name="enddate"  id="basic-default-company" placeholder="" value="<?=$satir['enddate']?>">
                          </div>
                        </div>
                          </div>
                          <br><br><br>
                          <center>
                          <?php if ($satir['role'] == 2) { ?>
                            <h5 class="text-primary" style="float:left;">Üyelik Durumu : <h5 class="text-danger" style="float:left; margin-left: 5px;"> Premium</h5>
                         <?php } ?>
                       
                        <br><br>
                        <?php if ($satir['enddate'] == "0") { ?>
                            <h5 class="text-primary" style="float:left;">Sınırsız Üye Durumu : <h5 class="text-danger" style="float:left; margin-left: 5px;"> Aktif</h5>
                         <?php }else{ ?>

                           <h5 class="text-primary" style="float:left;">Sınırsız Üye Durumu : <h5 class="text-danger" style="float:left; margin-left: 5px;"> Kapalı</h5>

                        <?php } ?>


                       </center>
                        </div>
                          

                       <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio" name="role" id="exampleRadios1" value="2" >
                                                    <label class="form-check-label" for="exampleRadios1">
                                                        Premium Üye
                                                    </label>
                                                </div>
                                                
                                                 <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio" name="enddate" id="exampleRadios1" value="0" >
                                                    <label class="form-check-label" for="exampleRadios1">
                                                        Süresiz Üye
                                                    </label>
                                                </div>
                        <br>

                        <br>
                        <div class="row justify-content-end">
                          <div class="col-sm-10">
                            <button type="submit" name="gonder" style="float:right;" class="btn btn-danger">Kaydet</button>
                          </div>
                          <br><br><br>
                         <?php echo $message; ?>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                         </div>
                         </div>
                         </div>


<?php
include("inc/main_js.php");

?>

