<?php
$page_title = 'Duyurular Owner';
include("inc/sidebar.php");
include("server/owner.php");

$sql = "SELECT * FROM duyuru";
$anger = $conn->query($sql);

if ($sentinel['owner'] == 1) {

	if (isset($_GET['sil'])) {
		$sil = htmlspecialchars($_GET['sil']);
		$silsentinel = $conn->prepare("DELETE FROM duyuru WHERE id=?");
		$silsentinel->execute([
			$_GET['sil']
		]);
	
		header("Location: duyurular.js");
	}
	
}


?>

<div class="row">
							<div class="col-md-12 col-lg-12">
								<div class="card"style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
									<div class="card-header">
										<h3 class="card-title">Kullanıcılar</h3>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="example" class="table table-striped table-bordered text-nowrap w-100">
												<thead>
													<tr>
														<th class="wd-20p">Duyuru Atan</th>
                                                        <th class="wd-20p">Duyuru</th>
                                                        <th class="wd-20p">Tarih</th>
                                                        <th class="wd-20p">Duyuru Sil</th>


													</tr>
												</thead>
												<tbody>
                                               <?php while ($users = $anger->fetch(PDO::FETCH_ASSOC)) { ?>
                                                <tr>
                                            <td><?=$users['duyuruatan']?></td>
                                            <td><?=$users['atılanduyuru']?></td>
                                            <td><?=$users['tarih']?></td>
                                       <td><a href="?sil=<?=$users['id']?>" onclick="return confirm('Silinsinmi ?')" class="badge rounded-pill  bg-danger mt-2">Sil</a></td>
                                       </tr>
                                               <?php } ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
                   </div>
              </div>
<?php
include("inc/main_js.php");
?>
