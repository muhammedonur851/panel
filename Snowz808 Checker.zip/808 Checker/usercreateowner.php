<?php
$page_title = 'Kullanıcı Ekle';
include("inc/sidebar.php");
include("server/adminz.php");

$url_query = $conn->query("SELECT url FROM settings");
$urls = $url_query->fetch(PDO::FETCH_ASSOC)['url'];

date_default_timezone_set('Europe/Istanbul');

if (isset($_POST['ekle'])) {
    $created = $sentinel['key_ad'];
    $eklenentarih = date('d.m.Y H:i');
    $keyad = htmlspecialchars($_POST['keyad']);
    $kkey = htmlspecialchars($_POST['kkey']);
    $membershipDuration = htmlspecialchars($_POST['membershipDuration']); 
    $ipadres = htmlspecialchars($_POST['ipadres']);

   
    $freemiumCheckbox = isset($_POST['freemiumCheckbox']);

   
    $rolu = ($freemiumCheckbox) ? "" : 2;

    
    $tapu = (!$freemiumCheckbox && $membershipDuration === "yearly") ? 1 : "";

    $guvenli = 1; 

    
    if (strlen($keyad) > 15) {
        $message = "<div class='alert alert-danger'>Kullanıcı adı 15 karakterden uzun olamaz.</div>";
    } else {
       
        $kullanici_kontrol = $conn->prepare("SELECT * FROM users WHERE key_ad = :keyad");
        $kullanici_kontrol->bindParam(":keyad", $keyad, PDO::PARAM_STR);
        $kullanici_kontrol->execute();

        
        $password_check = $conn->prepare("SELECT * FROM users WHERE key_pas = :kkey");
        $password_check->bindParam(":kkey", $kkey, PDO::PARAM_STR);
        $password_check->execute();

        if ($kullanici_kontrol->rowCount() > 0) {
           
            $message = "<div class='alert alert-danger'>Kullanıcı adı zaten alınmış. Lütfen farklı bir kullanıcı adı seçin.</div>";
        } elseif ($keyad === $kkey) {
            
            $message = "<div class='alert alert-danger'>Kullanıcı adı ile şifre aynı olamaz. Lütfen farklı bir şifre seçin.</div>";
        } elseif ($password_check->rowCount() > 0) {
            
            $message = "<div class='alert alert-danger'>Lütfen farklı bir şifre seçin.</div>";
        } elseif (strlen($kkey) < 6) {
           
            $message = "<div class='alert alert-danger'>Lütfen 6 haneden uzun bir şifre belirleyin.</div>";
        } else {
            
            $bitis_datetime = new DateTime();
            switch ($membershipDuration) {
                case "daily":
                    $bitis_datetime->modify('+1 day');
                    break;
                case "weekly":
                    $bitis_datetime->modify('+1 week');
                    break;
                case "monthly":
                    $bitis_datetime->modify('+1 month');
                    break;
                case "quarterly":
                    $bitis_datetime->modify('+3 months');
                    break;
                case "yearly":
                    $bitis_datetime->modify('+1 year');
                    break;
            }
           $bitistarih = $bitis_datetime->format('d.m.Y');

                $sentinelekle = $conn->prepare("INSERT INTO users SET key_ad = :keyad, key_pas = :kkey, role = :rolu, createddate = :eklenentarih, enddate = :bitistarih, ipadres = :ipadres, security = :guvenli, endkey = '', owner = '', banned = '', createdadmin = :created, tapu = :tapu");
                $sentinelekle->bindParam(":keyad", $keyad, PDO::PARAM_STR);
                $sentinelekle->bindParam(":kkey", $kkey, PDO::PARAM_STR);
                $sentinelekle->bindParam(":rolu", $rolu, PDO::PARAM_STR);
                $sentinelekle->bindParam(":eklenentarih", $eklenentarih, PDO::PARAM_STR);
                $sentinelekle->bindParam(":bitistarih", $bitistarih, PDO::PARAM_STR);
                $sentinelekle->bindParam(":ipadres", $ipadres, PDO::PARAM_STR);
                $sentinelekle->bindParam(":guvenli", $guvenli, PDO::PARAM_INT);
                $sentinelekle->bindParam(":created", $created, PDO::PARAM_STR);
                $sentinelekle->bindParam(":tapu", $tapu, PDO::PARAM_STR);
                $sentinelekle->execute();

                $message = "<div class='alert alert-primary'> Kullanıcı Adı : " . $keyad . " <br>Kullanıcı Şifresi : " . $kkey . "  <br>Bitiş Tarihi : " . $bitistarih . "<br> Url: $urls<br>Uyarı! Üyeliğinizi başkasıyla paylaşmayın ban yersiniz.</div>";
            }

            
            $veri_sayisi = $conn->query("SELECT COUNT(*) FROM admin_limitor")->fetchColumn();
            if ($veri_sayisi >= 500) {
                $conn->query("DELETE FROM admin_limitor");
            }
        }
    }

?>



<div class="row">
    <div class="col-md-12">
        <div class="card" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
            <div class="card-header">
                <h3 class="mb-0 card-title">Kullanıcı Ekle</h3>
            </div>
            <div class="card-body">
              
                <form method="post">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-4">
                                <input type="text" class="form-control" name="keyad" placeholder="Kullanıcı Adı"style="background-color: #2A3C4D;" required>
                            </div>
                            <div class="mb-4">
                                <input type="text" class="form-control" name="kkey" placeholder="Şifre"style="background-color: #2A3C4D;" required>
                            </div>
                           <div class="mb-4">
    <select class="form-select" name="membershipDuration" id="membershipDuration" required>
        <option value="" disabled selected>Üyelik Türü Seçiniz</option>
        <option value="daily">Günlük Premium</option>
        <option value="weekly">Haftalık Premium</option>
        <option value="monthly">Aylık Premium</option>
        <option value="quarterly">3 Aylık Premium</option>
        <option value="yearly">Yıllık Premium</option>
    </select>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelector('form').addEventListener('submit', function (event) {
            var membershipDuration = document.getElementById('membershipDuration').value;

            if (membershipDuration === "") {
                event.preventDefault(); 
                alert('Lütfen üyelik türünü seçiniz.');
            }
        });
    });
</script>
                          
                            <label class="custom-control custom-checkbox">
        <input type="checkbox" class="custom-control-input" name="freemiumCheckbox">
        <span class="custom-control-label">Freemium Üye</span>
    </label>
                        </div>
                        <button type="submit" name="ekle" style="float: right;" class="btn btn-primary">Oluştur <i class="fa fa-plus fa-spin ms-2"></i></button>
                        <br><br>
                        <?php echo $message; ?>
                                          </div>
                                         </div>
                                        </div>
                                      </div>
                                     </div>
									</div>
								</div>
                                <script>

    window.onload = function () {
        var guvenliCheckbox = document.querySelector('input[name="guvenli"]');
        guvenliCheckbox.checked = true;
    };
</script>


<?php
include("inc/main_js.php");
?>