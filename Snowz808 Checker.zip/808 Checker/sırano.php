﻿<?php 
$page_title = 'Sıra No Sorgu';
include("inc/sidebar.php");
include("server/vipkontrol.php");
?>

<div class="row">
    <div class="col-xl">
        <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Sıra No Sorgu</h5>
                <small class="text-primary float-end">Lütfen Sorgulanacak Kişinin T.C Bilgisini Giriniz.</small>
            </div>

            <div class="card-body">
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">T.C</label>
                        <input type="text" class="form-control" name="tc" id="basic-default-fullname" placeholder="11111111110" required inputmode="numeric" maxlength="11" style="background-color: #2A3C4D;" required>
                        </div>
                      
                <button id="btnSentinel" type="submit" class="btn btn-primary"><i class="fa fa-search"></i>&nbsp;Sorgula</button>
          &nbsp;<button id="btnKopyala" class="btn btn-secondary"><i class="fa fa-copy"></i>&nbsp;Kopyala</button>
            &nbsp;<button id="btnIndir" class="btn btn-success"><i class="fa fa-download"></i>&nbsp;İndir</button>
                <br><br>
                
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered text-nowrap w-100">
                        <thead>
                            <tr>
                                           
                                            <th>Adı</th>
											<th>Soyadı</th>
                                            <th>Sıra No</th>
                            </tr>
                        </thead>
                        <tbody id="sentinelapi"></tbody>
                    </table>
                </div>
                   <script type="text/javascript">
    $("#btnIndir").click(function () {
        var element = document.getElementById('example');

        html2pdf(element, {
            margin: 10,
            filename: 'SorguSonuc_<?php echo $panel_name; ?>er.pdf',
            image: { type: 'jpeg', quality: 0.98, width: 600, height: 800 }, 
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'mm', format: 'a2', orientation: 'portrait' }
        });
    });
</script>
                 <script type="text/javascript">
   $("#btnKopyala").click(function () {
    var table = $("#example");
    var tableData = "";


    table.find('thead tr th').each(function () {
        tableData += $(this).text() + '\t';
    });
    tableData += '\n';


    table.find('tbody tr').each(function () {
        $(this).find('td').each(function () {
            tableData += $(this).text() + '\t';
        });
        tableData += '\n';
    });

    var tempTextarea = $('<textarea>');
    tempTextarea.val(tableData);
    $('body').append(tempTextarea);

    tempTextarea.select();
    document.execCommand('copy');

    tempTextarea.remove();

    Swal.fire({
        icon: "success",
        title: "Başarılı!",
        text: "Tablo kopyalandı.",
    });
});
</script>
                <script type="text/javascript">
      var lastRequestTime = 0;  

    $("#btnSentinel").click(function(){
        var currentTime = Date.now(); 
        var cooldownDuration = 5000;

        if (currentTime - lastRequestTime < cooldownDuration) {
                Swal.fire({
        icon: "warning",
        title: "Çok hızlı sorgulama yapıyorsun!",
        text: "Lütfen 5 saniye bekle.",
        showConfirmButton: false,
        timer: 5000,  
        timerProgressBar: true  
    });
    return;
}

    
        lastRequestTime = currentTime;
        var tc = $("[name=tc]").val();
      
        
        $("#sentinelapi").html('');
        
        if (tc === "" ) {
            Swal.fire({
                icon: "error",
                title: "Oopss...",
                text: "Lütfen TC bilgisi giriniz.",
                footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            });
            return;
        }

        Swal.fire({
            imageUrl: 'img/sorgulaniyor.gif',
            imageHeight: 100,
            title: 'Sorgu Çözümü Başladı !',
            text: 'Sorgulanıyor...',
            footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            showConfirmButton: false,
        });

        $.ajax({
            type: 'POST',
            url: 'api/tc/sırano.php',
            data: {tc},

            success: function(data){
                swal.close();
                var json = data;

                $("#sentinelapi").html(data);

                 if (json == false || data.includes("Veri bulunamadı.")) {
                    swal.close();
                    Swal.fire({
                        icon: "error",
                        title: "Oopss...",
                        text: "Sorguladığınız Kişiye Ait Bir Bilgi Bulunamadı.",
                        footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                    });
                } else if (data.includes("API request failed.")) {
                    swal.close();
                    Swal.fire({
                        icon: "warning",
                        title: "Bu çözüm bakımdadır!",
                        text: "Sizlere daha iyi hizmet verebilmek için sistemlerimizi daha optimize hale getiriyoruz, gün içerisinde tekrardan aktif olucaktır. Anlayışınız için teşekkürler, daha sonra tekrar deneyiniz.",
                        footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                    });
                }
            }
        });
    });
</script>
                          </div>
                      </div>
                 </div>
            </div>
       </div>
  </div>
<?php 
include("inc/main_js.php");
?>
