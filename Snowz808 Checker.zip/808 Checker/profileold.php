<?php 
$page_title = 'Profil';

include("inc/sidebar.php");
?>

<?php
$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}

// Formdan verileri al
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullaniciAdi = $_POST["kullaniciAdi"];
    $mevcutSifre = $_POST["mevcutSifre"];
    $yeniSifre = $_POST["yeniSifre"];
    
    // Hazır ifade oluştur
    $sql = "SELECT key_pas FROM users WHERE key_ad = ?";
    $stmt = $conn->prepare($sql);

    // Parametreleri bağla
    $stmt->bind_param("s", $kullaniciAdi);

    // Sorguyu çalıştır
    $stmt->execute();

    // Sonuçları al
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $veritabaniSifre = $row["key_pas"];
        
        // Mevcut şifreyi doğrula
        if ($mevcutSifre == $veritabaniSifre) {
            // Yeni şifreyi kontrol et
            $checkSql = "SELECT key_pas FROM users WHERE key_pas = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->bind_param("s", $yeniSifre);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();

            if ($checkResult->num_rows > 0) {
                echo "Bu şifre zaten kullanılıyor. Lütfen başka bir şifre seçin.";
            } else {
                // Yeni şifreyi güncelle
                $updateSql = "UPDATE users SET key_pas = ? WHERE key_ad = ?";
                $updateStmt = $conn->prepare($updateSql);
                $updateStmt->bind_param("ss", $yeniSifre, $kullaniciAdi);
                
                if ($updateStmt->execute()) {
                    echo "Şifre başarıyla değiştirildi.";
                } else {
                    echo "Şifre değiştirme işlemi başarısız: " . $conn->error;
                }
            }
        } else {
            echo "Mevcut şifre yanlış.";
        }
    } else {
        echo "Kullanıcı bulunamadı.";
    }

    // Hazır ifadeleri kapat
    $stmt->close();
    $updateStmt->close();
    $checkStmt->close();
}

$conn->close();
?>


    
                 
                  

                   	<div class="profile">
	<div class="profile-pic">
		<div class="header-color"></div>
		
		<img src="<?php echo empty($sentinel['img']) ? 'img/pp.png' : $sentinel['img']; ?>" alt="Profile Picture">
	</div>
	<div class="title">
		<h1><?=$sentinel['key_ad'];?>	<?php
if ($sentinel['owner'] == 1) {
    $image = "img/role/owner.png";
} elseif ($sentinel['role'] == 1) {
    $image = "img/role/adminrole.png";
} elseif ($sentinel['role'] == 2) {
    $image = "img/role/premiumrole.png";
} else {
    $image = "img/role/freemium.png"; 
}


echo "<img src='$image' alt='rol_img' width='35' >";
?></h1>
		
		<?php
if ($sentinel['owner'] == 1) {
    echo "<h2>OWNER</h2>";
} elseif ($sentinel['role'] == 1) {
    echo "<h2>Admin</h2>";
} elseif ($sentinel['role'] == 2) {
    echo "<h2>Premium</h2>";
} else {
    echo "<h2>Freemium</h2>"; 
}
?>


													
                          <font class="text-danger">Bitiş Tarihi:
                          <?php
                                                   if ($sentinel['role'] == 1) {
                            echo "Sınırsız";
                             }elseif ($sentinel['role'] == 2 && $sentinel['enddate'] == 0) {
                            echo "Sınırsız";
                             }elseif ($sentinel['role'] == 3 && $sentinel['enddate'] == 0) {
                            echo "Sınırsız";
                             }elseif ($sentinel['enddate'] == 0 ) {
                            echo "Sınırsız";
                             }else{
                              echo "";
                             }
                              
                          ?></font>
                          <font class="text-danger">
                        <?php
    if ($sentinel['enddate'] != 0) {
        echo $sentinel['enddate'];
    }
    ?>
    </font>
    
                   
<br>
<br>
<style>
.custom-input {
    width: 250px; 
    margin: 0 auto; 
    
}
</style>
<?php
if ($sentinel['role'] == 1 || $sentinel['role'] == 2) {
    
?>
    <form action="../server/img_guncelle.php" method="POST" id="imgForm">
	<div class="description">
        <label for="img">Profil Fotoğrafı Ekle:</label>
        <input type="text" id="img" class="form-control" name="img" placeholder="https://resim.com/img.jpg" >
        <input type="submit"  class="btn btn-primary" value="Ekle">
        <input type="submit"  class="btn btn-danger" value="Sil">
        <input type="hidden" name="kullanici_adi" value="<?=$sentinel['key_ad'];?>">
    </form></div>
	<div class="description">
	<form method="POST" id="passform">
        <label for="kullaniciAdi">Şifre Değiştir:</label>
        <input type="text" name="kullaniciAdi" class="form-control custom-input" value="<?=$sentinel['key_ad'];?>" readonly>

        
        <input type="password" name="mevcutSifre" class="form-control custom-input" placeholder="Mevcut Şifre" required>

      
        <input type="password" name="yeniSifre" class="form-control custom-input" placeholder="Yeni Şifre" required>

        <input type="submit" value="Şifreyi Değiştir" class="btn btn-primary">
    </form>  </div>
<?php
}
?>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("#passform");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(form);

        fetch("../server/passreset.php", {
            method: "POST",
            body: formData,
        })
        .then((response) => response.text())
        .then((data) => {
            if (data === "Şifre başarıyla değiştirildi.") {
                Swal.fire({
                    icon: "success",
                    title: "Başarılı!",
                    text: "Şifre başarıyla değiştirildi.",
                });

                setTimeout(function () {
                    location.reload();
                }, 1000);
            } else if (data === "Mevcut şifre yanlış.") {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: "Mevcut şifre yanlış.",
                });
                
            } else if (data === " Lütfen başka bir şifre seçin.") {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: " Lütfen başka bir şifre seçin.",
                });
          } else if (data.includes("Yeni şifre en az 6 karakter olmalıdır.")) {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: "Yeni şifre en az 6 karakter olmalıdır.",
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: "Şifre değiştirme işlemi başarısız.",
                });
            }
        })
        .catch((error) => {
            console.error("Hata:", error);
        });
    });
});
</script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("#imgForm"); 

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      const formData = new FormData(form);

      fetch("../server/img_guncelle.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.text())
        .then((data) => {
          if (data === "Img değeri başarıyla güncellendi.") {
            Swal.fire({
              icon: "success",
              title: "Başarılı!",
              text: "Profil fotoğrafı eklendi.",
            });

            setTimeout(function () {
              location.reload();
            }, 1000);
          } else if (data === "Lütfen geçerli bir resim URL'si girin.") {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "Fotoğraf linki doğru değil. Örneğin https://resim.com/img.jpg gibi link olarak ekleyiniz.",
            });
          } else if (data === "Geçerli bir resim uzantısı ekleyin.") {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "Resim linki doğru değil. Linkin sonunda .jpg .png .gif .webp gibi resim uzantısı olmalıdır.",
            });
          } else {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "Profil fotoğrafı eklenirken bir hata oluştu.",
            });
          }
        })
        .catch((error) => {
          console.error("Hata:", error);
        });
    });
  });
</script>



	<br>

 </p>
			<a href="logout.js"	>
	<button class="follow">Çıkış Yap</button>	</a>
	</div>
	



	
			
		
		</div>
	</div>
</div>
                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
       </div>
      </div>
     </div>
    </div>
</div>



             
<?php 

include("inc/main_js.php");

?>
                   		<style>
                   	@import url("https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap");

* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}

html,
body {
        background-image: url('https://static.vecteezy.com/system/resources/previews/013/755/473/non_2x/abstract-dark-background-with-line-grid-gradient-color-applicable-website-banner-poster-corporate-social-media-template-billboard-business-sign-video-film-in-channel-backdrop-techno-background-free-vector.jpg');
	height: 100vh;
	display: grid;
	
	font-family: "Open Sans", sans-serif;
}

.profile {
	margin: auto;
	height: 500px;
	width: 330px;
	background: #ffffff;
	display: flex;
	flex-direction: column;
	align-items: center;
	text-align: center;
	border-radius: 20px;
	box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;
	-ms-overflow-style: none; /* for Internet Explorer, Edge */
	scrollbar-width: none; /* for Firefox */
	overflow-y: scroll;
	
}

::-webkit-scrollbar {
	display: none; /* for Chrome, Safari, and Opera */
}

.header-color {
	border-radius: 20px 20px 0 0;
	padding-bottom: 150px;
	width: 400px;
	background: black;
}

.profile-pic img {
	height: 200px;
	width: 200px;
	border-radius: 50%;
	border: 10px solid #ffffff;
	margin-top: -100px;
}

.title {
	margin-bottom: 25px;
}

h1 {
	font-size: 32px;
	font-weight: 700;
	color: #0c120c;
	margin-bottom: 10px;
	letter-spacing: 0.025em;
}

h2 {
	font-size: 18px;
	letter-spacing: 0.01em;
	color: #0c120c;
	span {
		color: #33658a;
		font-weight: 700;
	}
}

.description {
	margin-bottom: 25px;
	color: #33658a;
	letter-spacing: 0.01em;

	p:not(:last-child) {
		margin-bottom: 5px;
	}
}

button {
	font-family: "Open Sans", sans-serif;
	color: #ffffff;
	background: #33658a;
	font-size: 18px;
	font-weight: 600;
	letter-spacing: 0.025em;
	border: none;
	border-radius: 15px;
	min-height: 35px;
	width: 100px;
	margin-bottom: 25px;
	transition: all 0.2s ease;
	cursor: pointer;
}

button:hover {
	width: 115px;
	background: #4f759be0;
}

.images-container {
	width: 350px;

	.image {
		margin-bottom: 25px;

		img {
			width: 100%;
			border-radius: 5px;
			margin-bottom: 5px;
		}

		i {
			color: #9b1d20;
			display: flex;
			align-items: center;
			margin-left: 10px;

			span {
				margin-left: 5px;
				font-family: "Open Sans", sans-serif;
				font-size: 14px;
				font-weight: 400;
				color: #000000;
			}
		}
	}
}
	</style>