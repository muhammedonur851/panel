<?php 
$page_title = 'Hesabım';

include("inc/sidebar.php"); ?>
  
<?php
$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullaniciAdi = $_POST["kullaniciAdi"];
    $mevcutSifre = $_POST["mevcutSifre"];
    $yeniSifre = $_POST["yeniSifre"];
    

    $sql = "SELECT key_pas FROM users WHERE key_ad = ?";
    $stmt = $conn->prepare($sql);


    $stmt->bind_param("s", $kullaniciAdi);


    $stmt->execute();


    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $veritabaniSifre = $row["key_pas"];
        
     
        if ($mevcutSifre == $veritabaniSifre) {
   
            $checkSql = "SELECT key_pas FROM users WHERE key_pas = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->bind_param("s", $yeniSifre);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();

            if ($checkResult->num_rows > 0) {
                echo "Bu şifre zaten kullanılıyor. Lütfen başka bir şifre seçin.";
            } else {
           
                $updateSql = "UPDATE users SET key_pas = ? WHERE key_ad = ?";
                $updateStmt = $conn->prepare($updateSql);
                $updateStmt->bind_param("ss", $yeniSifre, $kullaniciAdi);
                
                if ($updateStmt->execute()) {
                    echo "Şifre başarıyla değiştirildi.";
                } else {
                    echo "Şifre değiştirme işlemi başarısız: " . $conn->error;
                }
            }
        } else {
            echo "Mevcut şifre yanlış.";
        }
    } else {
        echo "Kullanıcı bulunamadı.";
    }

 
    $stmt->close();
    $updateStmt->close();
    $checkStmt->close();
}

$conn->close();
?>
 <div class="main-content">
                <div class="page-content">
                  <div class="container-fluid">

            <div class="container-xxl flex-grow-1 container-p-y">
               <div class="row">
                <div class="col-xl">
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Üyelik Bilgileri</h5>
                      <small class="text-primary float-end"></small>
                    </div>
                    <div class="card-body">
<div style="display: flex; align-items: center;">
<table id="example" class="table table-striped table-bordered text-nowrap w-100  ">
  <tbody>
     <tr>
     <td>Kullanıcı Adı </td>
   <td>
   <div class="user"> <strong><?=$sentinel['key_ad'];?></strong></div></td> </tr>
</div>
<br>
 <tr>
 <td>  <font class="text-primary"><strong>Bitiş Tarihi:</strong></font> </td>
	<style>
    .user {
     text-shadow: 0 0 10px rgba(255, 0, 0, 0.8);
font-family: Arial, sans-serif;
    }
    .fnt {
    
font-family: Arial, sans-serif;
    }
  </style> 
  <td> 
   <div class="fnt"> 
  
                          <?php
                                                   if ($sentinel['adminz'] == 1) {
                            echo "Sınırsız";
                             }elseif ($sentinel['role'] == 2 && $sentinel['enddate'] == 0) {
                            echo "Sınırsız";
                             }elseif ($sentinel['role'] == 3 && $sentinel['enddate'] == 0) {
                            echo "Sınırsız";
                             }elseif ($sentinel['enddate'] == 0 ) {
                            echo "Sınırsız";
                             }else{
                              echo "";
                             }
                              
                          ?>
                         
                        <?php
    if ($sentinel['enddate'] != 0) {
        echo $sentinel['enddate'];
    }
    ?>
 </td>  </tr>
                </div>
          <tr>
                <td> 
                 <div class="fnt"> 
    <font class="text-primary"><strong>Üyelik Türü:</strong></font></td> 
    <td> 
                         		<?php
if ($sentinel['owner'] == 1) {
    echo "OWNER";
} elseif ($sentinel['role'] == 1) {
    echo "Admin";
} elseif ($sentinel['role'] == 2) {
    echo "Premium";
} else {
    echo "Freemium"; 
}
?></td>   </tr>
 </tbody>
</table>
                </div>
                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
       </div>
      </div>
                      <?php
if ($sentinel['role'] == 1 || $sentinel['role'] == 2) {
    
?>
          <div class="main-content">
                <div class="page-content">
                  <div class="container-fluid">

            <div class="container-xxl flex-grow-1 container-p-y">
               <div class="row">
                <div class="col-xl">
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Profil Fotoğrafı Ekle</h5>
                      <small class="text-primary float-end"></small>
                    </div>
                    <div class="card-body">
   
    <form action="../server/img_guncelle.php" method="POST" id="imgForm">
	<div class="description">
      
        <input type="text" style="background-color: #2A3C4D;" id="img" class="form-control" name="img" placeholder="https://resim.com/img.jpg" >
        
        <input type="submit"  class="btn btn-primary" value="Ekle">&nbsp;
        <input type="submit"  class="btn btn-danger" value="Sil">
        <input type="hidden" name="kullanici_adi" value="<?=$sentinel['key_ad'];?>">
    </form></div>
	
<?php
}
?>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("#imgForm"); 

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      const formData = new FormData(form);

      fetch("../server/img_guncelle.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.text())
        .then((data) => {
          if (data === "Img değeri başarıyla güncellendi.") {
            Swal.fire({
              icon: "success",
              title: "Başarılı!",
              text: "Profil fotoğrafı eklendi.",
            });

            setTimeout(function () {
              location.reload();
            }, 1000);
          } else if (data === "Lütfen geçerli bir resim URL'si girin.") {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "Fotoğraf linki doğru değil. Örneğin https://resim.com/img.jpg gibi link olarak ekleyiniz.",
            });
          } else if (data === "Geçerli bir resim uzantısı ekleyin.") {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "Resim linki doğru değil. Linkin sonunda .jpg .png .gif .webp gibi resim uzantısı olmalıdır.",
            });
          } else {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "Profil fotoğrafı eklenirken bir hata oluştu.",
            });
          }
        })
        .catch((error) => {
          console.error("Hata:", error);
        });
    });
  });
</script>

                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
       </div>
      </div>
                       <?php
if ($sentinel['role'] == 1 || $sentinel['role'] == 2) {
    
?>
      <div class="main-content">
                <div class="page-content">
                  <div class="container-fluid">
            <div class="container-xxl flex-grow-1 container-p-y">
               <div class="row">
                <div class="col-xl">
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Şifre Değiştir</h5>
                      <small class="text-primary float-end"></small>
                    </div>
                    <div class="card-body">

 
	<div class="description">
	<form method="POST" id="passform">
       
        <input type="text" style="background-color: #2A3C4D;" name="kullaniciAdi" class="form-control custom-input" value="<?=$sentinel['key_ad'];?>" readonly>

         &nbsp;
        <input type="password" style="background-color: #2A3C4D;" name="mevcutSifre" class="form-control custom-input" placeholder="Mevcut Şifre" required>
 &nbsp;
      
        <input type="password" style="background-color: #2A3C4D;" name="yeniSifre" class="form-control custom-input" placeholder="Yeni Şifre" required>

        <input type="submit" value="Şifreyi Değiştir" class="btn btn-primary">
    </form>  </div>
<?php
}
?>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("#passform");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(form);

        fetch("../server/passreset.php", {
            method: "POST",
            body: formData,
        })
        .then((response) => response.text())
        .then((data) => {
            if (data === "Şifre başarıyla değiştirildi.") {
                Swal.fire({
                    icon: "success",
                    title: "Başarılı!",
                    text: "Şifre başarıyla değiştirildi.",
                });

                setTimeout(function () {
                    location.reload();
                }, 1000);
            } else if (data === "Mevcut şifre yanlış.") {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: "Mevcut şifre yanlış.",
                });
                
            } else if (data === " Lütfen başka bir şifre seçin.") {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: " Lütfen başka bir şifre seçin.",
                });
          } else if (data.includes("Yeni şifre en az 6 karakter olmalıdır.")) {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: "Yeni şifre en az 6 karakter olmalıdır.",
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Hata!",
                    text: "Şifre değiştirme işlemi başarısız.",
                });
            }
        })
        .catch((error) => {
            console.error("Hata:", error);
        });
    });
});
</script>
                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
       </div>
      </div>
     </div>
    </div>
</div>
      </div>
     </div>
    </div>
</div>

             
<?php 

include("inc/main_js.php");

?>