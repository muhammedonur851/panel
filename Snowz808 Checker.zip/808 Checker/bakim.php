<?php 
$page_title = 'Bakım';
include("inc/sidebar.php");
include("server/vipkontrol.php");

?>  
          <div class="main-content">
                <div class="page-content">
                  <div class="container-fluid">

            <div class="container-xxl flex-grow-1 container-p-y">
               <div class="row">
                <div class="col-xl">
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Yakında aktif olucak ..</h5>
                      <small class="text-primary float-end">Sentinel</small>
                    </div>
                    <div class="card-body">
                    <center>
                    <img src="https://i.giphy.com/media/McUBKCpESJD0F7eqzT/giphy.webp" width="80">
                    <p>Bu çözüm geçici olarak kullanım dışıdır.<p></center>
                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
       </div>
      </div>
     </div>
    </div>
</div>


             
<?php 

include("inc/main_js.php");

?>