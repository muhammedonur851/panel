<?php
include("../server/connect.php");


$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}


$kullanici_adi = $_POST['kullanici_adi'];
$yeni_img = $_POST['img'];


if ($yeni_img !== "") {
    if (!filter_var($yeni_img, FILTER_VALIDATE_URL)) {
        echo "Lütfen geçerli bir resim URL'si girin.";
    
        exit();
    } elseif (!preg_match("/\.(jpg|jpeg|png|gif|webp)$/i", $yeni_img)) {
        echo "Geçerli bir resim uzantısı ekleyin.";
     
        exit();
    }
}


$stmt = $conn->prepare("UPDATE users SET img = ? WHERE key_ad = ?");
$stmt->bind_param("ss", $yeni_img, $kullanici_adi);


if ($stmt->execute()) {
    echo "Img değeri başarıyla güncellendi.";
} else {
    echo "Güncelleme hatası: " . $stmt->error;
}


$stmt->close();

$conn->close();
?>
