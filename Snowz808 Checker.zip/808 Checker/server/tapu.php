<?php

$key = $_SESSION['key'];

$codedbysentinel = $conn->query("SELECT * FROM users WHERE key_pas='$key'")->fetch();

if (($codedbysentinel['role'] == 1 || $codedbysentinel['tapu'] == 1 || ($codedbysentinel['role'] == 2 && $codedbysentinel['enddate'] == 0))) {
   
} else {
    header("Location: sınırsızgerekli.js");
}

?>
