<?php
include("../server/connect.php");

try {
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
   
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $key_ad = filter_input(INPUT_POST, 'key_ad', FILTER_SANITIZE_STRING);
    $key_pas = filter_input(INPUT_POST, 'key_pas', FILTER_SANITIZE_STRING);


    $stmt = $conn->prepare("INSERT INTO multiban (key_ad, key_pas) VALUES (:key_ad, :key_pas)");


    $stmt->bindParam(':key_ad', $key_ad, PDO::PARAM_STR);
    $stmt->bindParam(':key_pas', $key_pas, PDO::PARAM_STR);


    if ($stmt->execute()) {
        echo "success"; 
    } else {
        echo "error";
    }
} catch (PDOException $e) {
    echo "error";
}


$conn = null;
?>
