<?php
ob_start();
error_reporting(0);
session_start();
include("connect.php");
if (isset($_SESSION['key'])) {
    
}else{
    header("Location: //");
}

$key = $_SESSION['key'];
$sentinel = $conn->query("SELECT * FROM users WHERE key_pas='{$key}'")->fetch();

$status = 1;
$durum = $conn->query("SELECT * FROM durum WHERE id='{$status}'")->fetch();

$eklenentarih = $sentinel['createddate'];
$bitistarih = $sentinel['enddate'];
$tarih1 = strtotime($eklenentarih);
$tarih2 = strtotime($bitistarih);

$sentinelsayi = $conn->query("SELECT COUNT(*) FROM users WHERE role ='1' or role='2' or role='0'")->fetchColumn();
$sentinelbanned = $conn->query("SELECT COUNT(*) FROM users WHERE banned ='1' ")->fetchColumn();

if (!empty($_SERVER['HTTP_CLIENT_IP']))   
  {
    $ip_address = $_SERVER['HTTP_CLIENT_IP'];
  }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
  {
    $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
  }
else
  {
    $ip_address = $_SERVER['REMOTE_ADDR'];
  }

  if ($sentinel['banned']==1) {
    session_destroy();
    header("Location: /");
    exit();
}

if ($sentinel['security'] == 1) {
  
}else if ($sentinel['ipadres'] != "$ip_address") {

  $kaydet = $conn->prepare("UPDATE users SET banned='1' WHERE key_pas = '{$key }'");
  $kaydet->execute();
     session_destroy(); 
     header("Location: /");
    exit();
  
}


$sürebitiş = date('d.m.Y');

$mercycheck = $conn->query("SELECT * FROM users WHERE enddate='$sürebitiş'")->fetch();


if ($mercycheck['enddate'] == $sürebitiş) {
  $teammercycheck = $conn->prepare("UPDATE users SET endkey='1' WHERE enddate='$sürebitiş'");
  $teammercycheck->execute();

}

if ($sentinel['endkey'] == 1) {
       session_destroy();
     header("Location: /");
    exit();
}
if ($sentinel['deleted'] == 1) {
       session_destroy();
     header("Location: /");
    exit();
}

if ($sentinel['role'] == 0) {
    header("Location: index.unity");
    exit();
}
?>