<?php

$key = $_SESSION['key'];

$codedbysentinel = $conn->query("SELECT * FROM users WHERE key_pas='$key'")->fetch();

if ($codedbysentinel['adminz'] != 1) {
    header("Location: check.js");
}

?>