<?php
include("../server/connect.php");


$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullaniciAdi = $_POST["kullaniciAdi"];
    $mevcutSifre = $_POST["mevcutSifre"];
    $yeniSifre = $_POST["yeniSifre"];


    $sql = "SELECT key_pas FROM users WHERE key_ad = ?";
    $stmt = $conn->prepare($sql);


    $stmt->bind_param("s", $kullaniciAdi);


    $stmt->execute();


    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $veritabaniSifre = $row["key_pas"];

      
        if ($mevcutSifre == $veritabaniSifre) {
          
            if (strlen($yeniSifre) < 6) {
                echo "Yeni şifre en az 6 karakter olmalıdır. Lütfen geçerli bir şifre girin.";
            } else {
                $checkSql = "SELECT key_pas FROM users WHERE key_pas = ?";
                $checkStmt = $conn->prepare($checkSql);
                $checkStmt->bind_param("s", $yeniSifre);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();

                if ($checkResult->num_rows > 0) {
                    echo "Başka bir şifre deneyiniz.";
                } else {
                
                    $updateSql = "UPDATE users SET key_pas = ? WHERE key_ad = ?";
                    $updateStmt = $conn->prepare($updateSql);
                    $updateStmt->bind_param("ss", $yeniSifre, $kullaniciAdi);

                    if ($updateStmt->execute()) {
                        echo "Şifre başarıyla değiştirildi.";
                    } else {
                        echo "Şifre değiştirme işlemi başarısız: " . $conn->error;
                    }
                }
            }
        } else {
            echo "Mevcut şifre yanlış.";
        }
    } else {
        echo "Kullanıcı bulunamadı.";
    }


    $stmt->close();
    $updateStmt->close();
    $checkStmt->close();
}


$conn->close();
?>
