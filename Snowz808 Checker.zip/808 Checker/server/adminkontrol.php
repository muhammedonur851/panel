<?php
$key = $_SESSION['key'];
$bacısikensentinel = $conn->query("SELECT * FROM users WHERE key_pas='{$key}'")->fetch();

if ($bacısikensentinel['role'] != 1) {
    header("Location: /check.js");

}

?>