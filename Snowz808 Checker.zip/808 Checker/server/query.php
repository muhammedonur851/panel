<?php
include("../server/connect.php");


$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}


$sorgu = $conn->prepare("SELECT count FROM sorgu_query");
$sorgu->execute();


$sorgu->bind_result($count);
$sorgu->fetch();

echo "<span style='font-size: 16px; color: #3498db; font-weight: ;'>" . number_format($count, 0, ',', '.') . "</span>";

$conn->close();
?>
