<?php
include("../server/connect.php");


$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}


$user = $_POST['user'];

$sql = "DELETE FROM LOG_sorgu WHERE user = '$user'";
if ($conn->query($sql) === TRUE) {
    echo "Veri başarıyla silindi.";
} else {
    echo "Veri silinemedi. Hata: " . $conn->error;
}


$conn->close();
?>
