<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "BOZO";

//CODED BY BOZO :) BOZO808 :D

try {
  $conn = new PDO("mysql:host=$servername;dbname=$db;charset=utf8", $username, $password);
  // t.me/sentinelbest
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}
?>