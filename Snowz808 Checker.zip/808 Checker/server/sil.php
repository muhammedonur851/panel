<?php
include("../server/connect.php");


$conn = new mysqli($servername, $username, $password, $db);


if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}


$key_ad = $_POST['key_ad'];
$key_pas = $_POST['key_pas'];


$sql = "DELETE FROM multiban WHERE key_ad = ? AND key_pas = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $key_ad, $key_pas);

if ($stmt->execute()) {
    echo "Veri başarıyla silindi.";
} else {
    echo "Veri silinemedi. Hata: " . $conn->error;
}


$conn->close();
?>
