<!-- CODED BY BOZO808 -->   <!-- NE ARIYON BURDA EŞŞEK -->
<?php
require 'server/connect.php';
ini_set("display_errors", 0);
error_reporting(0);

$connection = new mysqli($servername, $username, $password, $db);

// Bağlantı hatası kontrolü
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$panel_query = $conn->query("SELECT panel_name FROM settings");
$panel_name = $panel_query->fetch(PDO::FETCH_ASSOC)['panel_name'];

$social_query = $conn->query("SELECT social_link FROM settings");
$social_link = $social_query->fetch(PDO::FETCH_ASSOC)['social_link'];

$social_kısa = $conn->query("SELECT social_kısa FROM settings");
$socialkısa = $social_kısa->fetch(PDO::FETCH_ASSOC)['social_kısa'];

$yetkili_query = $conn->query("SELECT yetkili FROM settings");
$yetkili = $yetkili_query->fetch(PDO::FETCH_ASSOC)['yetkili'];

$yetkiliurl_query = $conn->query("SELECT yetkili_tg FROM settings");
$yetkili_tg = $yetkiliurl_query->fetch(PDO::FETCH_ASSOC)['yetkili_tg'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="robots" content="noindex">
  <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
<table width=100% height=100%><td align=center><br><br><br><br><br><br><br><br>
<link href="https://fonts.googleapis.com/css?family=Orbitron:700" rel='stylesheet' type='text/css'>

<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>---</title>
</head>
<body bgcolor="black" oncontextmenu='return false;' onkeydown='return false;' onmousedown='return false;'>
<style type="text/css">
h1 {color: #333;font-size: 85px;margin: 1px auto;text-align:center;text-transform:uppercase; font-family:Orbitron;}
.neon {color: #FFFFFF;text-shadow: 0 0 5px #1ab4e7, 0 0 10px #1ab4e7, 0 0 30px #18a2d0, 0 0 45px #18a2d0, 0 0 60px #18a2d0;}
 
 
h2 {color: #333;font-size: 50px;margin: 1px auto;text-align:center;text-transform:uppercase; font-family:Orbitron;}
.neon {color: #FFFFFF;text-shadow: 0 0 5px #1ab4e7, 0 0 10px #1ab4e7, 0 0 30px #18a2d0, 0 0 45px #18a2d0, 0 0 60px #18a2d0;}
 
h3 {color: #333;font-size: 50px;margin: 1px auto;text-align:center;text-transform:uppercase; font-family:Orbitron;}
.neon {color: #FFFFFF;text-shadow: 0 0 5px #1ab4e7, 0 0 10px #1ab4e7, 0 0 30px #18a2d0, 0 0 45px #18a2d0, 0 0 60px #18a2d0;}
 
 
h4 {color: #FF0000;font-size: 20px;margin: 1px auto;text-align:center;text-transform:uppercase; font-family:Orbitron;}
.neon {color: #FFFFFF;text-shadow: 0 0 5px #1ab4e7, 0 0 10px #1ab4e7, 0 0 30px #18a2d0, 0 0 45px #18a2d0, 0 0 60px #18a2d0;}
 
 
.matrix {color: #FFFFFF; font-family:Arial, Courier, Monotype; font-size:20pt; text-align:center; width:10px; padding:0px; margin:0px;}
.jokitz1{
    text-align : center;
    }
.jokitz2{
    text-align : center;
    font-family : Courier;
    }
</style>
<script type="text/javascript">
 
<!--
 
//Disable right click script
 
var message="Dear Admin, Just Edit Index";
 
///////////////////////////////////
 
function clickIE() {if (document.all) {(message);return false;}}
 
function clickNS(e) {if
 
(document.layers||(document.getElementById&&!document.all)) {
 
if (e.which==2||e.which==3) {(message);return false;}}}
 
if (document.layers)
 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
 
document.oncontextmenu=new Function("return false")
 
// -->
 
</script>
 
<!-- <script language="JavaScript1.2" type="text/javascript">
 
function ClearError() {return true;}
 
window.onerror = ClearError;
 
</script> -->
 
<script><!--
 
var rows=1; // must be an odd number
 
var speed=10; // lower is faster
 
var reveal=2; // between 0 and 2 only. The higher, the faster the word appears
 
var effectalign="center" //enter "center" to center it.
 
 
/***********************************************
 
* Just Edit :V
 
***********************************************/
  
var w3c=document.getElementById && !window.opera;;
 
var ie45=document.all && !window.opera;
 
var ma_tab, matemp, ma_bod, ma_row, x, y, columns, ma_txt, ma_cho;
 
var m_coch=new Array();
 
var m_copo=new Array();
 
window.onload=function() {
 
    if (!w3c && !ie45) return
 
 var matrix=(w3c)?document.getElementById("matrix"):document.all["matrix"];
 
 ma_txt=(w3c)?matrix.firstChild.nodeValue:matrix.innerHTML;
 
 ma_txt=" "+ma_txt+" ";
 
 columns=ma_txt.length;
 
 if (w3c) {
 
   while (matrix.childNodes.length) matrix.removeChild(matrix.childNodes[0]);
 
   ma_tab=document.createElement("table");
 
   ma_tab.setAttribute("border", 0);
 
   ma_tab.setAttribute("align", effectalign);
 
   ma_tab.style.backgroundColor="#000000";
 
   ma_bod=document.createElement("tbody");
 
   for (x=0; x<rows; x++) {
 
     ma_row=document.createElement("tr");
 
     for (y=0; y<columns; y++) {
 
       matemp=document.createElement("td");
 
       matemp.setAttribute("id", "Mx"+x+"y"+y);
 
       matemp.className="matrix";
 
       matemp.appendChild(document.createTextNode(String.fromCharCode(160)));
 
       ma_row.appendChild(matemp);
 
     }
 
     ma_bod.appendChild(ma_row);
 
   }
 
   ma_tab.appendChild(ma_bod);
 
   matrix.appendChild(ma_tab);
 
 } else {
 
   ma_tab='<ta'+'ble align="'+effectalign+'" border="0" style="background-color:#000000">';
 
   for (var x=0; x<rows; x++) {
 
     ma_tab+='<t'+'r>';
 
     for (var y=0; y<columns; y++) {
 
       ma_tab+='<t'+'d class="matrix" id="Mx'+x+'y'+y+'"> </'+'td>';
 
     }
 
     ma_tab+='</'+'tr>';
 
   }
 
   ma_tab+='</'+'table>';
 
   matrix.innerHTML=ma_tab;
 
 }
 
 ma_cho=ma_txt;
 
 for (x=0; x<columns; x++) {
 
   ma_cho+=String.fromCharCode(32+Math.floor(Math.random()*94));
 
   m_copo[x]=0;
 
 }
 
 ma_bod=setInterval("mytricks()", speed);
 
}
 
 
 
function mytricks() {
 
 x=0;
 
 for (y=0; y<columns; y++) {
 
   x=x+(m_copo[y]==100);
 
   ma_row=m_copo[y]%100;
 
   if (ma_row && m_copo[y]<100) {
 
     if (ma_row<rows+1) {
 
       if (w3c) {
 
         matemp=document.getElementById("Mx"+(ma_row-1)+"y"+y);
 
         matemp.firstChild.nodeValue=m_coch[y];
 
       }
 
       else {
 
         matemp=document.all["Mx"+(ma_row-1)+"y"+y];
 
         matemp.innerHTML=m_coch[y];
 
       }
 
       matemp.style.color="#81F2FF";
 
       matemp.style.fontWeight="bold";
 
     }
 
     if (ma_row>1 && ma_row<rows+2) {
 
       matemp=(w3c)?document.getElementById("Mx"+(ma_row-2)+"y"+y):document.all["Mx"+(ma_row-2)+"y"+y];
 
       matemp.style.fontWeight="normal";
 
       matemp.style.color="#00BBFF";
 
     }
 
     if (ma_row>2) {
 
         matemp=(w3c)?document.getElementById("Mx"+(ma_row-3)+"y"+y):document.all["Mx"+(ma_row-3)+"y"+y];
 
       matemp.style.color="#20FFDA";
 
     }
 
     if (ma_row<Math.floor(rows/2)+1) m_copo[y]++;
 
     else if (ma_row==Math.floor(rows/2)+1 && m_coch[y]==ma_txt.charAt(y)) zoomer(y);
 
     else if (ma_row<rows+2) m_copo[y]++;
 
     else if (m_copo[y]<100) m_copo[y]=0;
 
   }
 
   else if (Math.random()>0.9 && m_copo[y]<100) {
 
     m_coch[y]=ma_cho.charAt(Math.floor(Math.random()*ma_cho.length));
 
     m_copo[y]++;
 
   }
 
 }
 
 if (x==columns) clearInterval(ma_bod);
 
}
 
 
 
function zoomer(ycol) {
 
 var mtmp, mtem, ytmp;
 
 if (m_copo[ycol]==Math.floor(rows/2)+1) {
 
   for (ytmp=0; ytmp<rows; ytmp++) {
 
     if (w3c) {
 
       mtmp=document.getElementById("Mx"+ytmp+"y"+ycol);
 
       mtmp.firstChild.nodeValue=m_coch[ycol];
 
     }
 
     else {
 
       mtmp=document.all["Mx"+ytmp+"y"+ycol];
 
       mtmp.innerHTML=m_coch[ycol];
 
     }
 
     mtmp.style.color="#5BEEFF";
 
     mtmp.style.fontWeight="bold";
 
   }
 
   if (Math.random()<reveal) {
 
     mtmp=ma_cho.indexOf(ma_txt.charAt(ycol));
 
     ma_cho=ma_cho.substring(0, mtmp)+ma_cho.substring(mtmp+1, ma_cho.length);
 
   }
 
   if (Math.random()<reveal-1) ma_cho=ma_cho.substring(0, ma_cho.length-1);
 
   m_copo[ycol]+=199;
 
   setTimeout("zoomer("+ycol+")", speed);
 
 }
 
 else if (m_copo[ycol]>200) {
 
   if (w3c) {
 
     mtmp=document.getElementById("Mx"+(m_copo[ycol]-201)+"y"+ycol);
 
     mtem=document.getElementById("Mx"+(200+rows-m_copo[ycol]--)+"y"+ycol);
 
   }
 
   else {
 
     mtmp=document.all["Mx"+(m_copo[ycol]-201)+"y"+ycol];
 
     mtem=document.all["Mx"+(200+rows-m_copo[ycol]--)+"y"+ycol];
 
   }
 
   mtmp.style.fontWeight="normal";
 
   mtem.style.fontWeight="normal";
 
   setTimeout("zoomer("+ycol+")", speed);
 
 }
 
 else if (m_copo[ycol]==200) m_copo[ycol]=100+Math.floor(rows/2);
 
 if (m_copo[ycol]>100 && m_copo[ycol]<200) {
 
   if (w3c) {
 
     mtmp=document.getElementById("Mx"+(m_copo[ycol]-101)+"y"+ycol);
 
     mtmp.firstChild.nodeValue=String.fromCharCode(160);
 
     mtem=document.getElementById("Mx"+(100+rows-m_copo[ycol]--)+"y"+ycol);
 
     mtem.firstChild.nodeValue=String.fromCharCode(160);
 
   }
 
   else {
 
     mtmp=document.all["Mx"+(m_copo[ycol]-101)+"y"+ycol];
 
     mtmp.innerHTML=String.fromCharCode(160);
 
     mtem=document.all["Mx"+(100+rows-m_copo[ycol]--)+"y"+ycol];
 
     mtem.innerHTML=String.fromCharCode(160);
 
   }
 
   setTimeout("zoomer("+ycol+")", speed);
 
 }
 
  
 //start
 
var h1 = document.getElementsByTagName("h1")[0],
 
text = h1.innerText || h1.textContent,
 
split = [], i, lit = 0, timer = null;
 
for(i = 0; i < text.length; ++i) {
 
split.push("<span>" + text[i] + "</span>");
 
}
 
h1.innerHTML = split.join("");
 
split = h1.childNodes;
 
var flicker = function() {
 
lit += 0.01;
 
if(lit >= 1) {
 
clearInterval(timer);
 
}
 
for(i = 0; i < split.length; ++i) {
 
if(Math.random() < lit) {
 
split[i].className = "neon";
 
} else {
 
split[i].className = "";
 
}
 
}
 
}
 
setInterval(flicker, 100);
 
}
 
//strat sec
 
// end  -->
 </script>

<center>
<div id="matrix" class="auto-style8">developed by <?php echo $yetkili ?></div>
<h1>

 <?php echo $panel_name ?>
</h1>

 <br>
<br>
 </font></a><br>
<font face="Arial Black" color="white" size="6px" >Telegram Adresimiz: </font>
<a href="<?php echo $social_link; ?>">
  <br><font face="Arial" color="30D5C8" size="7px" ><?php echo $social_link; ?>
<br><br>
<style>
  .button-85 {
    padding: 2em 3em 2em;
    border: none;
    outline: none;
    color: rgb(255, 255, 255);
    background: #111;
    cursor: pointer;
    position: relative;
    z-index: 0;
    border-radius: 10px;
    user-select: none;
    -webkit-user-select: none;
    touch-action: manipulation;
  }
  
  .button-85:before {
    content: "";
    background: linear-gradient(
      45deg,
      #ff0000,
      #ff7300,
      #fffb00,
      #48ff00,
      #00ffd5,
      #002bff,
      #7a00ff,
      #ff00c8,
      #ff0000
    );
    position: absolute;
    top: -2px;
    left: -2px;
    background-size: 400%;
    z-index: -1;
    filter: blur(5px);
    -webkit-filter: blur(5px);
    width: calc(100% + 4px);
    height: calc(100% + 4px);
    animation: glowing-button-85 20s linear infinite;
    transition: opacity 0.3s ease-in-out;
    border-radius: 10px;
  }
  
  @keyframes glowing-button-85 {
    0% {
      background-position: 0 0;
    }
    50% {
      background-position: 400% 0;
    }
    100% {
      background-position: 0 0;
    }
  }
  
  .button-85:after {
    z-index: -1;
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    background: #222;
    left: 0;
    top: 0;
    border-radius: 10px;
  }
  </style>
  <a href="login.js">
  <button class="button-85" role="button"><font size="25">Giriş Yap</button></a></font>
  
  
</html>

<script>/** @license

 DHTML Snowstorm! JavaScript-based snow for web pages
 Making it snow on the internets since 2003. You're welcome.
 -----------------------------------------------------------
 Version 1.44.20131215 (Previous rev: 1.44.20131208)
 Copyright (c) 2007, Scott Schiller. All rights reserved.
 Code provided under the BSD License
 http://schillmania.com/projects/snowstorm/license.txt
*/
var snowStorm=function(g,f){function k(a,d){isNaN(d)&&(d=0);return Math.random()*a+d}function x(){g.setTimeout(function(){a.start(!0)},20);a.events.remove(m?f:g,"mousemove",x)}function y(){(!a.excludeMobile||!D)&&x();a.events.remove(g,"load",y)}this.excludeMobile=this.autoStart=!0;this.flakesMax=128;this.flakesMaxActive=64;this.animationInterval=33;this.useGPU=!0;this.className=null;this.excludeMobile=!0;this.flakeBottom=null;this.followMouse=!0;this.snowColor="#fff";this.snowCharacter="&bull;";this.snowStick=
!0;this.targetElement=null;this.useMeltEffect=!0;this.usePixelPosition=this.usePositionFixed=this.useTwinkleEffect=!1;this.freezeOnBlur=!0;this.flakeRightOffset=this.flakeLeftOffset=0;this.flakeHeight=this.flakeWidth=8;this.vMaxX=5;this.vMaxY=4;this.zIndex=0;var a=this,q,m=navigator.userAgent.match(/msie/i),E=navigator.userAgent.match(/msie 6/i),D=navigator.userAgent.match(/mobile|opera m(ob|in)/i),r=m&&"BackCompat"===f.compatMode||E,h=null,n=null,l=null,p=null,s=null,z=null,A=null,v=1,t=!1,w=!1,
u;a:{try{f.createElement("div").style.opacity="0.5"}catch(F){u=!1;break a}u=!0}var B=!1,C=f.createDocumentFragment();q=function(){function c(b){g.setTimeout(b,1E3/(a.animationInterval||20))}function d(a){return void 0!==h.style[a]?a:null}var e,b=g.requestAnimationFrame||g.webkitRequestAnimationFrame||g.mozRequestAnimationFrame||g.oRequestAnimationFrame||g.msRequestAnimationFrame||c;e=b?function(){return b.apply(g,arguments)}:null;var h;h=f.createElement("div");e={transform:{ie:d("-ms-transform"),
moz:d("MozTransform"),opera:d("OTransform"),webkit:d("webkitTransform"),w3:d("transform"),prop:null},getAnimationFrame:e};e.transform.prop=e.transform.w3||e.transform.moz||e.transform.webkit||e.transform.ie||e.transform.opera;h=null;return e}();this.timer=null;this.flakes=[];this.active=this.disabled=!1;this.meltFrameCount=20;this.meltFrames=[];this.setXY=function(c,d,e){if(!c)return!1;a.usePixelPosition||w?(c.style.left=d-a.flakeWidth+"px",c.style.top=e-a.flakeHeight+"px"):r?(c.style.right=100-100*
(d/h)+"%",c.style.top=Math.min(e,s-a.flakeHeight)+"px"):a.flakeBottom?(c.style.right=100-100*(d/h)+"%",c.style.top=Math.min(e,s-a.flakeHeight)+"px"):(c.style.right=100-100*(d/h)+"%",c.style.bottom=100-100*(e/l)+"%")};this.events=function(){function a(c){c=b.call(c);var d=c.length;e?(c[1]="on"+c[1],3<d&&c.pop()):3===d&&c.push(!1);return c}function d(a,b){var c=a.shift(),d=[f[b]];if(e)c[d](a[0],a[1]);else c[d].apply(c,a)}var e=!g.addEventListener&&g.attachEvent,b=Array.prototype.slice,f={add:e?"attachEvent":
"addEventListener",remove:e?"detachEvent":"removeEventListener"};return{add:function(){d(a(arguments),"add")},remove:function(){d(a(arguments),"remove")}}}();this.randomizeWind=function(){var c;c=k(a.vMaxX,0.2);z=1===parseInt(k(2),10)?-1*c:c;A=k(a.vMaxY,0.2);if(this.flakes)for(c=0;c<this.flakes.length;c++)this.flakes[c].active&&this.flakes[c].setVelocities()};this.scrollHandler=function(){var c;p=a.flakeBottom?0:parseInt(g.scrollY||f.documentElement.scrollTop||(r?f.body.scrollTop:0),10);isNaN(p)&&
(p=0);if(!t&&!a.flakeBottom&&a.flakes)for(c=0;c<a.flakes.length;c++)0===a.flakes[c].active&&a.flakes[c].stick()};this.resizeHandler=function(){g.innerWidth||g.innerHeight?(h=g.innerWidth-16-a.flakeRightOffset,l=a.flakeBottom||g.innerHeight):(h=(f.documentElement.clientWidth||f.body.clientWidth||f.body.scrollWidth)-(!m?8:0)-a.flakeRightOffset,l=a.flakeBottom||f.documentElement.clientHeight||f.body.clientHeight||f.body.scrollHeight);s=f.body.offsetHeight;n=parseInt(h/2,10)};this.resizeHandlerAlt=function(){h=
a.targetElement.offsetWidth-a.flakeRightOffset;l=a.flakeBottom||a.targetElement.offsetHeight;n=parseInt(h/2,10);s=f.body.offsetHeight};this.freeze=function(){if(a.disabled)return!1;a.disabled=1;a.timer=null};this.resume=function(){if(a.disabled)a.disabled=0;else return!1;a.timerInit()};this.toggleSnow=function(){a.flakes.length?(a.active=!a.active,a.active?(a.show(),a.resume()):(a.stop(),a.freeze())):a.start()};this.stop=function(){var c;this.freeze();for(c=0;c<this.flakes.length;c++)this.flakes[c].o.style.display=
"none";a.events.remove(g,"scroll",a.scrollHandler);a.events.remove(g,"resize",a.resizeHandler);a.freezeOnBlur&&(m?(a.events.remove(f,"focusout",a.freeze),a.events.remove(f,"focusin",a.resume)):(a.events.remove(g,"blur",a.freeze),a.events.remove(g,"focus",a.resume)))};this.show=function(){var a;for(a=0;a<this.flakes.length;a++)this.flakes[a].o.style.display="block"};this.SnowFlake=function(c,d,e){var b=this;this.type=c;this.x=d||parseInt(k(h-20),10);this.y=!isNaN(e)?e:-k(l)-12;this.vY=this.vX=null;
this.vAmpTypes=[1,1.2,1.4,1.6,1.8];this.vAmp=this.vAmpTypes[this.type]||1;this.melting=!1;this.meltFrameCount=a.meltFrameCount;this.meltFrames=a.meltFrames;this.twinkleFrame=this.meltFrame=0;this.active=1;this.fontSize=10+10*(this.type/5);this.o=f.createElement("div");this.o.innerHTML=a.snowCharacter;a.className&&this.o.setAttribute("class",a.className);this.o.style.color=a.snowColor;this.o.style.position=t?"fixed":"absolute";a.useGPU&&q.transform.prop&&(this.o.style[q.transform.prop]="translate3d(0px, 0px, 0px)");
this.o.style.width=a.flakeWidth+"px";this.o.style.height=a.flakeHeight+"px";this.o.style.fontFamily="arial,verdana";this.o.style.cursor="default";this.o.style.overflow="hidden";this.o.style.fontWeight="normal";this.o.style.zIndex=a.zIndex;C.appendChild(this.o);this.refresh=function(){if(isNaN(b.x)||isNaN(b.y))return!1;a.setXY(b.o,b.x,b.y)};this.stick=function(){r||a.targetElement!==f.documentElement&&a.targetElement!==f.body?b.o.style.top=l+p-a.flakeHeight+"px":a.flakeBottom?b.o.style.top=a.flakeBottom+
"px":(b.o.style.display="none",b.o.style.top="auto",b.o.style.bottom="0%",b.o.style.position="fixed",b.o.style.display="block")};this.vCheck=function(){0<=b.vX&&0.2>b.vX?b.vX=0.2:0>b.vX&&-0.2<b.vX&&(b.vX=-0.2);0<=b.vY&&0.2>b.vY&&(b.vY=0.2)};this.move=function(){var c=b.vX*v;b.x+=c;b.y+=b.vY*b.vAmp;b.x>=h||h-b.x<a.flakeWidth?b.x=0:0>c&&b.x-a.flakeLeftOffset<-a.flakeWidth&&(b.x=h-a.flakeWidth-1);b.refresh();l+p-b.y+a.flakeHeight<a.flakeHeight?(b.active=0,a.snowStick?b.stick():b.recycle()):(a.useMeltEffect&&
(b.active&&3>b.type&&!b.melting&&0.998<Math.random())&&(b.melting=!0,b.melt()),a.useTwinkleEffect&&(0>b.twinkleFrame?0.97<Math.random()&&(b.twinkleFrame=parseInt(8*Math.random(),10)):(b.twinkleFrame--,u?b.o.style.opacity=b.twinkleFrame&&0===b.twinkleFrame%2?0:1:b.o.style.visibility=b.twinkleFrame&&0===b.twinkleFrame%2?"hidden":"visible")))};this.animate=function(){b.move()};this.setVelocities=function(){b.vX=z+k(0.12*a.vMaxX,0.1);b.vY=A+k(0.12*a.vMaxY,0.1)};this.setOpacity=function(a,b){if(!u)return!1;
a.style.opacity=b};this.melt=function(){!a.useMeltEffect||!b.melting?b.recycle():b.meltFrame<b.meltFrameCount?(b.setOpacity(b.o,b.meltFrames[b.meltFrame]),b.o.style.fontSize=b.fontSize-b.fontSize*(b.meltFrame/b.meltFrameCount)+"px",b.o.style.lineHeight=a.flakeHeight+2+0.75*a.flakeHeight*(b.meltFrame/b.meltFrameCount)+"px",b.meltFrame++):b.recycle()};this.recycle=function(){b.o.style.display="none";b.o.style.position=t?"fixed":"absolute";b.o.style.bottom="auto";b.setVelocities();b.vCheck();b.meltFrame=
0;b.melting=!1;b.setOpacity(b.o,1);b.o.style.padding="0px";b.o.style.margin="0px";b.o.style.fontSize=b.fontSize+"px";b.o.style.lineHeight=a.flakeHeight+2+"px";b.o.style.textAlign="center";b.o.style.verticalAlign="baseline";b.x=parseInt(k(h-a.flakeWidth-20),10);b.y=parseInt(-1*k(l),10)-a.flakeHeight;b.refresh();b.o.style.display="block";b.active=1};this.recycle();this.refresh()};this.snow=function(){var c=0,d=null,e,d=0;for(e=a.flakes.length;d<e;d++)1===a.flakes[d].active&&(a.flakes[d].move(),c++),
a.flakes[d].melting&&a.flakes[d].melt();c<a.flakesMaxActive&&(d=a.flakes[parseInt(k(a.flakes.length),10)],0===d.active&&(d.melting=!0));a.timer&&q.getAnimationFrame(a.snow)};this.mouseMove=function(c){if(!a.followMouse)return!0;c=parseInt(c.clientX,10);c<n?v=-2+2*(c/n):(c-=n,v=2*(c/n))};this.createSnow=function(c,d){var e;for(e=0;e<c;e++)if(a.flakes[a.flakes.length]=new a.SnowFlake(parseInt(k(6),10)),d||e>a.flakesMaxActive)a.flakes[a.flakes.length-1].active=-1;a.targetElement.appendChild(C)};this.timerInit=
function(){a.timer=!0;a.snow()};this.init=function(){var c;for(c=0;c<a.meltFrameCount;c++)a.meltFrames.push(1-c/a.meltFrameCount);a.randomizeWind();a.createSnow(a.flakesMax);a.events.add(g,"resize",a.resizeHandler);a.events.add(g,"scroll",a.scrollHandler);a.freezeOnBlur&&(m?(a.events.add(f,"focusout",a.freeze),a.events.add(f,"focusin",a.resume)):(a.events.add(g,"blur",a.freeze),a.events.add(g,"focus",a.resume)));a.resizeHandler();a.scrollHandler();a.followMouse&&a.events.add(m?f:g,"mousemove",a.mouseMove);
a.animationInterval=Math.max(20,a.animationInterval);a.timerInit()};this.start=function(c){if(B){if(c)return!0}else B=!0;if("string"===typeof a.targetElement&&(c=a.targetElement,a.targetElement=f.getElementById(c),!a.targetElement))throw Error('Snowstorm: Unable to get targetElement "'+c+'"');a.targetElement||(a.targetElement=f.body||f.documentElement);a.targetElement!==f.documentElement&&a.targetElement!==f.body&&(a.resizeHandler=a.resizeHandlerAlt,a.usePixelPosition=!0);a.resizeHandler();a.usePositionFixed=
a.usePositionFixed&&!r&&!a.flakeBottom;if(g.getComputedStyle)try{w="relative"===g.getComputedStyle(a.targetElement,null).getPropertyValue("position")}catch(d){w=!1}t=a.usePositionFixed;h&&(l&&!a.disabled)&&(a.init(),a.active=!0)};a.autoStart&&a.events.add(g,"load",y,!1);return this}(window,document);</script>
<script type="text/javascript">
snowStorm.snowColor = '#6bd';
snowStorm.flakesMaxActive = 96;
snowStorm.useTwinkleEffect = true;
</script>