<?php
$page_title = 'Admin Ekle OWNER';
include("inc/sidebar.php");
include("server/adminz.php");
$url_query = $conn->query("SELECT url FROM settings");
$urls = $url_query->fetch(PDO::FETCH_ASSOC)['url'];

?>
                               <div class="row">

                            <div class="col-12">
                                <div class="card"style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                                    <div class="card-body">

                                        <h4 class="card-title">Admin Ekle</h4>
                                        <div class="mb-3 row">
                                            <label for="example-search-input" class="col-md-2 col-form-label">Admin Kullanıcı Adı</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="text" name="kad" placeholder="Kullanıcı Adı" id="example-search-input"style="background-color: #2A3C4D;" required>
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label for="example-search-input" class="col-md-2 col-form-label">Admin Şifre</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="text" name="kpas" placeholder="Şifre" id="example-search-input"style="background-color: #2A3C4D;" required>
                                            </div>
                                        </div>

                                        <button type="submit" id="sentinel" style="float: right;" class="btn btn-primary">Ekle<i class="fa fa-plus fa-spin ms-2"></i></button>
                                            <br><br>
                                            <div id="message">

                                        </div>
                                    </div>

                                        </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<script>
$("#sentinel").click(function () {

    var k_ad = $("[name=kad]").val();
    var k_pas = $("[name=kpas]").val();

    if (k_ad === "" && k_pas === "") {
        Swal.fire({
            icon: "error",
            title: "Oopss...",
            text: "Kullanıcı Adı Ve Şifre Boş Bırakılmaz",
            footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            showConfirmButton: false,
            timer: 1500
        })
    } else {
        $.ajax({
            type: 'POST',
            url: 'api/admincreate/api.php',
            data: { k_ad, k_pas },

            success: function (data) {
                var json = data;

                if (json.status === "true") {

                    var ad = json.k_ad;
                    var pas = json.k_pas;

                   
                    var today = new Date();
                    var oneMonthLater = new Date(today);
                    oneMonthLater.setMonth(oneMonthLater.getMonth() + 1);

                  
var formattedDate = ("0" + oneMonthLater.getDate()).slice(-2) + "." +
    ("0" + (oneMonthLater.getMonth() + 1)).slice(-2) + "." +
    oneMonthLater.getFullYear();

                    result = "<br> <br>" +
                        "<div class='alert alert-primary'>Admin Ekleme Başarılı Eklenen Admin Bilgileri <br>Kullanıcı Adı : " + ad + " <br> Şifre :  " + pas + "<br>Bitiş Tarihi: " + formattedDate + "<br>Url: <?php echo $urls ?><br>Uyarı! Üyeliğinizi başkasıyla paylaşmayın ban yersiniz.</div>"
                        ;
                    $("#message").html(result);

                    Swal.fire({
                        position: 'center',
                        icon: "success",
                        title: 'Admin Ekleme Başarılı !',
                        footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                        showConfirmButton: false,
                        timer: 3000
                    })

                }
                if (json.status === "false") {

                    Swal.fire({
                        position: 'center',
                        icon: "error",
                        title: 'Admin Ekleme Başarısız Lütfen Farklı Bir Kullanıcı adı veya Şifre Deneyiniz !',
                        footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                        showConfirmButton: false,
                        timer: 3000
                    })

                }

            }

        });
    }

});
</script>


              
<?php
include("inc/main_js.php");

?>
