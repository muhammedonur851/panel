<?php
$page_title = 'Sorgu Aktiflik Ayarları';
include("inc/sidebar.php");
include("server/adminz.php");
?>

<div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Sorgu Aktiflik Ayarları</h5>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered text-nowrap w-100">
                <thead>
                    <tr>
                        <th class="wd-20p">SORGU</th>
                        <th class="wd-20p">DURUM</th>
                        <th class="wd-20p">AKTİF ET</th>
                        <th class="wd-20p">PASİF ET</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
    $conn = new mysqli($servername, $username, $password, $db);

    if ($conn->connect_error) {
        die("Veritabanına bağlanılamadı: " . $conn->connect_error);
    }
//adsoyad

    if(isset($_POST['update_adsoyad']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adsoyad = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//adsoyadpasif

    if(isset($_POST['update_adsoyadpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adsoyad = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //adsoyadpro

    if(isset($_POST['update_adsoyadpro']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adsoyadpro = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//adsoyadpropasif

    if(isset($_POST['update_adsoyadpropasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adsoyadpro = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //tcsorgu

    if(isset($_POST['update_tc']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tc = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//tcsorgupasif

    if(isset($_POST['update_tcpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tc = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
//tcpro

    if(isset($_POST['update_tcpro']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tcpro = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//tcpropasif

    if(isset($_POST['update_tcpropasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tcpro = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
//aile

    if(isset($_POST['update_aile']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET aile = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ailepasif

    if(isset($_POST['update_ailepasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET aile = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }

    //ailepro

    if(isset($_POST['update_ailepro']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ailepro = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ailepropasif

    if(isset($_POST['update_ailepropasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ailepro = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //soyagac

    if(isset($_POST['update_soyagac']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET soyagac = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//soyagacpasif

    if(isset($_POST['update_soyagacpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET soyagac = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //din

    if(isset($_POST['update_din']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET din = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//dinpasif

    if(isset($_POST['update_dinpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET din = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //serino

    if(isset($_POST['update_serino']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET serino = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//serinopasif

    if(isset($_POST['update_serinopasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET serino = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //skt

    if(isset($_POST['update_skt']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET skt = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//sktpasif

    if(isset($_POST['update_sktpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET skt = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //sırano

    if(isset($_POST['update_sırano']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET sırano = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//sıranopasif

    if(isset($_POST['update_sıranopasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET sırano = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }

     //ciltno

    if(isset($_POST['update_ciltno']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ciltno = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ciltnopasif

    if(isset($_POST['update_ciltnopasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ciltno = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }

     //ailesırano

    if(isset($_POST['update_ailesırano']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ailesırano = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ailesıranopasif

    if(isset($_POST['update_ailesıranopasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ailesırano = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //adres

    if(isset($_POST['update_adres']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adres = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//adrespasif

    if(isset($_POST['update_adrespasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adres = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //evlilik

    if(isset($_POST['update_evlilik']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET evlilik = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//evlilikpasif

    if(isset($_POST['update_evlilikpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET evlilik = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ilac

    if(isset($_POST['update_ilac']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ilac = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ilacpasif

    if(isset($_POST['update_ilacpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ilac = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
    //muayene

    if(isset($_POST['update_muayene']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET muayene = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//muayenepasif

    if(isset($_POST['update_muayenepasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET muayene = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
    //rapor

    if(isset($_POST['update_rapor']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET rapor = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//raporpasif

    if(isset($_POST['update_raporpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET rapor = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
//sigorta

    if(isset($_POST['update_sigorta']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET sigorta = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//sigortapasif

    if(isset($_POST['update_sigortapasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET sigorta = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
       //okulno

    if(isset($_POST['update_okulno']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET okulno = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//okulnopasif

    if(isset($_POST['update_okulnopasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET okulno = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
       //uni

    if(isset($_POST['update_uni']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET uni = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//unipasif

    if(isset($_POST['update_unipasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET uni = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
    //eokulvesika

    if(isset($_POST['update_eokulvesika']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET eokulvesika = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//eokulvesikapasif

    if(isset($_POST['update_eokulvesikapasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET eokulvesika = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
    //arac

    if(isset($_POST['update_arac']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET arac = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//aracpasif

    if(isset($_POST['update_aracpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET arac = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
    //olum

    if(isset($_POST['update_olum']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET olum = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//olumpasif

    if(isset($_POST['update_olumpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET olum = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
  //tcgsm

    if(isset($_POST['update_tcgsm']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tcgsm = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//tcgsmpasif

    if(isset($_POST['update_tcgsmpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tcgsm = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
      //gsmtc

    if(isset($_POST['update_gsmtc']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET gsmtc = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//gsmtcpasif

    if(isset($_POST['update_gsmtcpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET gsmtc = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
      //tcgsmpro

    if(isset($_POST['update_tcgsmpro']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tcgsmpro = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//tcgsmpropasif

    if(isset($_POST['update_tcgsmpropasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET tcgsmpro = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
      //gsmtcv2

    if(isset($_POST['update_gsmtcv2']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET gsmtcv2 = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//gsmtcv2pasif

    if(isset($_POST['update_gsmtcv2pasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET gsmtcv2 = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //smsbomb

    if(isset($_POST['update_smsbomb']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET smsbomb = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//smsbombpasif

    if(isset($_POST['update_smsbombpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET smsbomb = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //operator

    if(isset($_POST['update_operator']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET operator = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//operatorpasif

    if(isset($_POST['update_operatorpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET operator = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //iban

    if(isset($_POST['update_iban']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET iban = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ibanpasif

    if(isset($_POST['update_ibanpasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET iban = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
     //ayakno

    if(isset($_POST['update_ayakno']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ayakno = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//ayaknopasif

    if(isset($_POST['update_ayaknopasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET ayakno = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }
 //eokulpro

    if(isset($_POST['update_eokulpro']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET eokulpro = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//eokulpropasif

    if(isset($_POST['update_eokulpropasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET eokulpro = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }

//adresv2

    if(isset($_POST['update_adresv2']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adresv2 = 1 WHERE id = $row_id";
        $conn->query($update_query);
    }
//adresv2pasif

    if(isset($_POST['update_adresv2pasif']) && isset($_POST['row_id'])) {
        $row_id = $_POST['row_id'];

      
        $update_query = "UPDATE durum SET adresv2 = 0 WHERE id = $row_id";
        $conn->query($update_query);
    }

    $query = "SELECT id, adsoyad, adsoyadpro FROM durum ORDER BY id "; 
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>AD SOYAD</td>
                   <td>";
            
            if ($durum['adsoyad'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_adsoyad' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_adsoyadpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";

            echo "<tr>
                    <td>AD SOYAD PRO</td>
                   <td>";
            
            if ($durum['adsoyadpro'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_adsoyadpro' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_adsoyadpropasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //tc
                  echo "<tr>
                    <td>TC</td>
                   <td>";
            
            if ($durum['tc'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_tc' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_tcpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
//tcpro
                  echo "<tr>
                    <td>TC PRO</td>
                   <td>";
            
            if ($durum['tcpro'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_tcpro' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_tcpropasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //aile
                  echo "<tr>
                    <td>AİLE</td>
                   <td>";
            
            if ($durum['aile'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_aile' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ailepasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //ailepro
                  echo "<tr>
                    <td>AİLE PRO</td>
                   <td>";
            
            if ($durum['ailepro'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_ailepro' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ailepropasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                   //soyagac
                  echo "<tr>
                    <td>SOYAĞAÇ</td>
                   <td>";
            
            if ($durum['soyagac'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_soyagac' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_soyagacpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //din
                  echo "<tr>
                    <td>DİN</td>
                   <td>";
            
            if ($durum['din'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_din' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_dinpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //serino
                  echo "<tr>
                    <td>SERİ NO</td>
                   <td>";
            
            if ($durum['serino'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_serino' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_serinopasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //skt
                  echo "<tr>
                    <td>SKT</td>
                   <td>";
            
            if ($durum['skt'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_skt' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_sktpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //sırano
                  echo "<tr>
                    <td>SIRA NO</td>
                   <td>";
            
            if ($durum['sırano'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_sırano' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_sıranopasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //ciltno
                  echo "<tr>
                    <td>CİLT NO</td>
                   <td>";
            
            if ($durum['ciltno'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_ciltno' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ciltnopasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //ailesırano
                  echo "<tr>
                    <td>AİLE SIRA NO</td>
                   <td>";
            
            if ($durum['ailesırano'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_ailesırano' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ailesıranopasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //adres
                  echo "<tr>
                    <td>ADRES</td>
                   <td>";
            
            if ($durum['adres'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_adres' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_adrespasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //adresv2
                  echo "<tr>
                    <td>ADRES V2</td>
                   <td>";
            
            if ($durum['adresv2'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_adresv2' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_adresv2pasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //evlilik
                  echo "<tr>
                    <td>EVLİLİK</td>
                   <td>";
            
            if ($durum['evlilik'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_evlilik' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_evlilikpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //ilac
                  echo "<tr>
                    <td>İLAÇ</td>
                   <td>";
            
            if ($durum['ilac'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_ilac' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ilacpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //muayene
                  echo "<tr>
                    <td>MUAYENE</td>
                   <td>";
            
            if ($durum['muayene'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_muayene' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_muayenepasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //rapor
                  echo "<tr>
                    <td>RAPOR</td>
                   <td>";
            
            if ($durum['rapor'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_rapor' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_raporpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //sigorta
                  echo "<tr>
                    <td>SİGORTA</td>
                   <td>";
            
            if ($durum['sigorta'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_sigorta' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_sigortapasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";

                   //okulno
                  echo "<tr>
                    <td>OKUL NO</td>
                   <td>";
            
            if ($durum['okulno'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_okulno' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_okulnopasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";

                   //uni
                  echo "<tr>
                    <td>UNİ</td>
                   <td>";
            
            if ($durum['uni'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_uni' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_unipasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
 //eokulvesika
                  echo "<tr>
                    <td>EOKUL VESİKA</td>
                   <td>";
            
            if ($durum['eokulvesika'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_eokulvesika' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_eokulvesikapasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //arac
                  echo "<tr>
                    <td>ARAÇ</td>
                   <td>";
            
            if ($durum['arac'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_arac' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_aracpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //olum
                  echo "<tr>
                    <td>ÖLÜM</td>
                   <td>";
            
            if ($durum['olum'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_olum' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_olumpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
//tcgsm
                  echo "<tr>
                    <td>TC GSM</td>
                   <td>";
            
            if ($durum['tcgsm'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_tcgsm' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_tcgsmpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //gsmtc
                  echo "<tr>
                    <td>GSM TC</td>
                   <td>";
            
            if ($durum['gsmtc'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_gsmtc' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_gsmtcpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //tcgsmpro
                  echo "<tr>
                    <td>TC GSM PRO</td>
                   <td>";
            
            if ($durum['tcgsmpro'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_tcgsmpro' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_tcgsmpropasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                 //gsmtcv2
                  echo "<tr>
                    <td>GSM TC V2</td>
                   <td>";
            
            if ($durum['gsmtcv2'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_gsmtcv2' value='AKİF ET'>
                        </form>
                    </td>
                      <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_gsmtcv2pasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //smsbomb
                  echo "<tr>
                    <td>SMS BOOMER</td>
                   <td>";
            
            if ($durum['smsbomb'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_smsbomb' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_smsbombpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //operator
                  echo "<tr>
                    <td>OPERATÖR</td>
                   <td>";
            
            if ($durum['operator'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_operator' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_operatorpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //iban
                  echo "<tr>
                    <td>İBAN</td>
                   <td>";
            
            if ($durum['iban'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_iban' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ibanpasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
                  //ayakno
                  echo "<tr>
                    <td>AYAK NO</td>
                   <td>";
            
            if ($durum['ayakno'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_ayakno' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_ayaknopasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";
 //eokulpro
                  echo "<tr>
                    <td>Eokul PRO</td>
                   <td>";
            
            if ($durum['eokulpro'] == 1) {
                echo '<img src="../img/aktif.png" width="15px">&nbsp;';
            } else {
                echo '<img src="../img/pasif.png" width="15px">&nbsp;';
            }

            echo "</td>
                    <td>
                        <form method='post' action=''>
                            <input type='hidden' name='row_id' value='" . $row['id'] . "'>
                            <input type='submit' name='update_eokulpro' value='AKİF ET'>
                        </form>
                    </td>
                     <td>
    <form method='post' action=''>
        <input type='hidden' name='row_id' value='" . $row['id'] . "'>
        <input type='submit' name='update_eokulpropasif' value='PASİF ET' class='pasif-button'>
    </form>
</td>
                 </tr>";

//end of story

        }
    } else {
        echo "<tr><td colspan='10'>Veri bulunamadı.</td></tr>";
    }

    $conn->close();
?>



            
        </tbody>
        
                                </table>

                            </div>
                           <style>
    input[type="submit"] {
        background-color: green;
        color: white;
        border: none;
        padding: 3px 6px;
        margin: 3px;
        cursor: pointer;
        border-radius: 3px;
    }

    input[type="submit"]:hover {
        background-color: darkpurple;
    }

    input[type="submit"]:active {
        background-color: white;
        color: purple;
    }

    input[type="submit"]:focus {
        background-color: white;
        color: purple;
    }
      input[type="submit"].pasif-button {
        background-color: red;
        color: white;
        border: none;
        padding: 3px 6px;
        margin: 3px;
        cursor: pointer;
        border-radius: 3px;
    }

    input[type="submit"].pasif-button:hover {
        background-color: darkred;
    }

    input[type="submit"].pasif-button:active {
        background-color: white;
        color: red;
    }

    input[type="submit"].pasif-button:focus {
        background-color: white;
        color: red;
    }
</style>

                         
                         
                            
                        </div></table>
                    </div>
                </div>
            </div>
        </div>
    </div>  </div>
        </div>  </div>
        </div>
</div>

<?php 

include("inc/main_js.php");

?>
</div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div>