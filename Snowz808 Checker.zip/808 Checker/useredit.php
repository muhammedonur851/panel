<?php
$page_title = 'Kullanıcı Düzenle ';
include("inc/sidebar.php");
include("server/adminkontrol.php");

$url_query = $conn->query("SELECT url FROM settings");
$urls = $url_query->fetch(PDO::FETCH_ASSOC)['url'];

if ($sentinel['role'] == 1) {


    $sql = "SELECT * from users WHERE id = ?";
    $sentinel_check = $conn->prepare($sql);
    $sentinel_check->execute([$_GET['id']]);
    $satir = $sentinel_check->fetch(PDO::FETCH_ASSOC);


   if ($satir['createdadmin'] != $sentinel['key_ad']) {
    header("Location: users.js");
    exit();
}


if ($satir['deleted'] == 1) {
    header("Location: users.js");
    exit();
}

    if (isset($_POST['gonder'])) {

        $keyad = $_POST['key_ad'];
        $kkey = $_POST['key_pas'];
        $bitistarih = $_POST['enddate'];
        $multi = $_POST['ipadres'];
        $guvenli = 1;
        $role = isset($_POST['role']) && $_POST['role'] == "on" ? '' : 2; 
        $id = htmlspecialchars($_GET['id']);

  
        $checkUsername = $conn->prepare("SELECT id FROM users WHERE key_ad = ? AND id != ?");
        $checkUsername->execute([$keyad, $id]);
        $existingUser = $checkUsername->fetch(PDO::FETCH_ASSOC);

   
        $checkPassword = $conn->prepare("SELECT id FROM users WHERE key_pas = ? AND id != ?");
        $checkPassword->execute([$kkey, $id]);
        $existingPassword = $checkPassword->fetch(PDO::FETCH_ASSOC);

  
        if (strlen($kkey) < 6) {
            $message = "<div class='alert alert-danger'>Hata : Şifre en az 6 karakter uzunluğunda olmalıdır!</div>";
        } elseif (strlen($keyad) > 15) {
            $message = "<div class='alert alert-danger'>Hata : Kullanıcı adı 15 karakterden uzun olamaz!</div>";
        } elseif ($existingUser) {
            $message = "<div class='alert alert-danger'>Hata : Bu kullanıcı adı zaten kullanımda, lütfen başka bir kullanıcı adı seçin!</div>";
        } elseif ($existingPassword) {
            $message = "<div class='alert alert-danger'>Hata : Lütfen başka bir şifre seçin!</div>";
        } else {
    
            if (!preg_match("/^\d{2}\.\d{2}.\d{4}$/", $bitistarih)) {
                $message = "<div class='alert alert-danger'>Hata : Geçerli bir tarih formatı girin (örn: 01.01.2023)</div>";
            } elseif (strtotime($bitistarih) <= strtotime(date('d.m.Y'))) {
                $message = "<div class='alert alert-danger'>Hata : Geçerli bir tarih girin (bugünden ileri bir tarih) </div>";
            } elseif (strtotime($bitistarih) > strtotime("+1 year")) {
                $message = "<div class='alert alert-danger'>Hata : Bitiş tarihi en fazla 1 yıl sonrası olabilir!</div>";
            } else {
         
                $guncelle = $conn->prepare("UPDATE users SET key_ad=?, key_pas=?, role=?, enddate=?, ipadres=?, security=?, endkey='0', owner='0', banned='0' WHERE id=? AND createdadmin=?");
                $guncelle->execute([$keyad, $kkey, $role, $bitistarih, $multi, $guvenli, $id, $sentinel['key_ad']]);

                $rowCount = $guncelle->rowCount();

                if ($rowCount > 0) {
                    $message = "<div class='alert alert-primary'>Bilgilendirme : Başarılı Kullanıcı Düzenlendi !  <br> Kullanıcı Adı : " . $keyad . " <br> Kullanıcı Şifresi : " . $kkey . " <br> Bitiş Tarihi : " . $bitistarih . " <br> Url: $urls <br> Uyarı! Üyeliğinizi başkasıyla paylaşmayın ban yersiniz.</div>";
                } else {
                    $message = "<div class='alert alert-danger'>Hata : Bu işlemi yapmak için yetkiniz yok!</div>";
                }
            }
        }
    }
}

$sql = "SELECT * from users WHERE id = ?";
$sentinel = $conn->prepare($sql);
$sentinel->execute([$_GET['id']]);
$satir = $sentinel->fetch(PDO::FETCH_ASSOC);
?>










                   <div class="row">
                            <div class="col-12">
                                <div class="card"style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                                    <div class="card-body">
        
                      <form method="POST">
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-name">Kullanıcı Adı</label>
                          <div class="col-sm-10">
                            <input type="text" style="background-color: #2A3C4D;" class="form-control" name="key_ad" id="basic-default-name" placeholder="" value="<?=$satir['key_ad']?>">
                          </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Kullanıcı Şifresi</label>
                          <div class="col-sm-10">
                            <input type="text"style="background-color: #2A3C4D;" class="form-control" name="key_pas" id="basic-default-company" placeholder="" value="<?=$satir['key_pas']?>">
                          </div>
                        </div>
                         <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Bitiş Tarihi</label>
                          <div class="col-sm-10">
                            <input type="text"style="background-color: #2A3C4D;" class="form-control" name="enddate"  id="basic-default-company" placeholder="" value="<?=$satir['enddate']?>">
                          </div>
                        </div>
                          </div>
                          <br><br><br>
                          <center>
                          <?php if ($satir['role'] == 2) { ?>
                            <h5 class="text-primary" style="float:left;">Üyelik Durumu : <h5 class="text-danger" style="float:left; margin-left: 5px;"> Premium</h5>
                         <?php } ?>
                         <br><br>
                    
                 
                        


                       </center>
                        </div>
                          
<div class="form-check mb-2">
    <div class="form-check mb-2">
        <input class="form-check-input" type="checkbox" name="role" id="exampleRadios1" <?php echo isset($_POST['role']) && $_POST['role'] == "on" ? 'checked' : ''; ?>>
        <label class="form-check-label" for="exampleRadios1">
            Freemium Üye
        </label>
    </div>
                                               
                        <br>

                        <br>
                        <div class="row justify-content-end">
                          <div class="col-sm-10">
                            <button type="submit" name="gonder" style="float:right;" class="btn btn-danger">Kaydet</button>
                          </div>
                          <br><br><br>
                         <?php echo $message; ?>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                         </div>
                         </div>
                         </div>


<?php
include("inc/main_js.php");

?>

