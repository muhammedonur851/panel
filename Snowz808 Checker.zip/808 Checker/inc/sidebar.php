<?php
include("server/control.php");
ini_set("display_errors", 0);
error_reporting(0);
date_default_timezone_set('Europe/Istanbul');

$panel_query = $conn->query("SELECT panel_name FROM settings");
$panel_name = $panel_query->fetch(PDO::FETCH_ASSOC)['panel_name'];

$social_query = $conn->query("SELECT social_link FROM settings");
$social_link = $social_query->fetch(PDO::FETCH_ASSOC)['social_link'];

$social_kısa = $conn->query("SELECT social_kısa FROM settings");
$socialkısa = $social_kısa->fetch(PDO::FETCH_ASSOC)['social_kısa'];

$yetkili_query = $conn->query("SELECT yetkili FROM settings");
$yetkili = $yetkili_query->fetch(PDO::FETCH_ASSOC)['yetkili'];

$yetkiliurl_query = $conn->query("SELECT yetkili_tg FROM settings");
$yetkili_tg = $yetkiliurl_query->fetch(PDO::FETCH_ASSOC)['yetkili_tg'];
?>
<!doctype html>
<!-- CODED BY SENTİNEL -->   <!-- NE ARIYON BURDA EŞŞEK HERİF-->
  <style>
    #example tbody tr:nth-child(even) {
        background-color: #2A3C4D; 
    }

    #example tbody tr:nth-child(odd) {
        background-color: #1C2833;
    }
	  #result-body tr:nth-child(even) {
    background-color: #2A3C4D;
  }

  #result-body tr:nth-child(odd) {
    background-color: #1C2833;
  }
   #example2 tbody tr:nth-child(even) {
        background-color: #2A3C4D; 
    }

    #example2 tbody tr:nth-child(odd) {
        background-color: #1C2833;
    }
</style>
<html lang="en" dir="ltr">
<head>
	<style>
    body {
        background-image: url('../img/bg.jpg');
        background-color: #1C2833; 
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }

    .card.img-card {
        background-color: #1C2833; 
         box-shadow: 0 0 10px rgba(0, 206, 209, 0.5); 
    }
	 .card{
        background-color: #1C2833; 
         box-shadow: 0 0 10px rgba(0, 206, 209, 0.5); 
    }
	  .card.mb-4 {
        background-color: #1C2833;
        box-shadow: 0 8px 16px rgba(0, 128, 128, 0.8);
    }
    
</style>
		<meta charset="UTF-8">
		<meta charset="ISO-8859-1">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="description" content="MERCY - Check">

				<link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />

               <title><?php echo $page_title ?> - <?php echo $panel_name; ?>er</title>

        <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />    
		
        <link href="assets/css/style.css" rel="stylesheet"/>
        <link href="assets/css/skin-modes.css" rel="stylesheet"/>
        <link href="assets/css/dark-style.css" rel="stylesheet"/>


        <link href="assets/css/sidemenu.css" rel="stylesheet" id="sidemenu">

        <link href="assets/plugins/p-scroll/perfect-scrollbar.css" rel="stylesheet" />

        <link href="assets/css/icons.css" rel="stylesheet"/>

        <link href="assets/plugins/sidebar/sidebar.css" rel="stylesheet">
		<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet"/>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<script src="https://rawgit.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />


        <link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/colors/color1.css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <link href="assets/switcher/css/switcher.css" rel="stylesheet">
        <link href="assets/switcher/demo.css" rel="stylesheet">

    </head>

	<body class="app sidebar-mini dark-mode">
		<div id="global-loader" style="background-color: #1C2833; ">
			<img src="assets/images/loader.svg" class="loader-img" alt="Loader">
		</div>
		<div class="page">
			<div class="page-main">
				<div class="app-sidebar__overlay" data-bs-toggle="sidebar"></div>
				<aside class="app-sidebar" style="box-shadow: 0 2px 4px rgba(0, 128, 128, 0.2), 0 -2px 4px rgba(0, 128, 128, 0.2), 2px 0 4px rgba(0, 128, 128, 0.2), -2px 0 4px rgba(0, 128, 128, 0.2);">
					<div class="side-header" style="background-color: #1C2833;" >
						
						<style> 
    .logo { 
      font-family: Arial, sans-serif; 
      font-size: 20px; 
      font-weight: bold; 
      color: #ffffff; 
	    background-color: #1C2833; 
    } 
	
  </style> 
		  <div class="logo"> 
			<a href="<?php echo $social_link; ?>"> 
    <?php echo $panel_name; ?>er   </a> 
  </div>			
                     </div>
					
					 <ul class="side-menu" style="background-color: #1C2833;">
						<strong><font face = "Verdana" ><?php echo $panel_name; ?></strong></font>
						<li class="bosluk"> </li>
					<a class="side-menu__item" data-bs-toggle="slide" href="check.js"><i class="side-menu__icon fa-solid fa-home"></i></i><span class="side-menu__label">Anasayfa</span></a>
					<?php
if ($sentinel['role'] == 1 || $sentinel['role'] == 2) {
    
?>
					<a class="side-menu__item" data-bs-toggle="slide" href="profile.js"><i class="side-menu__icon fa-solid fa-cog"></i></i><span class="side-menu__label">Hesabım</span></a>
					<?php
}
?>
					<a class="side-menu__item" data-bs-toggle="slide" href="vipsatış.js"><i class="side-menu__icon fa-solid fa-shopping-cart "></i></i><span class="side-menu__label">Paketler</span></a>
					
					<style>
					li.bosluk {
                    margin-top: 0.2cm; 
}</style> <li class="bosluk">
						<li class="bosluk"> </li>
						<strong><font face = "Verdana" >Sorgular</strong></font>
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-user"></i></i><span class="side-menu__label">Kişi Veri Sistemi</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
							<li><a href="adsoyad.js" class="slide-item"><?php if ($durum['adsoyad'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Ad Soyad Sorgu</a></li>
							<li><a href="aadsoyadpro.js" class="slide-item"><?php if ($durum['adsoyadpro'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Ad Soyad Pro &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
						    <li><a href="tc.js" class="slide-item"><?php if ($durum['tc'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>T.C Sorgu </a></li>
							<li><a href="tcpro.js" class="slide-item"><?php if ($durum['tcpro'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>T.C  Pro  &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							<li><a href="ailepre.js" class="slide-item"><?php if ($durum['aile'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Aile Sorgu </a></li>
							<li><a href="ailepro.js" class="slide-item"><?php if ($durum['ailepro'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Aile Pro &nbsp;<i class="fa-solid fa-star text-purple"></i> </a></li>
							<li><a href="sülalepre.js" class="slide-item"><?php if ($durum['soyagac'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Soyağaç Sorgu </a></li>
							<li><a href="din.js" class="slide-item"><?php if ($durum['din'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Din Sorgu  &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#kimlik"><i class="side-menu__icon fa-solid fa-id-card"></i><span class="side-menu__label">Kimlik Veri Sistemi </span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
						        <li><a href="serino.js" class="slide-item"><?php if ($durum['serino'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Seri No Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="skt.js" class="slide-item"><?php if ($durum['skt'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Kimlik Son Geçerlilik  &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="sırano.js" class="slide-item"><?php if ($durum['sırano'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Sıra No Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="ciltno.js" class="slide-item"><?php if ($durum['ciltno'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Cilt No Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="ailesıra.js" class="slide-item"><?php if ($durum['ailesırano'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Aile Sıra No Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#adres"><i class="side-menu__icon fa-solid fa-map-marker"></i><span class="side-menu__label">Güncel Adres</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								
								<li><a href="ikametgah.js" class="slide-item"><?php if ($durum['adres'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Adres Sorgu 2024 &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="adresv2.js" class="slide-item"><?php if ($durum['adresv2'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Adres Sorgu V2 &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							</ul>
						</li>
							<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#adres"><i class="side-menu__icon fa-solid fa-venus-mars"></i><span class="side-menu__label">Evlilik Sorgu</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								
								<li><a href="medenihal.js" class="slide-item"> <?php if ($durum['evlilik'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Evlilik Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							</ul>
						</li>

						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-medkit"></i></i><span class="side-menu__label">Sağlık Veri Sistemi</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="ilac.js" class="slide-item"><?php if ($durum['ilac'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>İlaç Sorgu&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="muayene.js" class="slide-item"><?php if ($durum['muayene'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Muayene Sorgu&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="rapor.js" class="slide-item"><?php if ($durum['rapor'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Rapor Sorgu&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>	
								<li><a href="sigorta.js" class="slide-item"><?php if ($durum['sigorta'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Sigorta Sorgu&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>	
					</ul>
						</li>
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-book"></i></i><span class="side-menu__label">Eğitim Veri Sistemi</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
							    <li><a href="eokul.js" class="slide-item"><?php if ($durum['okulno'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Okul No Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="eokulpro.js" class="slide-item"><?php if ($durum['eokulpro'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Eokul PRO&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="vesikas.js" class="slide-item"><?php if ($durum['eokulvesika'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Eokul Vesikalık Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="uni.js" class="slide-item"><?php if ($durum['uni'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Üniversite Mezun Sorgu&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								
					</ul>
						</li>	
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-picture-o"></i></i><span class="side-menu__label">Vesikalık Sorguları</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="vesika.js" class="slide-item"><?php if ($durum['eokulvesika'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Eokul Vesikalık Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							
								
					</ul>
						</li>
						
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-car"></i></i><span class="side-menu__label">Araç Sorguları</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="aracguncel.js" class="slide-item"><?php if ($durum['arac'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>TC'den Araç Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="aracgecmis.js" class="slide-item"><?php if ($durum['arac'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>TC'den Geçmiş Araç S. &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
					</ul>
						</li>	
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa fa-h-square"></i></i><span class="side-menu__label">Ölüm Durumu Sorgu</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="olumdurumu.js" class="slide-item"><?php if ($durum['olum'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Ölüm Durumu Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								
					</ul>
						</li>	
											
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-mobile-screen"></i><span class="side-menu__label">Telefon Veri Sistemi</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
						
							<li><a href="tcgsm.js" class="slide-item"><?php if ($durum['tcgsm'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>TC-GSM Sorgu </a></li>
							<li><a href="gsmtc.js" class="slide-item"><?php if ($durum['gsmtc'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>GSM-TC Sorgu</a></li>
							<li><a href="tcgsm23.js" class="slide-item"><?php if ($durum['tcgsmpro'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>TC-GSM PRO&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							<li><a href="gsmtcvip.js" class="slide-item"><?php if ($durum['gsmtcv2'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>GSM-TC V2&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							<li><a href="smsbomber.js" class="slide-item"><?php if ($durum['smsbomb'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>SMS Bomber&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							<li><a href="operator.js" class="slide-item"><?php if ($durum['operator'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Operator Sorgu&nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
							</ul>
						</li>
						
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-bars"></i><span class="side-menu__label">Ekstralar</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="cimer.js" class="slide-item"><?php if ($durum['cimer'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Cimer İhbar &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="iban.js" class="slide-item"><?php if ($durum['iban'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>İban Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>
								<li><a href="ayak.js" class="slide-item"><?php if ($durum['ayakno'] == 1) {echo '<img src="../img/aktif.png" width="8px">&nbsp;'; } else {echo '<img src="../img/pasif.png" width="8px">&nbsp;';}?>Ayak No Sorgu &nbsp;<i class="fa-solid fa-star text-purple"></i></a></li>	
							</ul>
						</li>
						<?php if ($sentinel['role'] == 1) { ?>
							<li class="bosluk"> </li>
							
							<strong><font face = "Verdana" >Admin</strong></font>
							<?php if ($sentinel['adminz'] == 1) { ?>
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-bolt"></i><span class="side-menu__label">Yetkili Menu</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="usercreateown.js" class="slide-item">Kullanıcı Ekle - Limitsiz</a></li>
								<li><a href="admincreate.js" class="slide-item">Admin Ekle</a></li>
								<li><a href="users2.js" class="slide-item">Kullanıcı Sil-Düzenle</a></li>
								<li><a href="sorgudurum.js" class="slide-item">Sorgu Aktiflik</a></li>
								
							</ul>
						</li>
							
						<?php } ?>
							<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-user-shield"></i><span class="side-menu__label">Bayi Menu</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
							
								<li><a href="usercreate.js" class="slide-item">Kullanıcı Ekle</a></li>
								<li><a href="users.js" class="slide-item">Kullanıcı Sil-Düzenle</a></li>
								
							</ul>
						</li>
							
						<?php } ?>

						<?php if ($sentinel['owner'] == 1) { ?>
							<li class="bosluk"> </li>
							
							<strong><font face = "Verdana" >Owner</strong></font>
							<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-hard-drive"></i><span class="side-menu__label">Owner Menu</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
							    <li><a href="usersowner.js" class="slide-item">Tüm Kullanıcılar</a></li>
							    <li><a href="adminmultilog.js" class="slide-item">Multi İzinleri</a></li>
								<li><a href="duyuru.js" class="slide-item">Duyuru Ekle</a></li>
								<li><a href="duyurular.js" class="slide-item">Duyuru Listesi</a></li>
								<li><a href="adminlist.js" class="slide-item">Admin Listesi</a></li>
								<li><a href="banned.js" class="slide-item">Ban Listesi</a></li>
								<li><a href="lastlogin.js" class="slide-item">Last Login</a></li>
							</ul>
						</li>
						<?php } ?>
							<?php if ($sentinel['adminz'] == 1) { ?>
						<li class="slide">
							<a class="side-menu__item" data-bs-toggle="slide" href="#"><i class="side-menu__icon fa-solid fa-database"></i><span class="side-menu__label">Log Kayıtları</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu">
								<li><a href="adminlog_2.js" class="slide-item">Giris Log</a></li>
								<li><a href="adminlogip.js" class="slide-item">Giris Log IP Search</a></li>
								<li><a href="sorgulog.jsowner" class="slide-item">Sorgu Log</a></li>
								<li><a href="sorgulogip.jsowner" class="slide-item">Sorgu Log IP Search</a></li>
								
							</ul>
						</li>
							
						<?php } ?>
						
						
					</ul>
				</aside>
	
				<div class="mobile-header" style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
					<div class="container-fluid" >
						<div class="d-flex">
							<a aria-label="Hide Sidebar" class="app-sidebar__toggle" data-bs-toggle="sidebar" href="#"></a>
							<a class="header-brand" href="index.html">
							
							</a>
							<div class="d-flex order-lg-2 ms-auto header-right-icons">

								<div class="dropdown profile-1" >
									<a href="#" data-bs-toggle="dropdown" class="nav-link pe-2 leading-none d-flex">
									<span>
    <img src="<?php echo empty($sentinel['img']) ? 'img/pp.png' : $sentinel['img']; ?>" alt="profile-user" class="avatar profile-user brround cover-image">
</span>
									</a>
									<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow" style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
										<div class="drop-heading">
											<div class="text-center">
												<h5 class="text-dark mb-0"><?=$sentinel['key_ad']?>	<?php
if ($sentinel['owner'] == 1) {
    $image = "img/role/owner.png";
} elseif ($sentinel['role'] == 1) {
    $image = "img/role/adminrole.png";
} elseif ($sentinel['role'] == 2) {
    $image = "img/role/premiumrole.png";
} else {
    $image = "img/role/freemium.png"; 
}


echo "<img src='$image' alt='rol_img' width='20' >";
?></h5>
												<small class="text-muted"><?php
if ($sentinel['owner'] == 1) {
    echo "OWNER";
} elseif ($sentinel['role'] == 1) {
    echo "Admin";
} elseif ($sentinel['role'] == 2) {
    echo "Premium";
} else {
    echo "Freemium"; 
}
?>
<br>
													<a href="profile.js">
											 <font class="text-primary"  >	Hesabım	</font></a>
												</small>
												
											</div>
										</div>
										<div class="dropdown-divider m-0"></div>
										<a class="dropdown-item" href="logout.js">
											<i class="dropdown-icon mdi  mdi-logout-variant"></i>Çıkış Yap
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="app-content">
					<div class="side-app">
					<div class="page-header"  style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">

		
						<div>
							<h1 class="page-title">   <a href="<?php echo $social_link; ?>"><font color="white"><i class="fa-brands fa-telegram"></i>&nbsp;<?php echo $socialkısa; ?> </a></h1></font>
						</div>

						<div class="d-flex  ms-auto header-right-icons header-search-icon">
								<div class="dropdown d-sm-flex">
									<div class="dropdown-menu header-search dropdown-menu-start">
										<div class="input-group w-100 p-2">
										</div>
									</div>
								</div>

								<div class="dropdown d-md-flex notifications">
									
									<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
										<div class="notifications-menu">
											
										</div>
										<div class="dropdown-divider"></div>
										
									</div>
								</div>
								<div class="dropdown d-md-flex message">
									<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow"style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
										<div class="message-menu">
										</div>
										<div class="dropdown-divider"></div>
									
									</div>
								</div>
								<div class="dropdown profile-1">
								<a href="#" data-bs-toggle="dropdown" class="nav-link pe-2 leading-none d-flex">
								<span>
    <img src="<?php echo empty($sentinel['img']) ? 'img/pp.png' : $sentinel['img']; ?>" alt="profile-user" class="avatar profile-user brround cover-image">
</span>
									</a>
									<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow"style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
										<div class="drop-heading">
											<div class="text-center">
												<h5 class="text-dark mb-0"><?=$sentinel["key_ad"]?>	<?php
if ($sentinel['owner'] == 1) {
    $image = "img/role/owner.png";
} elseif ($sentinel['role'] == 1) {
    $image = "img/role/adminrole.png";
} elseif ($sentinel['role'] == 2) {
    $image = "img/role/premiumrole.png";
} else {
    $image = "img/role/freemium.png"; 
}


echo "<img src='$image' alt='rol_img' width='23' >";
?></h5>
												<small class="text-muted">
												<?php
if ($sentinel['owner'] == 1) {
    echo "OWNER";
} elseif ($sentinel['role'] == 1) {
    echo "Admin";
} elseif ($sentinel['role'] == 2) {
    echo "Premium";
} else {
    echo "Freemium"; 
}
?>

												</small>
												<br>
												<a href="profile.js">
											 <font class="text-primary"  >	Hesabım	</font></a>
											</div>
										</div>
										<div class="dropdown-divider m-0"></div>
										<a class="dropdown-item" href="logout.js">
											<i class="dropdown-icon mdi  mdi-logout-variant"></i> Çıkış Yap
										</a>
									</div>
								</div>
								<div class="dropdown d-md-flex header-settings">
									
								</div>
							</div>
						</div>
		
<?php if ($sentinel['no_price'] != 1) { ?>
<!-- Chatra {literal} -->
<script>
    (function(d, w, c) {
        w.ChatraID = 'mo8LEzYJk5T7wnvJC';
        var s = d.createElement('script');
        w[c] = w[c] || function() {
            (w[c].q = w[c].q || []).push(arguments);
        };
        s.async = true;
        s.src = 'https://call.chatra.io/chatra.js';
        if (d.head) d.head.appendChild(s);
    })(document, window, 'Chatra');
</script>
<!-- /Chatra {/literal} -->
<?php } ?>