<footer class="footer"  style="background-color: #1C2833; box-shadow: 0 -4px 8px rgba(0, 128, 128, 0.5);">
				<div class="container">
					<div class="row align-items-center flex-row-reverse">
						<div class="col-md-12 col-sm-12 text-center">
							Copyright © 2024 <a href="<?php echo $social_link ?>"><strong><?php echo $panel_name ?> </strong></a> Developed by <a href="<?php echo $yetkili_tg ?>"> <strong><?php echo $yetkili ?> </strong>&nbsp;&nbsp;<i class="fa fa-code" aria-hidden="true"></i></a>
						</div>
					</div>
				</div>
			</footer>
        </div>
        <a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

        <script src="assets/js/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>


<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/plugins/rating/jquery.rating-stars.js"></script>

<script src="assets/plugins/input-mask/jquery.mask.min.js"></script>

<script src="assets/plugins/sidemenu/sidemenu.js"></script>

<script src="assets/switcher/js/switcher.js"></script>

<script src="assets/plugins/sidebar/sidebar.js"></script>

<script src="assets/plugins/p-scroll/perfect-scrollbar.js"></script>
<script src="assets/plugins/p-scroll/pscroll.js"></script>
<script src="assets/plugins/p-scroll/pscroll-1.js"></script>

    <script src="assets/plugins/chart/Chart.bundle.js"></script>
    <script src="assets/plugins/chart/utils.js"></script>

    <script src="assets/plugins/charts-c3/d3.v5.min.js"></script>
    <script src="assets/plugins/charts-c3/c3-chart.js"></script>

    <script src="assets/js/index3.js"></script>

    <script src="assets/plugins/peitychart/jquery.peity.min.js"></script>
    <script src="assets/plugins/peitychart/peitychart.init.js"></script>


<script src="assets/js/custom.js"></script>

<script src="assets/js/color-change.js"></script>
</body>
</html>
