<?php

header("Location: login.js");

?>