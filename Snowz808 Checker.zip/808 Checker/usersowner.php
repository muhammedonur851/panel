<?php 
$page_title = 'ALL Kullanıcılar Owner';
include("inc/sidebar.php");
include("server/owner.php");


if ($sentinel['role'] == 1) {

    if (isset($_GET['sil'])) {
        $sil = htmlspecialchars($_GET['sil']);
        $sorgu = $conn->query("SELECT * FROM users WHERE id='$sil'")->fetch();
        if ($sorgu['role'] != 1) {
            $silsentinel = $conn->prepare("DELETE FROM users WHERE id=? OR role='2' AND role='3'");
            $silsentinel->execute([
                $_GET['sil']
            ]);
            header("Location: usersowner.js");
        }else{
            header("Location: usersowner.js");
        }
      
    }
    if (isset($_GET['aktifet'])) {
    $aktifet = htmlspecialchars($_GET['aktifet']);
    $sorgu2 = $conn->query("SELECT * FROM users WHERE id='$aktifet'")->fetch();

    if ($sorgu2['role'] != 1) {
        $aktifetsentinel = $conn->prepare("UPDATE users SET deleted = 0 WHERE id = ?");
        $aktifetsentinel->execute([$aktifet]);
        header("Location: usersowner.js");
    } else {
        header("Location: usersowner.js");
    }
} 
 if (isset($_GET['bankaldır'])) {
    $bankaldır = htmlspecialchars($_GET['bankaldır']);
    $sorgu3 = $conn->query("SELECT * FROM users WHERE id='$bankaldır'")->fetch();

    if ($sorgu3['role'] != 1) {
        $bankaldırsentinel = $conn->prepare("UPDATE users SET banned = 0 WHERE id = ?");
        $bankaldırsentinel->execute([$bankaldır]);
        header("Location: usersowner.js");
    } else {
        header("Location: usersowner.js");
    }
} 
}

?>
   
          
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Tüm Kullanıcılar</h5>
                     
                    </div>

                <div class="card-body">
   
       
                <div class="table-responsive">
    <form action="usersowner.js" method="get">
        <input type="text" name="search" placeholder="Kullanıcı adı" class="form-control"style="background-color: #2A3C4D;">
        <button type="submit" class="btn w-sm btn-primary waves-effect waves-light">Ara</button>
    </form>
    <br>
    <div class="table-responsive">
    <table id="example" class="table table-striped table-bordered text-nowrap w-100">
        <thead>
            <tr>
                <th class="wd-20p">Durum</th>
                <th class="wd-20p">Kullanıcı Adı</th>
                <th class="wd-20p">Şifre</th>
                <th class="wd-20p">IP Adresi</th>
                <th class="wd-20p">Bitiş Tarihi</th>
                <th class="wd-20p">Oluşturulan Tarih</th>
                <th class="wd-20p">Oluşturan</th>
                <th class="wd-20p">Üyelik</th>
                <th class="wd-20p">Sil</th>
                <th class="wd-20p">Düzenle</th>
            </tr>
        </thead>
        <tbody>
        <?php
$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}

$rows_per_page = 100;
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $rows_per_page;

$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = !empty($search_query) ? "WHERE key_ad LIKE '%$search_query%'" : '';

$query = "SELECT key_ad, key_pas, security, enddate, createddate, createdadmin, role, banned, id, endkey,deleted,owner,adminz FROM users $search_condition ORDER BY id DESC LIMIT $offset, $rows_per_page";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>";
        if ($row['deleted'] == 1) {
            echo 'Silinmiş';
        } elseif ($row['endkey'] == 1) {
            echo 'Süresi Bitmiş';
        } elseif ($row['banned'] == 1) {
            echo 'Banlı';
        } else {
            echo 'Aktif';
        }
        echo "</td>
                <td>" . $row['key_ad'] . "</td>
                <td>" . $row['key_pas'] . "</td>
                <td>";
        if ($row['security'] == 1) {
            echo 'Güvenilir Üye';
        } else {
            echo $row['ipadres'];
        }
        echo "</td>
                <td>";
        if ($row['enddate'] == 0) {
            echo 'Sınırsız Üye';
        } else {
            echo $row['enddate'];
        }
        echo "</td>
                <td>" . $row['createddate'] . "</td>
                <td>" . $row['createdadmin'] . "</td>
                <td>";
                if ($row['role'] == 2) {
                    echo 'Premium';
                      } elseif ($row['owner'] == 1) {
                    echo 'OWNER';
                     } elseif ($row['adminz'] == 1) {
                    echo 'Yetkili Admin';
                } elseif ($row['role'] == 1) {
                    echo 'Admin';
                } elseif ($row['banned'] == 1) {
                    echo 'Banlı';
                } else {
                    echo 'Freemium'; 
                }

       echo "</td>
            <td><a href='?sil=" . $row['id'] . "' onclick=\"return confirm('Silinsin mi?')\" class='badge rounded-pill bg-danger mt-2'>Sil</a></td>
            <td><a href='usereditowner.js?id=" . $row['id'] . "' class='badge rounded-pill bg-danger mt-2'>Düzenle</a></td>";
    if ($row['deleted'] == 1) {
        echo "<td><a href='?aktifet=" . $row['id'] . "' onclick=\"return confirm('Aktif etmek istediğinize emin misiniz?')\" class='badge rounded-pill bg-success mt-2'>Aktif et</a></td>";
    }
if ($row['banned'] == 1) {
        echo "<td><a href='?bankaldır=" . $row['id'] . "' onclick=\"return confirm('Banı kaldırmak istediğinize emin misiniz?')\" class='badge rounded-pill bg-success mt-2'>Ban Kaldır</a></td>";
    }
    echo "</tr>";
    }
    
} else {
    echo "<tr><td colspan='10'>Veri bulunamadı.</td></tr>";
}

$conn->close();
?>


            
        </tbody>
        
                                </table>

                            </div>
                            <style>
    
        button {
            background-color: purple;
            color: white;
            border: none;
            padding: 5px 10px;
            margin: 5px;
            cursor: pointer;
            border-radius: 5px;
        }

       
        button:hover {
            background-color: darkpurple;
        }

       
        button:active {
            background-color: white;
            color: purple;
        }

      
        button:focus {
            background-color: white;
            color: purple;
        }
    </style>
                         
                            <button id="previousPageButton" onclick="navigateToPreviousPage()">Önceki</button>
<span id="currentPageSpan">Sayfa 1</span>
<button id="nextPageButton" onclick="navigateToNextPage()">Sonraki</button>

<script>

    function getCurrentPageNumber() {
        const urlParams = new URLSearchParams(window.location.search);
        return parseInt(urlParams.get('page')) || 1;
    }

 
    function updateCurrentPageNumber() {
        const currentPage = getCurrentPageNumber();
        document.getElementById('currentPageSpan').textContent = `Sayfa ${currentPage}`;
    }


    function navigateToPreviousPage() {
        const currentPage = getCurrentPageNumber();
        if (currentPage > 1) {
            const previousPage = currentPage - 1;
            window.location.href = `?page=${previousPage}`;
        }
    }


    function navigateToNextPage() {
        const currentPage = getCurrentPageNumber();
        const nextPage = currentPage + 1;
        window.location.href = `?page=${nextPage}`;
    }

  
    window.addEventListener('load', updateCurrentPageNumber);
</script>
                            
                        </div></table>
                    </div>
                </div>
            </div>
        </div>
    </div>  </div>
        </div>  </div>
        </div>
</div>

<?php 

include("inc/main_js.php");

?>
</div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div>