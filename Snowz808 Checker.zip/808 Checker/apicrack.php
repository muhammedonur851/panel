<?php


$tc = $_GET["tc"];


$url ="" . $tc;


$json = file_get_contents($url);
$DATA = json_decode($json, true);




header('Content-Type: application/json; charset=utf-8');
echo json_encode($DATA, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

?>
