<?php
$page_title = 'Banned OWNER';
include("inc/sidebar.php");
include("server/owner.php");

$sql = "SELECT * FROM users WHERE banned='1'";
$anger = $conn->query($sql);

if ($sentinel['role'] == 1) {
    
    if (isset($_GET['bankaldir'])) {
        $banla = htmlspecialchars($_GET['bankaldir']);
        $banlsentinel = $conn->prepare("UPDATE users SET banned='0' WHERE id=?");
        $banlsentinel->execute([
            $_GET['bankaldir']
        ]);
    
        header("Location: banned.js");
    }
}

$recordsPerPage = 100;


$page = isset($_GET['page']) ? intval($_GET['page']) : 1;


$offset = ($page - 1) * $recordsPerPage;


$sql = "SELECT * FROM users WHERE banned='1'  LIMIT :offset, :limit";
$anger = $conn->prepare($sql);
$anger->bindValue(':offset', $offset, PDO::PARAM_INT);
$anger->bindValue(':limit', $recordsPerPage, PDO::PARAM_INT);
$anger->execute();


$totalRecords = $conn->query("SELECT COUNT(*) FROM users WHERE banned='1'")->fetchColumn();
$totalPages = ceil($totalRecords / $recordsPerPage);

?>

<div class="row">
							<div class="col-md-12 col-lg-12">
								<div class="card"style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
									<div class="card-header">
										<h3 class="card-title">Kullanıcılar</h3>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="example" class="table table-striped table-bordered text-nowrap w-100">
												<thead>
													<tr>
														<th class="wd-20p">Kullanıcı Adı</th>
                                                        <th class="wd-20p">Şifre</th>
                                                        <th class="wd-20p">IP Adresi</th>
                                                        <th class="wd-20p">Bitiş Tarihi</th>
                                                        <th class="wd-20p">Oluşturulan Tarih</th>
                                                        <th class="wd-20p">Oluşturan</th>
                                                        <th class="wd-20p">Üyelik</th>
                                                        <th class="wd-20p">Ban Kaldır</th>

													</tr>
												</thead>
												<tbody>
                                               <?php while ($users = $anger->fetch(PDO::FETCH_ASSOC)) { ?>
                                                <tr>
                                            <td><?=$users['key_ad']?></td>
                                            <td><?=$users['key_pas']?></td>
                                            <?php if ($users['security'] == 1) { ?>
                                                <td>Güvenilir Üye</td>
                                           <?php }else{ ?>
                                        <td><?=$users['ipadres']?></td>
                                         <?php } ?>
                                         <?php if ($users['enddate'] == 0) { ?>
                                            <td>Sınırsız Üye</td>
                                        <?php }else{ ?>
                                            <td><?=$users['enddate']?></td>
                                        <?php } ?>
                                        <td><?=$users['createddate']?></td>
                                        <td><?=$users['createdadmin']?></td>
                                        <?php if ($users['role'] == 0) { ?>
                                            <td>Freemium</td>
                                       <?php }elseif ($users['role'] == 2) { ?>
                                        <td>Premium</td>
                                      <?php } ?>
                                       <td><a href="?bankaldir=<?=$users['id']?>" onclick="return confirm('Yasak Kaldırılsınmı ?')" class="badge rounded-pill  bg-danger mt-2">Ban Kaldır</a></td>
                                       </tr>
                                               <?php } ?>
												</tbody>
											</table>
										</div>
                                          
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++) {
                        $activeClass = ($i === $page) ? 'active' : '';
                        echo '<a class="page-link ' . $activeClass . '" href="?page=' . $i . '">' . $i . '</a>';
                    } ?>
          			</div>
									</div>
								</div>
							</div>
						</div>
                   </div>
              </div>
<?php
include("inc/main_js.php");
?>
