<?php

header("Location: loginxpremium.decart");

?>