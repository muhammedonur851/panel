-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 11 May 2024, 11:31:36
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `mercy`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin_limitor`
--

CREATE TABLE `admin_limitor` (
  `id` int(11) NOT NULL,
  `kullanici_adi` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `limit_deger` int(11) NOT NULL,
  `tarih` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `durum`
--

CREATE TABLE `durum` (
  `id` int(11) NOT NULL,
  `adsoyad` text NOT NULL,
  `adsoyadpro` text NOT NULL,
  `tc` text NOT NULL,
  `tcpro` text NOT NULL,
  `aile` text NOT NULL,
  `ailepro` text NOT NULL,
  `soyagac` text NOT NULL,
  `din` text NOT NULL,
  `serino` text NOT NULL,
  `skt` text NOT NULL,
  `sırano` text NOT NULL,
  `ciltno` text NOT NULL,
  `ailesırano` text NOT NULL,
  `adres` text NOT NULL,
  `evlilik` text NOT NULL,
  `ilac` text NOT NULL,
  `muayene` text NOT NULL,
  `rapor` text NOT NULL,
  `sigorta` text NOT NULL,
  `okulno` text NOT NULL,
  `uni` text NOT NULL,
  `eokulvesika` text NOT NULL,
  `arac` text NOT NULL,
  `olum` text NOT NULL,
  `tcgsm` text NOT NULL,
  `gsmtc` text NOT NULL,
  `tcgsmpro` text NOT NULL,
  `gsmtcv2` text NOT NULL,
  `smsbomb` text NOT NULL,
  `operator` text NOT NULL,
  `cimer` text NOT NULL,
  `iban` text NOT NULL,
  `ayakno` text NOT NULL,
  `eokulpro` text NOT NULL,
  `adresv2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `durum`
--

INSERT INTO `durum` (`id`, `adsoyad`, `adsoyadpro`, `tc`, `tcpro`, `aile`, `ailepro`, `soyagac`, `din`, `serino`, `skt`, `sırano`, `ciltno`, `ailesırano`, `adres`, `evlilik`, `ilac`, `muayene`, `rapor`, `sigorta`, `okulno`, `uni`, `eokulvesika`, `arac`, `olum`, `tcgsm`, `gsmtc`, `tcgsmpro`, `gsmtcv2`, `smsbomb`, `operator`, `cimer`, `iban`, `ayakno`, `eokulpro`, `adresv2`) VALUES
(1, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `duyuru`
--

CREATE TABLE `duyuru` (
  `id` int(11) NOT NULL,
  `duyuruatan` text NOT NULL,
  `atılanduyuru` text NOT NULL,
  `tarih` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_adres`
--

CREATE TABLE `limit_adres` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_arac`
--

CREATE TABLE `limit_arac` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_cinsiyet`
--

CREATE TABLE `limit_cinsiyet` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_death`
--

CREATE TABLE `limit_death` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_din`
--

CREATE TABLE `limit_din` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_ilac`
--

CREATE TABLE `limit_ilac` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_isyeri`
--

CREATE TABLE `limit_isyeri` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_medenihal`
--

CREATE TABLE `limit_medenihal` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_muayene`
--

CREATE TABLE `limit_muayene` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_rapor`
--

CREATE TABLE `limit_rapor` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_serino`
--

CREATE TABLE `limit_serino` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_skt`
--

CREATE TABLE `limit_skt` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_tapu`
--

CREATE TABLE `limit_tapu` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `limit_tcgsm2023`
--

CREATE TABLE `limit_tcgsm2023` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `query_date` date NOT NULL,
  `query_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `key_ad` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_pas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_time` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `logout`
--

CREATE TABLE `logout` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `logout_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `log_sorgu`
--

CREATE TABLE `log_sorgu` (
  `id` int(11) NOT NULL,
  `user` text CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `type` text CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `log` text CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `ip` text NOT NULL,
  `zaman` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `multiban`
--

CREATE TABLE `multiban` (
  `id` int(11) NOT NULL,
  `key_ad` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_pas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `panel_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `social_link` text NOT NULL,
  `social_kısa` text NOT NULL,
  `url` text NOT NULL DEFAULT '0',
  `yetkili` text NOT NULL,
  `yetkili_tg` text NOT NULL,
  `haftalik` text NOT NULL,
  `aylik` text NOT NULL,
  `3aylik` text NOT NULL,
  `yillik` text NOT NULL,
  `Bayilik` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `settings`
--

INSERT INTO `settings` (`id`, `panel_name`, `social_link`, `social_kısa`, `url`, `yetkili`, `yetkili_tg`, `haftalik`, `aylik`, `3aylik`, `yillik`, `Bayilik`) VALUES
(1, '808 Check', 'https://t.me/mafia8088', 't.me/mafia8088', 'https://pubsckulanmayın.net', 'BOZO808', 'https://t.me/mafia8088', '150', '250', '500', '1000', '1500');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sorgu_query`
--

CREATE TABLE `sorgu_query` (
  `count` text CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `sorgu_query`
--

INSERT INTO `sorgu_query` (`count`) VALUES
('10');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `key_ad` text NOT NULL,
  `key_pas` text NOT NULL,
  `role` text NOT NULL,
  `createddate` text NOT NULL,
  `enddate` text NOT NULL,
  `ipadres` text NOT NULL,
  `security` text NOT NULL,
  `endkey` text NOT NULL,
  `owner` text NOT NULL,
  `banned` text NOT NULL,
  `deleted` text NOT NULL,
  `createdadmin` text NOT NULL,
  `img` text NOT NULL,
  `adminz` text NOT NULL,
  `tapu` text NOT NULL,
  `no_log` text NOT NULL,
  `last_login` text NOT NULL,
  `no_price` text NOT NULL,
  `limitor` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `key_ad`, `key_pas`, `role`, `createddate`, `enddate`, `ipadres`, `security`, `endkey`, `owner`, `banned`, `deleted`, `createdadmin`, `img`, `adminz`, `tapu`, `no_log`, `last_login`, `no_price`, `limitor`) VALUES
(1, '1', '1', '1', '', '0', '1', '1', '', '1', '', '', '', '', '1', '', '1', '2024-05-11 12:26:29', '', '');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin_limitor`
--
ALTER TABLE `admin_limitor`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `durum`
--
ALTER TABLE `durum`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `duyuru`
--
ALTER TABLE `duyuru`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `limit_adres`
--
ALTER TABLE `limit_adres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_arac`
--
ALTER TABLE `limit_arac`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_cinsiyet`
--
ALTER TABLE `limit_cinsiyet`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_death`
--
ALTER TABLE `limit_death`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_din`
--
ALTER TABLE `limit_din`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_ilac`
--
ALTER TABLE `limit_ilac`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_isyeri`
--
ALTER TABLE `limit_isyeri`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_medenihal`
--
ALTER TABLE `limit_medenihal`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_muayene`
--
ALTER TABLE `limit_muayene`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_rapor`
--
ALTER TABLE `limit_rapor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_serino`
--
ALTER TABLE `limit_serino`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_skt`
--
ALTER TABLE `limit_skt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_tapu`
--
ALTER TABLE `limit_tapu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `limit_tcgsm2023`
--
ALTER TABLE `limit_tcgsm2023`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_name`,`query_date`);

--
-- Tablo için indeksler `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `logout`
--
ALTER TABLE `logout`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `log_sorgu`
--
ALTER TABLE `log_sorgu`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `multiban`
--
ALTER TABLE `multiban`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`panel_name`,`social_link`) USING HASH;

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin_limitor`
--
ALTER TABLE `admin_limitor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `durum`
--
ALTER TABLE `durum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `duyuru`
--
ALTER TABLE `duyuru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_adres`
--
ALTER TABLE `limit_adres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_arac`
--
ALTER TABLE `limit_arac`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_cinsiyet`
--
ALTER TABLE `limit_cinsiyet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_death`
--
ALTER TABLE `limit_death`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_din`
--
ALTER TABLE `limit_din`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_ilac`
--
ALTER TABLE `limit_ilac`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_isyeri`
--
ALTER TABLE `limit_isyeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_medenihal`
--
ALTER TABLE `limit_medenihal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_muayene`
--
ALTER TABLE `limit_muayene`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_rapor`
--
ALTER TABLE `limit_rapor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_serino`
--
ALTER TABLE `limit_serino`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_skt`
--
ALTER TABLE `limit_skt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_tapu`
--
ALTER TABLE `limit_tapu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `limit_tcgsm2023`
--
ALTER TABLE `limit_tcgsm2023`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `logout`
--
ALTER TABLE `logout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `log_sorgu`
--
ALTER TABLE `log_sorgu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `multiban`
--
ALTER TABLE `multiban`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
