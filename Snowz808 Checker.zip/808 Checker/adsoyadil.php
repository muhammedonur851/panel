<?php 
$page_title = 'Ad Soyad Pro';
include("inc/sidebar.php");
include("server/vipkontrol.php");
?>
  <style>
#btnIndir {
    float: right;
}
  </style>
    <div class="row">
        <div class="col-xl">
            <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Ad Soyad Pro</h5>
                    <small class="text-primary float-end">Lütfen Sorgulanacak Kişinin Ad, Soyad, İl Bilgisini Giriniz.</small>
                </div>

                <div class="card-body">
                    <p><i class="fa fa-info-circle text-primary"></i>&nbsp;Bu çözümde soyadını bilmediğiniz kişileri Ad ve İl bilgisi girerek bulabilirsiniz.</p>
                    <form id="adsoyadil-form">
                        <div class="mt-0">
                            <div class="row">
                               
                                <div class="col-xl-6">
                                    <div class="mb-2">
                                        <label for="cleave-delimiters" class="form-label">Ad</label>
                                        <input type="text" class="form-control" name="ad" id="basic-default-fullname" placeholder="Ahmet" style="background-color: #2A3C4D;"required="required">

                                        <label for="cleave-delimiters" class="form-label">Soyad</label>
                                        <input type="text" class="form-control" name="soyad" id="basic-default-fullname" placeholder="Yıldız"style="background-color: #2A3C4D;">

                                        <label for="cleave-delimiters" class="form-label">İl</label>
                                        <input type="text" class="form-control" name="il" id="basic-default-fullnames" placeholder="İzmir"style="background-color: #2A3C4D;" required="required">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" id="btnSentinel" name="adsoyadsorgu" class="btn w-sm btn-primary waves-effect waves-light"><i class="fa fa-search"></i>&nbsp;Sorgula</button>
                        &nbsp;   <button type="button" id="btnKopyala" class="btn w-sm btn-secondary waves-effect waves-light"><i class="fa fa-copy"></i>&nbsp;Kopyala</button>
                         </form>
                           &nbsp;<button id="btnIndir" class="btn btn-success"><i class="fa fa-download"></i>&nbsp;İndir</button>
                   
      <br>      <br>
                    
                    <div class="table-responsive">
                        <table id="result-table" class="table table-striped table-bordered text-nowrap w-100">
                            <thead>
                                <tr>
                                    <th>TC</th>
                                    <th>Adı</th>
                                    <th>Soyadı</th>
                                    <th>Doğum Tarihi</th>
                                    <th>Nufus İl</th>
                                    <th>Nufus İlçe</th>
                                    <th>Anne Adı</th>
                                    <th>Anne TC</th>
                                    <th>Baba Adı</th>
                                    <th>Baba TC</th>
                                    <th>Uyruk</th>
                                </tr>
                            </thead>
                            <tbody id="result-body">
                              
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
      <script type="text/javascript">
    $("#btnIndir").click(function () {
        var resultTable = document.getElementById('result-table');

        if (resultTable.rows.length === 0) {
            alert("No data to download.");
            return;
        }

        html2pdf(resultTable, {
            margin: 10,
            filename: 'SorguSonuc_<?php echo $panel_name; ?>er.pdf',
            image: { type: 'jpeg', quality: 0.98, width: 500, height: 600 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'mm', format: 'a2', orientation: 'portrait', margin: 10 },
            include: ['#result-table th:nth-child(1)', '#result-table td:nth-child(1)', '#result-table th:nth-child(2)', '#result-table td:nth-child(2)'] 
        }).from(resultTable).save();
    });
</script>



  <script>
  
    const kopyalaButton = document.getElementById('btnKopyala');


    kopyalaButton.addEventListener('click', function () {
       
        const resultTable = document.getElementById('result-table');


        const range = document.createRange();
        range.selectNode(resultTable);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);

      
        try {
            const successful = document.execCommand('copy');
            const message = successful ? 'Tablo başarıyla kopyalandı.' : 'Tablo kopyalanamadı. Tarayıcınızı güncelleyin veya izin verin.';
            Swal.fire({
                title: successful ? 'Başarılı' : 'Hata',
                text: message,
                icon: successful ? 'success' : 'error',
            });
        } catch (err) {
            console.error('Kopyalama Hatası:', err);
            Swal.fire({
                title: 'Hata',
                text: 'Tablo kopyalanırken bir hata oluştu.',
                icon: 'error',
            });
        }

     
        window.getSelection().removeAllRanges();
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('adsoyadil-form');
        const resultBody = document.getElementById('result-body');
        let lastRequestTime = 0;

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            
            const currentTime = new Date().getTime();
            const timeSinceLastRequest = currentTime - lastRequestTime;

            if (timeSinceLastRequest < 5000) {
                     Swal.fire({
        icon: "warning",
        title: "Çok hızlı sorgulama yapıyorsun!",
        text: "Lütfen 5 saniye bekle.",
        showConfirmButton: false,
        timer: 5000,  
        timerProgressBar: true 
    });
    return;
}

            lastRequestTime = currentTime;

            const formData = new FormData(form);

            Swal.fire({
                imageUrl: 'img/sorgulaniyor.gif',
                imageHeight: 100,
                title: 'Sorgu Çözümü Başladı !',
                text: 'Sorgulanıyor...',
                footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                showConfirmButton: false,
            });

            fetch('api/adsoyadil/api.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                Swal.close();

                if (data.status === 'success') {
                    resultBody.innerHTML = '';

                    data.data.forEach(item => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${item.TC}</td>
                            <td>${item.ADI}</td>
                            <td>${item.SOYADI}</td>
                            <td>${item.DOGUMTARIHI}</td>
                            <td>${item.NUFUSIL}</td>
                            <td>${item.NUFUSILCE}</td>
                            <td>${item.ANNEADI}</td>
                            <td>${item.ANNETC}</td>
                            <td>${item.BABAADI}</td>
                            <td>${item.BABATC}</td>
                            <td>${item.UYRUK}</td>
                        `;
                        resultBody.appendChild(row);
                    });
                } else if (data.status === 'error') {
                    Swal.fire({
                        title: 'Bu çözüm bakımdadır!',
                        text: data.message,
                        icon: 'info',
                        footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);

                Swal.fire({
                    title: 'Oopss...',
                    text: 'Sorguladığınız Kişiye Ait Bir Bilgi Bulunamadı.',
                    icon: 'error',
                    footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                });
            });
        });
    });
</script>

    </tbody>
                                </table>
                            </div>
                        </div></table>
                    </div>
                </div>
            </div>
        </div>
    </div>  </div>
        </div>  </div>
        </div>
</div>

<?php 

include("inc/main_js.php");

?>
</div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div>
