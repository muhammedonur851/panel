<?php
ini_set("display_errors", 0);
error_reporting(0);

$tc = htmlspecialchars($_POST['tc']);

if (!empty($tc)) {
    $apiUrl = "http://api.xyz/apiservicexsent/tcgsmv2/tcgsmsent.php?auth=sent&tc=" . urlencode($tc);
    $apiResponse = @file_get_contents($apiUrl); // Hata raporlaması engellendi

    if ($apiResponse !== false) {
        $data = json_decode($apiResponse, true);

        if ($data !== null && is_array($data)) {
            if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                echo "Veri Bulunamadı.";
            } else {
               

                foreach ($data as $row) {
                    echo "<tr>
                        <td>" . $row["TC"] . "</td>
                        <td>" . $row["GSM"] . "</td>
                      
                    </tr>";
                }

                echo "</table>";
            }
        } else {
            echo "Veri bulunamadı.";
        }
    } else {
        echo "API request failed.";
    }
} else {
    echo "Please provide both name and surname.";
}
?>
