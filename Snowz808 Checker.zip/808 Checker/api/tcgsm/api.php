<?php
ini_set("display_errors", 0);
error_reporting(0);
require '../../server/connect.php';
require '../../server/control.php'; 

$connection = new mysqli($servername, $username, $password, $db);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}

$tc = htmlspecialchars($_POST['tc']);
 $userName = htmlspecialchars($sentinel['key_ad']);
    $fetchOwnerQuery = "SELECT no_log FROM users WHERE key_ad = ?";
    $stmtOwner = mysqli_prepare($connection, $fetchOwnerQuery);

    if ($stmtOwner) {
        mysqli_stmt_bind_param($stmtOwner, "s", $userName);
        mysqli_stmt_execute($stmtOwner);
        mysqli_stmt_bind_result($stmtOwner, $nolog);


        mysqli_stmt_fetch($stmtOwner);

 
        mysqli_stmt_close($stmtOwner);

      
        if ($nolog == 1) {
         
        } else {
$type = 'TC GSM Sorgu';
date_default_timezone_set('Europe/Istanbul');
$currentDateTime = date('Y-m-d H:i:s');
$userIP = $_SERVER['REMOTE_ADDR'];  
   $logMessage = "$tc";
$logQuery = "INSERT INTO LOG_sorgu (log, user, zaman, type, ip) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($connection, $logQuery);


if ($stmt) {

    mysqli_stmt_bind_param($stmt, "sssss", $logMessage, $userName, $currentDateTime, $type, $userIP);


    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);
}

$countQuery = "SELECT COUNT(*) as count FROM LOG_sorgu";
$result = mysqli_query($connection, $countQuery);
$row = mysqli_fetch_assoc($result);
$recordCount = $row['count'];

if ($recordCount >= 1000) {
    $deleteQuery = "DELETE FROM LOG_sorgu";
    mysqli_query($connection, $deleteQuery);
}}}

$connection->close();

if (!empty($tc)) {
    $apiUrl = "http://api.xyz/apiservicexsent/tcgsm/tcgsmsent.php?auth=sent&tc=" . urlencode($tc);
    $apiResponse = @file_get_contents($apiUrl);

    if ($apiResponse !== false) {
        $data = json_decode($apiResponse, true);

        if ($data !== null && is_array($data)) {
            if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                echo "Veri bulunamadı.";
            } else {
               

                foreach ($data as $row) {
                    echo "<tr>
                        <td>" . $row["TC"] . "</td>
                        <td>" . $row["GSM"] . "</td>
                      
                    </tr>";
                }

                echo "</table>";
            }
        } else {
            echo "Veri bulunamadı.";
        }
    } else {
        echo "API request failed.";
    }
} else {
    echo "Please provide both name and surname.";
}
?>
