
<?php
ini_set("display_errors", 0);
error_reporting(0);

require '../../server/connect.php';
require '../../server/control.php';

$connection = new mysqli($servername, $username, $password, $db);


if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}

$ad = htmlspecialchars($_POST['name']);
$soyad = htmlspecialchars($_POST['surname']);
$userName = htmlspecialchars($sentinel['key_ad']);
$nolog = htmlspecialchars($sentinel['no_log']);
$type = 'Ad Soyad Sorgu';


if ($nolog === '1') {
    
    makeApiRequest($ad, $soyad);
} else {
    
    $userIp = $_SERVER['REMOTE_ADDR'];
    logRequest($ad, $soyad, $userName, $userIp, $type);

    
    makeApiRequest($ad, $soyad);
}

function logRequest($ad, $soyad, $userName, $userIp, $type) {
    date_default_timezone_set('Europe/Istanbul');
    $currentDateTime = date('Y-m-d H:i:s');

    
    $logStatement = mysqli_prepare($GLOBALS['connection'], "INSERT INTO LOG_sorgu (log, user, zaman, type, ip) VALUES (?, ?, ?, ?, ?)");

   
    mysqli_stmt_bind_param($logStatement, "sssss", $logMessage, $userName, $currentDateTime, $type, $userIp);

    
    $logMessage = "$ad, $soyad";

 
    mysqli_stmt_execute($logStatement);

   
    mysqli_stmt_close($logStatement);

    
    $countStatement = mysqli_prepare($GLOBALS['connection'], "SELECT COUNT(*) as count FROM LOG_sorgu");
    mysqli_stmt_execute($countStatement);

   
    mysqli_stmt_bind_result($countStatement, $recordCount);

    
    mysqli_stmt_fetch($countStatement);

 
    mysqli_stmt_close($countStatement);

   
    if ($recordCount >= 1000) {
      
        $deleteStatement = mysqli_prepare($GLOBALS['connection'], "DELETE FROM LOG_sorgu");

    
        mysqli_stmt_execute($deleteStatement);

        
        mysqli_stmt_close($deleteStatement);
    }
}


$connection->close();


function makeApiRequest($ad, $soyad) {
    $apiUrl = "http://api.xyz/apiservicexsent/adsoyad/api.php?adi=" . urlencode($ad) . "&soyadi=" . urlencode($soyad);

    if ($apiUrl === false) {
        die('API request failed.');
    }

    $apiResponse = file_get_contents($apiUrl);

    if ($apiResponse !== false) {
        $data = json_decode($apiResponse, true);

        if ($data !== false) {
            if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                echo '<div class="error-message"><i class="fa fa-exclamation-circle"></i>Veri bulunamadı.</div>';
            } else {
                foreach ($data as $row) {
                  echo "<tr>
    <td>" . (!empty($row["TC"]) ? $row["TC"] : '-') . "</td>
    <td>" . (!empty($row["ADI"]) ? $row["ADI"] : '-') . "</td>
    <td>" . (!empty($row["SOYADI"]) ? $row["SOYADI"] : '-') . "</td>
    <td>" . (!empty($row["DOGUMTARIHI"]) ? $row["DOGUMTARIHI"] : '-') . "</td>
    <td>" . (!empty($row["NUFUSIL"]) ? $row["NUFUSIL"] : '-') . "</td>
    <td>" . (!empty($row["NUFUSILCE"]) ? $row["NUFUSILCE"] : '-') . "</td>
    <td>" . (!empty($row["ANNEADI"]) ? $row["ANNEADI"] : '-') . "</td>
    <td>" . (!empty($row["ANNETC"]) ? $row["ANNETC"] : '-') . "</td>
    <td>" . (!empty($row["BABAADI"]) ? $row["BABAADI"] : '-') . "</td>
    <td>" . (!empty($row["BABATC"]) ? $row["BABATC"] : '-') . "</td>
    <td>" . (!empty($row["UYRUK"]) ? $row["UYRUK"] : '-') . "</td>
</tr>";

                }
            }
        } else {
            echo "Invalid data received from API.";
        }
    } else {
        echo "API request failed.";
    }
}
?>
 <style>
    .error-message {
    font-family: 'Arial', sans-serif;
    font-weight: bold;
    font-size: 12px;
    color: white;
  }
</style>