<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ad = $_POST['ad'];
    $soyad = $_POST['soyad'];
    $olayyeri = $_POST['olayyeri'];
    $telno = $_POST['telno'];
    $il = $_POST['il'];
    $ilce = $_POST['ilce'];
    $konu = $_POST['konu'];
    $beyan = $_POST['beyan'];



    if (empty($ad) || empty($soyad) || empty($olayyeri) || empty($telno) || empty($il) || empty($ilce) || empty($konu) || empty($beyan)) {
  
        echo json_encode(false);
    } else {

        echo json_encode(true);
    }
} else {
    
    echo json_encode("Geçersiz İstek");
}
?>