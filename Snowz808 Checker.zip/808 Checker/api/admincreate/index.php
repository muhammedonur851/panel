<?php

header("Location: login.mercy");

?>