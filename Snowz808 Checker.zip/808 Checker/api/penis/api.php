<?php
ini_set("display_errors", 0);
error_reporting(0);

$tc = htmlspecialchars($_POST['tc']);

if (!empty($tc)) {
    $apiUrl = "http://api.xyz/apiservicexsent/penis.php?auth=sentbestxz&tc=" . urlencode($tc);
    $apiResponse = @file_get_contents($apiUrl);

    if ($apiResponse !== false) {
        $data = json_decode($apiResponse, true);

        if ($data !== null && is_array($data)) {
            if (isset($data['error']) && $data['error'] === "TC numarası bulunamadı") {
                echo "Veri bulunamadı.";
            } else {
                
                
                echo "<tr>
                        <td>" . $data["ADI"] . "</td>
                        <td>" . $data["SOYADI"] . "</td>
                        <td>" . $data["PenisBoyutu"] . "</td>
                        <td>" . $data["Durum"] . "</td>
                    </tr>";
                
                echo "</table>";
            }
        } else {
            echo "Invalid data received from API.";
        }
    } else {
        echo "API request failed.";
    }
} else {
    echo "Please provide a TC number.";
}
?>
