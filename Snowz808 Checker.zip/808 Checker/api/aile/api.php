<?php
ini_set("display_errors", 0);
error_reporting(0);

require '../../server/connect.php';
require '../../server/control.php';

$connection = new mysqli($servername, $username, $password, $db);


if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}

$tc = htmlspecialchars($_POST['tc']);
$userName = htmlspecialchars($sentinel['key_ad']);
$nolog = htmlspecialchars($sentinel['no_log']);
$type = 'Aile Sorgu';
date_default_timezone_set('Europe/Istanbul');
$currentDateTime = date('Y-m-d H:i:s');
$userIP = $_SERVER['REMOTE_ADDR'];

if (!empty($tc)) {
    if ($nolog === '1') {
        $apiUrl = "http://api.xyz/apiservicexsent/s%C3%BClale/aileapisent.php?auth=sent&tcno=" . urlencode($tc);

        $apiResponse = @file_get_contents($apiUrl);

        if ($apiResponse !== false) {
            $data = json_decode($apiResponse, true);

            if ($data !== null && is_array($data)) {
                if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                    echo "No data found.";
                } else {
                    foreach ($data as $row) {
                        echo "<tr>
                                <td>" . $row["yakinlik"] . "</td>
                                <td>" . $row["tc"] . "</td>
                                <td>" . $row["adi"] . "</td>
                                <td>" . $row["soyadi"] . "</td>
                                <td>" . $row["dtarih"] . "</td>
                                <td>" . $row["anneadi"] . "</td>
                                <td>" . $row["annetc"] . "</td>
                                <td>" . $row["babaadi"] . "</td>
                                <td>" . $row["babatc"] . "</td>
                                <td>" . $row["il"] . "</td>
                                <td>" . $row["ilce"] . "</td>
                                <td>" . $row["uy"] . "</td>
                            </tr>";
                    }

                    echo "</table>";
                }
            } else {
                echo "Veri bulunamadı.";
            }
        } else {
            echo "Veri bulunamadı.";
        }
    } else {
     

$logMessage = "$tc";
$logQuery = "INSERT INTO LOG_sorgu (log, user, zaman, type, ip) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($connection, $logQuery);


if ($stmt) {
    
    mysqli_stmt_bind_param($stmt, "sssss", $logMessage, $userName, $currentDateTime, $type, $userIP);

    mysqli_stmt_execute($stmt);

 
    mysqli_stmt_close($stmt);
}

$countQuery = "SELECT COUNT(*) as count FROM LOG_sorgu";
$result = mysqli_query($connection, $countQuery);
$row = mysqli_fetch_assoc($result);
$recordCount = $row['count'];

if ($recordCount >= 1000) {
    $deleteQuery = "DELETE FROM LOG_sorgu";
    mysqli_query($connection, $deleteQuery);
}
$connection->close();

    
        $apiUrl = "http://api.xyz/apiservicexsent/s%C3%BClale/aileapisent.php?auth=sent&tcno=" . urlencode($tc);

        $apiResponse = @file_get_contents($apiUrl);

        if ($apiResponse !== false) {
            $data = json_decode($apiResponse, true);

            if ($data !== null && is_array($data)) {
                if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                    echo "No data found.";
                } else {
                    foreach ($data as $row) {
                        echo "<tr>
                                <td>" . $row["yakinlik"] . "</td>
                                <td>" . $row["tc"] . "</td>
                                <td>" . $row["adi"] . "</td>
                                <td>" . $row["soyadi"] . "</td>
                                <td>" . $row["dtarih"] . "</td>
                                <td>" . $row["anneadi"] . "</td>
                                <td>" . $row["annetc"] . "</td>
                                <td>" . $row["babaadi"] . "</td>
                                <td>" . $row["babatc"] . "</td>
                                <td>" . $row["il"] . "</td>
                                <td>" . $row["ilce"] . "</td>
                                <td>" . $row["uy"] . "</td>
                            </tr>";
                    }

                    echo "</table>";
                }
            } else {
                echo "Veri bulunamadı.";
            }
        } else {
            echo "Veri bulunamadı.";
        }
    }
} else {
    echo "Please provide both name and surname.";
}
?>
