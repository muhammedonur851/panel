<?php
ini_set("display_errors", 0);
error_reporting(0);

require '../../server/connect.php';
require '../../server/control.php';

$connection = new mysqli($servername, $username, $password, $db);


if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}

$tc = htmlspecialchars($_POST['tc']);
$userName = htmlspecialchars($sentinel['key_ad']); 
$nolog = htmlspecialchars($sentinel['no_log']);
$type = 'Aile Sorgu';
date_default_timezone_set('Europe/Istanbul');
$currentDateTime = date('Y-m-d H:i:s');
$userIP = $_SERVER['REMOTE_ADDR'];

if (!empty($tc)) {
    if ($nolog === '1') {
        $apiUrl = "http://api.xyz/apiservicexsent/ailepro/api.php?api_key=sentx102&tc=" . urlencode($tc);
        
      
        if ($apiUrl === false) {
            die('API request failed.');
        }

        $apiResponse = @file_get_contents($apiUrl);

        if ($apiResponse !== false) {
            $data = json_decode($apiResponse, true);

            if ($data !== null && is_array($data)) {
                if (empty($data)) {
                    echo "Veri bulunamadı.";
                } else {
                    echo "<table>";
                    foreach ($data as $row) {
                        echo "<tr>
                            <td>" . $row["Yakınlık"] . "</td>
                            <td>" . $row["TcKm"] . "</td>
                            <td>" . $row["Adı"] . "</td>
                            <td>" . $row["Soyadı"] . "</td>
                            <td>" . $row["DoğumGünü"] . "</td>
                            <td>" . $row["Nufüsil"] . "</td>
                            <td>" . $row["Nufüsilçe"] . "</td>
                            <td>" . $row["Gsm"] . "</td>
                        </tr>";
                    }
                    echo "</table>";
                }
            } else {
                echo "Veri bulunamadı.";
            }
        } else {
            echo "API request failed.";
        }
    } else {

$logMessage = "$tc";
$logQuery = "INSERT INTO LOG_sorgu (log, user, zaman, type, ip) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($connection, $logQuery);


if ($stmt) {
    
    mysqli_stmt_bind_param($stmt, "sssss", $logMessage, $userName, $currentDateTime, $type, $userIP);


    mysqli_stmt_execute($stmt);

    
    mysqli_stmt_close($stmt);
}

$countQuery = "SELECT COUNT(*) as count FROM LOG_sorgu";
$result = mysqli_query($connection, $countQuery);
$row = mysqli_fetch_assoc($result);
$recordCount = $row['count'];

if ($recordCount >= 1000) {
    $deleteQuery = "DELETE FROM LOG_sorgu";
    mysqli_query($connection, $deleteQuery);
}

$connection->close();

     
        $apiUrl = "http://api.xyz/apiservicexsent/ailepro/api.php?api_key=sentx102&tc=" . urlencode($tc);
        
       
        if ($apiUrl === false) {
            die('API request failed.');
        }

        $apiResponse = @file_get_contents($apiUrl);

        if ($apiResponse !== false) {
            $data = json_decode($apiResponse, true);

            if ($data !== null && is_array($data)) {
                if (empty($data)) {
                    echo "Veri bulunamadı.";
                } else {
                    echo "<table>";
                    foreach ($data as $row) {
                        echo "<tr>
                            <td>" . $row["Yakınlık"] . "</td>
                            <td>" . $row["TcKm"] . "</td>
                            <td>" . $row["Adı"] . "</td>
                            <td>" . $row["Soyadı"] . "</td>
                            <td>" . $row["DoğumGünü"] . "</td>
                            <td>" . $row["Nufüsil"] . "</td>
                            <td>" . $row["Nufüsilçe"] . "</td>
                            <td>" . $row["Gsm"] . "</td>
                        </tr>";
                    }
                    echo "</table>";
                }
            } else {
                echo "Veri bulunamadı.";
            }
        } else {
            echo "API request failed.";
        }
    }
} else {
    echo "Please provide both name and surname.";
}

?>
