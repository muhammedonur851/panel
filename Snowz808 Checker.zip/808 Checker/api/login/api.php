<?php
session_start();
header("Content-Type: application/json; utf-8;");
require '../../server/connect.php';

date_default_timezone_set('Europe/Istanbul');

ini_set("display_errors", 0);
error_reporting(0);
if (isset($_POST)) {
    $anasikensentinel = $_POST["keyad"];
    $bacisikensentinel = $_POST["key"];

    $recaptchaSecret = "6LcX-YMqAAAAAErc-Y9dU5OoOU5x_0v7EyQPoHiD";
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptchaSecret&response=$recaptchaResponse");
    $responseKeys = json_decode($response, true);

    if (intval($responseKeys["success"]) !== 1) {
        echo json_encode(array("error" => "recaptcha", "message" => "reCAPTCHA verification failed"));
        exit();
    }

    $checkDeletedQuery = $conn->prepare("SELECT * FROM users WHERE key_ad = ? AND deleted = 1");
    $checkDeletedQuery->execute(array($anasikensentinel));
    $deletedUser = $checkDeletedQuery->fetch(PDO::FETCH_ASSOC);

    if ($deletedUser) {
        echo json_encode(["status" => "false", "error" => "deleted"]);
        exit();
    }
    $stmt = $conn->prepare("SELECT * FROM multiban WHERE key_ad = ? AND key_pas = ?");
    $stmt->execute(array($anasikensentinel, $bacisikensentinel));
    $multibanUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($multibanUser) {
      
        $_SESSION['key'] = $bacisikensentinel;
        echo json_encode(["status" => "true", "login" => "success"]);
        die();
    } elseif ($user['banned'] == 1) {
      
        echo json_encode(["status" => "false", "error" => "banned"]);
        die();
    }

    
    $exceptionUsers = array(
        "mercy" => "mercyfree",
        "Mercy" => "Mercyfree",
        "MERCY" => "mercyfree",
        "mercy" => "Mercyfree"
       
    );

   
    $lowercaseExceptionUsers = array_change_key_case($exceptionUsers, CASE_LOWER);
    $anasikensentinelLower = strtolower($anasikensentinel);

    if (array_key_exists($anasikensentinelLower, $lowercaseExceptionUsers) && $bacisikensentinel == $lowercaseExceptionUsers[$anasikensentinelLower]) {
     
        $_SESSION['key'] = $bacisikensentinel;
        echo json_encode(["status" => "true", "login" => "success"]);
        die();
    }

   

   
    $stmt = $conn->prepare("SELECT * FROM users WHERE key_ad = ? AND key_pas = ?");
    $stmt->execute(array($anasikensentinel, $bacisikensentinel));
    $apisikensentinel = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($apisikensentinel && $apisikensentinel['banned'] == 1) {
        echo json_encode(["status" => "false", "error" => "banned"]);
        die();
    } elseif ($apisikensentinel && $apisikensentinel['endkey'] == 1) {
        echo json_encode(["status" => "false", "error" => "endkey"]);
        die();
    } elseif ($apisikensentinel) {
        $_SESSION['key'] = $bacisikensentinel;
        echo json_encode(["status" => "true", "login" => "success"]);
        

        $ipAddress = $_SERVER['REMOTE_ADDR'];
        $currentDateTime = date('Y-m-d H:i:s');

 
$checkNoLogQuery = $conn->prepare("SELECT no_log FROM users WHERE key_ad = ?");
$checkNoLogQuery->execute(array($anasikensentinel));

if ($checkNoLogQuery->rowCount() > 0) {
    $userData = $checkNoLogQuery->fetch(PDO::FETCH_ASSOC);

   
    if ($userData['no_log'] == 1) {
    
    } else {
       
        $query = $conn->prepare("INSERT INTO log (key_ad, key_pas, ip_address, login_time) VALUES (?, ?, ?, ?)");
        $query->execute(array($anasikensentinel, $bacisikensentinel, $ipAddress, $currentDateTime));

       
    }
} else {

    $query = $conn->prepare("INSERT INTO log (key_ad, key_pas, ip_address, login_time) VALUES (?, ?, ?, ?)");
    $query->execute(array($anasikensentinel, $bacisikensentinel, $ipAddress, $currentDateTime));

   
}
      
$sql = "SELECT COUNT(DISTINCT ip_address) as ip_count FROM log WHERE key_ad = ?";
$result = $conn->prepare($sql);
$result->execute(array($anasikensentinel));
$ipCount = $result->fetch(PDO::FETCH_ASSOC)['ip_count'];

if ($ipCount > 4) {
   
    $updateQuery = $conn->prepare("UPDATE users SET banned = 1 WHERE key_ad = ?");
    $updateQuery->execute(array($anasikensentinel));
}

       
        $rowCount = $conn->query("SELECT COUNT(*) FROM log")->fetchColumn();

        if ($rowCount >= 400) {
     
            $conn->exec("DELETE FROM log");
        }

        $updateLastLoginQuery = $conn->prepare("UPDATE users SET last_login = ? WHERE key_ad = ?");
        $updateLastLoginQuery->execute(array($currentDateTime, $anasikensentinel));
        die();
    } else {
        echo json_encode(["status" => "false", "login" => "error"]);
        die();
    }
}
?>