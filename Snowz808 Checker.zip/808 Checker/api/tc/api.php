<?php
ini_set("display_errors", 0);
error_reporting(0);

require '../../server/connect.php';
require '../../server/control.php';

$connection = new mysqli($servername, $username, $password, $db);


if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}

$tc = htmlspecialchars($_POST['tc']);
$userName = htmlspecialchars($sentinel['key_ad']); 
$nolog = htmlspecialchars($sentinel['no_log']);
$type = 'TC Sorgu';
date_default_timezone_set('Europe/Istanbul');
$currentDateTime = date('Y-m-d H:i:s');
$userIP = $_SERVER['REMOTE_ADDR'];

if (!empty($tc)) {
    
    if ($nolog === '1') {
       
        $apiUrl = "http://api.xyz/apiservicexsent/tcsent/api.php?auth=sent&tc=" . urlencode($tc);
        $apiResponse = @file_get_contents($apiUrl);
        
        if ($apiResponse !== false) {
            $data = json_decode($apiResponse, true);
    
            if ($data !== null && is_array($data)) {
                if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                    echo "Veri bulunamadı.";
                } else {
                    foreach ($data as $row) {
                        echo "<tr>
                            <td>" . $row["TC"] . "</td>
                            <td>" . $row["ADI"] . "</td>
                            <td>" . $row["SOYADI"] . "</td>
                            <td>" . $row["DOGUMTARIHI"] . "</td>
                            <td>" . $row["NUFUSIL"] . "</td>
                            <td>" . $row["NUFUSILCE"] . "</td>
                            <td>" . $row["ANNEADI"] . "</td>
                            <td>" . $row["ANNETC"] . "</td>
                            <td>" . $row["BABAADI"] . "</td>
                            <td>" . $row["BABATC"] . "</td>
                            <td>" . $row["UYRUK"] . "</td>
                        </tr>";
                    }
                }
            } else {
                echo "Invalid data received from API.";
            }
        } else {
            echo "API request failed.";
        }
    } else {
        
        $logMessage = $tc;
        $logQuery = "INSERT INTO LOG_sorgu (log, user, zaman, type, ip) VALUES (?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($logQuery);

        
        $stmt->bind_param("sssss", $logMessage, $userName, $currentDateTime, $type, $userIP);

        
        $stmt->execute();

       
        $stmt->close();

        $countQuery = "SELECT COUNT(*) as count FROM LOG_sorgu";
        $result = $connection->query($countQuery);
        $row = $result->fetch_assoc();
        $recordCount = $row['count'];

        if ($recordCount >= 1000) {
            $deleteQuery = "DELETE FROM LOG_sorgu";
            $connection->query($deleteQuery);
        }
$connection->close();
        $apiUrl = "http://api.xyz/apiservicexsent/tcsent/tc.php?auth=sent&tc=" . urlencode($tc);
        $apiResponse = @file_get_contents($apiUrl);
        
        if ($apiResponse !== false) {
            $data = json_decode($apiResponse, true);
    
            if ($data !== null && is_array($data)) {
                if (isset($data['error']) && $data['error'] === "Veri bulunamadı") {
                    echo "Veri bulunamadı.";
                } else {
                    foreach ($data as $row) {
                        echo "<tr>
                            <td>" . $row["TC"] . "</td>
                            <td>" . $row["ADI"] . "</td>
                            <td>" . $row["SOYADI"] . "</td>
                            <td>" . $row["DOGUMTARIHI"] . "</td>
                            <td>" . $row["NUFUSIL"] . "</td>
                            <td>" . $row["NUFUSILCE"] . "</td>
                            <td>" . $row["ANNEADI"] . "</td>
                            <td>" . $row["ANNETC"] . "</td>
                            <td>" . $row["BABAADI"] . "</td>
                            <td>" . $row["BABATC"] . "</td>
                            <td>" . $row["UYRUK"] . "</td>
                        </tr>";
                    }
                }
            } else {
                echo "Invalid data received from API.";
            }
        } else {
            echo "API request failed.";
        }
    }
} else {
    echo "Please provide both name and surname.";
}
?>
