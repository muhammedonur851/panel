<?php
ini_set("display_errors", 0);
error_reporting(0);
require '../../server/connect.php';
require '../../server/control.php'; 

$connection = new mysqli($servername, $username, $password, $db);


if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}

$tc = isset($_POST['tc']) ? htmlspecialchars($_POST['tc']) : '';
 $userName = htmlspecialchars($sentinel['key_ad']);
    $fetchOwnerQuery = "SELECT no_log FROM users WHERE key_ad = ?";
    $stmtOwner = mysqli_prepare($connection, $fetchOwnerQuery);

    if ($stmtOwner) {
        mysqli_stmt_bind_param($stmtOwner, "s", $userName);
        mysqli_stmt_execute($stmtOwner);
        mysqli_stmt_bind_result($stmtOwner, $nolog);


        mysqli_stmt_fetch($stmtOwner);

 
        mysqli_stmt_close($stmtOwner);

      
        if ($nolog == 1) {
         
        } else {
$type = 'İban Sorgu';
date_default_timezone_set('Europe/Istanbul');
$currentDateTime = date('Y-m-d H:i:s');
$userIP = $_SERVER['REMOTE_ADDR'];  
   $logMessage = "$tc";
$logQuery = "INSERT INTO LOG_sorgu (log, user, zaman, type, ip) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($connection, $logQuery);


if ($stmt) {
   
    mysqli_stmt_bind_param($stmt, "sssss", $logMessage, $userName, $currentDateTime, $type, $userIP);


    mysqli_stmt_execute($stmt);


    mysqli_stmt_close($stmt);
}

$countQuery = "SELECT COUNT(*) as count FROM LOG_sorgu";
$result = mysqli_query($connection, $countQuery);
$row = mysqli_fetch_assoc($result);
$recordCount = $row['count'];

if ($recordCount >= 1000) {
    $deleteQuery = "DELETE FROM LOG_sorgu";
    mysqli_query($connection, $deleteQuery);
}}}

$connection->close();
if (!empty($tc)) {
    $apiUrl = "http://api.xyz/apiservicexsent/iban/api.php?iban=" . urlencode($tc);
    $apiResponse = @file_get_contents($apiUrl);

    if ($apiResponse !== false) {
        $data = json_decode($apiResponse, true);

        if ($data !== null && is_array($data)) {
            if (isset($data['error']) && $data['error'] === "İban numarası bulunamadı") {
                echo "Veri bulunamadı.";
            } else {
                echo "<tr>
                        <td>
                            <strong>Ad:</strong> " . $data["BANKA BİLGİLERİ"]["Ad"] . "<br>
                            <strong>Kod:</strong> " . $data["BANKA BİLGİLERİ"]["Kod"] . "<br>
                            <strong>Swift:</strong> " . $data["BANKA BİLGİLERİ"]["Swift"] . "<br>
                            <strong>Hesap No:</strong> " . $data["BANKA BİLGİLERİ"]["Hesap No"] . "
                        </td>
                        <td>
                            <strong>Ad:</strong> " . $data["ŞUBE BİLGİLERİ"]["Ad"] . "<br>
                            <strong>Kod:</strong> " . $data["ŞUBE BİLGİLERİ"]["Kod"] . "<br>
                            <strong>İl:</strong> " . $data["ŞUBE BİLGİLERİ"]["İl"] . "<br>
                            <strong>İlçe:</strong> " . $data["ŞUBE BİLGİLERİ"]["İlçe"] . "<br>
                            <strong>Tel:</strong> " . $data["ŞUBE BİLGİLERİ"]["Tel"] . "<br>
                            <strong>Fax:</strong> " . $data["ŞUBE BİLGİLERİ"]["Fax"] . "<br>
                            <strong>Adres:</strong> " . $data["ŞUBE BİLGİLERİ"]["Adres"] . "
                        </td>
                    </tr>";
                
                echo "</table>";
            }
        } else {
            echo "Invalid data received from API.";
        }
    } else {
        echo "API request failed.";
    }
} else {
    echo "Please provide a TC number.";
}
?>
