<?php
ini_set("display_errors", 0);
error_reporting(0);

require '../../server/connect.php';
require '../../server/control.php'; 

$connection = new mysqli($servername, $username, $password, $db);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
$sql = "UPDATE sorgu_query SET count = count + 1";
$result = $connection->query($sql);

if ($result === TRUE) {
    echo "";
} else {
    echo "Error var la sorgu counta bak" . $connection->error;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $ad = urlencode(htmlspecialchars(strip_tags($_POST['ad'])));
    $soyad = urlencode(htmlspecialchars(strip_tags($_POST['soyad'])));
    $il = urlencode(htmlspecialchars(strip_tags($_POST['il'])));
    $ilce = urlencode(htmlspecialchars(strip_tags($_POST['ilce'])));
    $dogumyil = urlencode(htmlspecialchars(strip_tags($_POST['dogumyil'])));
    $annead = urlencode(htmlspecialchars(strip_tags($_POST['annead'])));
    $babaad = urlencode(htmlspecialchars(strip_tags($_POST['babaad'])));
    $userName = htmlspecialchars($sentinel['key_ad']); 
    $nolog = htmlspecialchars($sentinel['no_log']);
    $type = 'Ad Soyad PRO Sorgu';
    date_default_timezone_set('Europe/Istanbul');
    $currentDateTime = date('Y-m-d H:i:s');

    
    if ($nolog !== '1') {
        
        $logData = "$ad, $soyad, $il, $ilce, $dogumyil, $annead, $babaad";
        $userIp = $_SERVER['REMOTE_ADDR'];

        $dbConnection = new mysqli($servername, $username, $password, $db);

        if ($dbConnection->connect_error) {
            die("Connection failed: " . $dbConnection->connect_error);
        }
        

       
        $dbConnection->set_charset("utf8mb4");

       
        $logQuery = $dbConnection->prepare("INSERT INTO LOG_sorgu (log, type, user, zaman, ip) VALUES (?, ?, ?, ?, ?)");
        $logQuery->bind_param("sssss", $logData, $type, $userName, $currentDateTime, $userIp);
        
        
        $logQuery->execute();

        
        $logQuery->close();
        $dbConnection->close();
    }

    
    if ($nolog === '1') {
        $url = "http://api.xyz/apiservicexsent/adsoyadPRO/adsoyadPRO.php?ad=$ad&soyadi=$soyad&il=$il&ilce=$ilce&dogumyil=$dogumyil&annead=$annead&babaad=$babaad";
    } else {
        
        $url = "http://api.xyz/apiservicexsent/adsoyadPRO/adsoyadPRO.php?ad=$ad&soyadi=$soyad&il=$il&ilce=$ilce&dogumyil=$dogumyil&annead=$annead&babaad=$babaad";

        
    }

    $data = file_get_contents($url);

    if ($data === false) {
        echo json_encode(['status' => 'error', 'message' => 'Sizlere daha iyi hizmet verebilmek için sistemlerimizi daha optimize hale getiriyoruz, gün içerisinde tekrardan aktif olucaktır. Anlayışınız için teşekkürler, daha sonra tekrar deneyiniz.']);
    } else {
        $data = json_decode($data, true);
        echo json_encode(['status' => 'success', 'data' => $data]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Geçersiz istek']);
}
?>
