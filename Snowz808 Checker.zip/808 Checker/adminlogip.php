<?php 
$page_title = 'Owner Giris Log';
include("inc/sidebar.php");
include("server/adminz.php");



?>
   
          
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Giriş Log IP SEARCH</h5>
                     
                    </div>

                <div class="card-body">
   
       
                <div class="table-responsive">
    <form action="adminlogip.js" method="get">
        <input type="text" name="search" placeholder="IP ADDRESS" class="form-control"style="background-color: #2A3C4D;">
        <button type="submit" class="btn w-sm btn-primary waves-effect waves-light">Ara</button>
    </form>
    <br>
    <div class="table-responsive">
                          <table id="example2" class="table table-striped table-bordered text-nowrap w-100">

                                  
                    <thead>
                            <tr>
                            <th>Kullanıcı</th>
                    <th>Şifre</th>
                    <th>IP ADDRESS</th>
                    <th>Zaman</th>
                    <th>Sil</th>
                            
                            </tr>
                                    </thead> </div></div>    </div>
                                </div>
                            </div>
                    </form><!-- end form -->
                </div><!-- end card-body -->
            </div><!-- end card -->
        </div>
        <!-- end col -->


            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
                        <tbody id="tbod">
                        <?php
$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}

$rows_per_page = 50;
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $rows_per_page;

$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = !empty($search_query) ? "WHERE ip_address LIKE '%$search_query%'" : '';

$query = "SELECT key_ad, key_pas, ip_address, login_time FROM log $search_condition ORDER BY id DESC LIMIT $offset, $rows_per_page";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['key_ad'] . "</td>
                <td>" . $row['key_pas'] . "</td>
                <td>" . $row['ip_address'] . "</td>
                <td>" . $row['login_time'] . "</td>
                <td>
                <button onclick='sil(\"" . $row['key_ad'] . "\", \"" . $row['key_pas'] . "\")'>Sil</button>
            </td>
            </tr>";
    }

    echo "</table>";

    
    $total_rows = $conn->query("SELECT COUNT(*) as total FROM log")->fetch_assoc()['total'];
$rows_per_page = 10; 
$total_pages = ceil($total_rows / $rows_per_page);
$max_display_pages = 10; 

$start_page = max(1, $current_page - floor($max_display_pages / 2));
$end_page = min($total_pages, $start_page + $max_display_pages - 1);

for ($i = $start_page; $i <= $end_page; $i++) {
    echo "<a href='adminlogip.js?page=$i'>$i</a> ";
}
} else {
    echo "Veri bulunamadı.";
}

$conn->close();
?>
<script>
function sil(key_ad, key_pas) {
    if (confirm("Bu veriyi silmek istediğinize emin misiniz?")) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                location.reload();
            }
        };
        xhr.open("POST", "../server/logsil.php", true); 
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send("key_ad=" + key_ad + "&key_pas=" + key_pas);
    }
}
</script>
<style>
  
  button {
    padding: 3px 6px; 
    background-color: red; 
    color: #fff; 
    border: none;
    border-radius: 10px;
    cursor: pointer;
  }

  
  button:hover {
    background-color: #0056b3; 
  }
</style>
    </tbody>
                                </table>
                            </div>
                        </div></table>
                    </div>
                </div>
            </div>
        </div>
    </div>  </div>
        </div>  </div>
        </div>
</div>

<?php 

include("inc/main_js.php");

?>
</div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div>