<?php 
$page_title = 'Owner Multi İzinli Kullanıcılar';
include("inc/sidebar.php");
include("server/owner.php");



?>
   
          
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Multi İzinli Kullanıcılar</h5>
                     
                    </div>

                <div class="card-body">
                 
<div class="form-group">
   
    <input type="text" class="form-control" id="key_ad" name="key_ad"placeholder="Kullanıcı adı"style="background-color: #2A3C4D;"required>
</div>

<div class="form-group">
   
    <input type="password" class="form-control" id="key_pas" name="key_pas"placeholder="Şifre"style="background-color: #2A3C4D;" required>
</div>

<button type="submit" id="sentinel"class="btn btn-primary">İzin Ver</button>
</form>
<script>
$("#sentinel").click(function () {
    var key_ad = $("#key_ad").val();
    var key_pas = $("#key_pas").val();

    if (key_ad === "" || key_pas === "") {
        Swal.fire({
            icon: "error",
            title: "Oopss...",
            text: "Kullanıcı Adı ve Şifre Boş Bırakılmaz",
            footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            showConfirmButton: false,
            timer: 1500
        });
    } else {
        $.ajax({
            type: 'POST',
            url: '../server/multizinekle.php',
            data: {
                key_ad: key_ad,
                key_pas: key_pas
            },

            success: function (data) {
    if (data.trim() === "success") {
        Swal.fire({
            position: 'center',
            icon: "success",
            title: 'Multi İzni Verildi!',
            footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            showConfirmButton: false,
            timer: 3000
        });

        
        $("#key_ad").val("");
        $("#key_pas").val("");

        
        setTimeout(function () {
            location.reload();
        }, 1000); 
    } else {
        Swal.fire({
            icon: "error",
            title: "Hata!",
            text: "Kullanıcı ekleme sırasında bir hata oluştu",
            footer: '<a href="<?php echo $social_link; ?>"><?php echo $social_link; ?></a>',
            showConfirmButton: false,
            timer: 1500
        });
    }
}

        });
    }
});
</script>
<br>
<br>

    <div class="table-responsive">
                          <table id="example2" class="table table-striped table-bordered text-nowrap w-100">
                         
                                  
                    <thead>
                            <tr>
                            <th>Kullanıcı</th>
                    <th>Şifre</th>
                    <th>Sil</th>
                  
                            
                            </tr>
                                    </thead> </div></div>    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
        
        <style>
  
  button {
    padding: 3px 6px; 
    background-color: red; 
    color: #fff; 
    border: none;
    border-radius: 10px;
    cursor: pointer;
  }

  
  button:hover {
    background-color: #0056b3; 
  }
</style>


            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
                        <tbody id="tbod">
                        <?php

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
    die("Veritabanına bağlanılamadı: " . $conn->connect_error);
}

$rows_per_page = 50;
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($current_page - 1) * $rows_per_page;

$query = "SELECT key_ad, key_pas FROM multiban ORDER BY id DESC LIMIT $offset, $rows_per_page"; 
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row['key_ad'] . "</td>
        <td>" . $row['key_pas'] . "</td>
        <td>
            <button onclick='sil(\"" . $row['key_ad'] . "\", \"" . $row['key_pas'] . "\")'>Sil</button>
        </td>
    </tr>";
    }

    echo "</table>";

    
    $total_rows = $conn->query("SELECT COUNT(*) as total FROM log")->fetch_assoc()['total'];
$rows_per_page = 10; 
$total_pages = ceil($total_rows / $rows_per_page);
$max_display_pages = 10; 

$start_page = max(1, $current_page - floor($max_display_pages / 2));
$end_page = min($total_pages, $start_page + $max_display_pages - 1);

for ($i = $start_page; $i <= $end_page; $i++) {
    echo "<a href='adminmultilog.js?page=$i'>$i</a> ";
}
} else {
    echo "Veri bulunamadı.";
}

$conn->close();
?>
<script>
function sil(key_ad, key_pas) {
    if (confirm("Bu veriyi silmek istediğinize emin misiniz?")) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                location.reload();
            }
        };
        xhr.open("POST", "../server/sil.php", true); 
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send("key_ad=" + key_ad + "&key_pas=" + key_pas);
    }
}
</script>

    </tbody>
                                </table>
                            </div>
                        </div></table>
                    </div>
                </div>
            </div>
        </div>
    </div>  </div>
        </div>  </div>
        </div>
</div>

<?php 

include("inc/main_js.php");

?>
</div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div> </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div></div>
            </div>
        </div>