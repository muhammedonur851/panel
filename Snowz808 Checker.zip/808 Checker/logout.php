<?php
ini_set("display_errors", 0);
error_reporting(0);
session_start();
date_default_timezone_set('Europe/Istanbul');

require 'server/connect.php';
require 'server/control.php';

$connection = new mysqli($servername, $username, $password, $db);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$user_name = $sentinel['key_ad'];

$result = $connection->query("SELECT no_log FROM users WHERE key_ad = '$user_name'");
$userRow = $result->fetch_assoc();
$no_log = $userRow['no_log'];

if ($no_log != 1) {
    $result = $connection->query("SELECT COUNT(*) as count FROM logout");
    $row = $result->fetch_assoc();
    $record_count = $row['count'];

    if ($record_count >= 200) {
        $stmt = $connection->prepare("DELETE FROM logout");
        $stmt->execute();
        $stmt->close();
    }

    $logout_time = date("Y-m-d H:i:s");
    $sql = "INSERT INTO logout (user_name, logout_time) VALUES (?, ?)";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("ss", $user_name, $logout_time);
    $stmt->execute();
    $stmt->close();
}

session_destroy();

$connection->close();

header("Location: login.js");
exit();
?>
