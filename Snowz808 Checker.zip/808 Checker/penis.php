﻿<?php 
$page_title = 'Penis Sorgu';
include("inc/sidebar.php");
include("server/vipkontrol.php");
?>

<div class="row">
    <div class="col-xl">
        <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Penis Cm Sorgu</h5>
                <small class="text-primary float-end">Lütfen Sorgulanacak Kişinin T.C Bilgisini Giriniz.</small>
            </div>

            <div class="card-body">
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">T.C</label>
                          <input type="text" class="form-control" name="tc"  id="basic-default-fullname" placeholder="11111111110"/ required>
                        </div>
                      
                <button id="btnSentinel" type="submit" class="btn btn-primary"><i class="fa fa-search"></i>&nbsp;Sorgula</button>
                <br><br>
                
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered text-nowrap w-100">
                        <thead>
                                 <tr>
                                    <th>Ad </th>
                                    <th>Soyad</th>
                                    <th>Penis Boyutu</th> 
                                    <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody id="sentinelapi"></tbody>
                    </table>
                </div>
                
                <script type="text/javascript">
    
    $("#btnSentinel").click(function(){
        var tc = $("[name=tc]").val();
      
        
        $("#sentinelapi").html('');
        
        if (tc === "" ) {
            Swal.fire({
                icon: "error",
                title: "Oopss...",
                text: "Lütfen TC bilgisi giriniz.",
                footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            });
            return;
        }

        Swal.fire({
            imageUrl: 'img/sorgulaniyor.gif',
            imageHeight: 100,
            title: 'Sorgu Çözümü Başladı !',
            text: 'Sorgulanıyor...',
            footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
            showConfirmButton: false,
        });

        $.ajax({
            type: 'POST',
            url: 'api/penis/api.php',
            data: {tc},

            success: function(data){
                swal.close();
                var json = data;

                $("#sentinelapi").html(data);

                if (json == false || data.includes("Veri bulunamadı.") || data.includes("No data found.")) {
                    swal.close();
                    Swal.fire({
                        icon: "error",
                        title: "Oopss...",
                        text: "Sorguladığınız Kişiye Ait Bir Bilgi Bulunamadı.",
                        footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                    });

                    return;
                }
            }
        });
    });
</script>
                          </div>
                      </div>
                 </div>
            </div>
       </div>
  </div>
<?php 
include("inc/main_js.php");
?>
