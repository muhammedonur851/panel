<?php

// Sabit JSON verisi
$jsonData = '{
    "success": true,
    "data": {
        "Tc": "11111111110",
        "Adı": "ABDULSELAM",
        "Soyadı": "DENİZ",
        "DogumTarihi": "1998-03-17",
        "DogumYeri": "DİYARBAKIR",
        "Cinsiyet": "ERKEK",
        "AnneAdı": "RAHİME",
        "BabaAdı": "BAHRİ",
        "Din": "İslam",
        "MedeniHal": "Evli",
        "NufusIL": "DİYARBAKIR",
        "NufusILCE": "ÇERMİK",
        "Uyruk": null,
        "KimlikTür": "T.C. Kimlik Kartı",
        "Mahalle": "ARMAĞANTAŞI",
        "CiltNo": 6,
        "SıraNo": 140,
        "AileSıraNo": 19,
        "SeriNo": "A00V56637"
    },
    "message": "Aranan Kişiye Ait Bilgiler Getirilmiştir."
}';

// JSON çıktısını ekrana yazdır
header('Content-Type: application/json; charset=utf-8');
echo json_encode(json_decode($jsonData), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

?>
