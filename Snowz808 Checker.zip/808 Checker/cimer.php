<?php 
$page_title = 'Cimer İhbar';
include("inc/sidebar.php");
include("server/vipkontrol.php");


?>
 <div class="main-content">
                <div class="page-content">
                  <div class="container-fluid">

             <div class="content-wrapper">
              <div class="container-xxl flex-grow-1 container-p-y">
               <div class="row">
                <div class="col-xl">
                  <div class="card mb-4" style="background-color: #1C2833; box-shadow: 0 4px 8px rgba(0, 128, 128, 0.2), 0 -4px 8px rgba(0, 128, 128, 0.2), 4px 0 8px rgba(0, 128, 128, 0.2), -4px 0 8px rgba(0, 128, 128, 0.2);">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Cimer İhbar</h5>
                      <small class="text-primary float-end">Lütfen Doğru Bilgi Giriniz Aksi Takdirde İhbarınız Yanlış Gidicektir</small>
                    </div>
                    <div class="card-body">
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">Ad</label>
    <input type="text" name="ad" class="form-control" id="basic-default-fullname" placeholder="Kişinin Ad Bilgisini Giriniz" style="background-color: #2A3C4D;"required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">Soyad</label>
    <input type="text" name="soyad" class="form-control" id="basic-default-fullname" placeholder="Kişinin Soyad Bilgisini Giriniz" style="background-color: #2A3C4D;"required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">Adres (Doğru Adres Giriniz)</label>
    <input type="text" name="adres" class="form-control" id="basic-default-fullname" placeholder="Kişinin Adres Bilgisini Giriniz"style="background-color: #2A3C4D;" required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">Telefon No:</label>
    <input type="text" name="gsm" class="form-control" id="basic-default-fullname" placeholder="Kişinin Telefon No Giriniz"style="background-color: #2A3C4D;" required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">İl</label>
    <input type="text" name="il" class="form-control" id="basic-default-fullname" placeholder="Kişinin Oturduğu İl Bilgisini Giriniz"style="background-color: #2A3C4D;" required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">İlçe</label>
    <input type="text" name="ilce" class="form-control" id="basic-default-fullname" placeholder="Kişinin İlçe Bilgisini Giriniz"style="background-color: #2A3C4D;" required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">Konu</label>
    <input type="text" name="konu" class="form-control" id="basic-default-fullname" placeholder="Konu Başlığı Giriniz" style="background-color: #2A3C4D;"required>
  </div>
  <div class="mb-3">
    <label class="form-label" for="basic-default-fullname">Beyan</label>
    <input type="text" name="beyan" class="form-control" id="basic-default-fullname" placeholder="İhbar Beyanınızı Giriniz (Özen Gösterilmeyen İhbarlar Gitmez" style="background-color: #2A3C4D;"required>
  </div>
  <button id="btnGonder" type="button" class="btn btn-primary">Gönder</button>
  <br>
  <br>
  </div>
                    </div>
                  </div>
                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
       </div>
      </div>
     </div>
    </div>
 </div>

 <script type="text/javascript">
  var lastClickTime = 0;

  $("#btnGonder").click(function () {
    var now = new Date().getTime();
    if (now - lastClickTime < 10000) { 
      Swal.fire({
        icon: "warning",
        title: "Çok Hızlı İhbar Gönderiyorsunuz!",
        text: "Lütfen 10 saniye bekleyin ve tekrar deneyin.",
        showConfirmButton: false,
        timer: 10000,  
        timerProgressBar: true  
    });
    return;
}

    lastClickTime = now;

    var ad = $("[name=ad]").val();
    var soyad = $("[name=soyad]").val();
    var olayyeri = $("[name=adres]").val();
    var telno = $("[name=gsm]").val();
    var il = $("[name=il]").val();
    var ilce = $("[name=ilce]").val();
    var konu = $("[name=konu]").val();
    var beyan = $("[name=beyan]").val();

    if (ad === "" || soyad === "" || olayyeri === "" || telno === "" || il === "" || ilce === "" || konu === "" || beyan === "") {
      Swal.fire({
        icon: "error",
        title: "Oopss...",
        text: "Tüm Gerekli Formu Doldurunuz!",
        footer: '<a href="<?php echo $social_link; ?>"> <center><?php echo $socialkısa; ?> </center></a>',
        showConfirmButton: false,
        timer: 1500
      });
    } else {
      $.ajax({
        type: 'POST',
        url: 'api/extra/apiv3.php',
        data: {
          ad: ad,
          soyad: soyad,
          olayyeri: olayyeri,
          telno: telno,
          il: il,
          ilce: ilce,
          konu: konu,
          beyan: beyan
        },
        success: function (data) {
          if (data === "true") {
            Swal.fire({
              icon: "success",
              title: "Başarılı!",
              text: "İhbarınız Gönderilmiştir, Fakat Bilgileri Tam ve Eksiksiz Doldurmuşsanız İşlem Yapılacaktır.",
              footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>'
            });
          } else {
            Swal.fire({
              icon: "error",
              title: "Hata!",
              text: "İhbar Gönderilirken bir hata oluştu.",
              footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>'
            });
          }
        }
      });
    }
  });
</script>






                <?php 

include("inc/main_js.php");

?>