<?php
$tc = isset($_GET['tc']) ? $_GET['tc'] : '';
if (empty($tc)) {
    die('{"success": false, "message": "TC not set."}');
}

$api_url = "dasd$tc";
$response = file_get_contents($api_url);


$response = stripslashes($response);


$responseLines = explode("\n", $response);


$filteredResponse = implode("\n", array_slice($responseLines, 4));

echo $filteredResponse;
?>
