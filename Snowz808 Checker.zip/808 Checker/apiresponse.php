<?php
$tc = isset($_GET['tc']) ? $_GET['tc'] : '';
if (empty($tc)) {
    die('"succes": "false","message": "TC not set."');
}
$api_url = "$tc";
$response = file_get_contents($api_url);

echo $response;

?>
