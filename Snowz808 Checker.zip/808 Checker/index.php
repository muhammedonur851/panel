<!-- CODED BY BOZO808 -->   <!-- NE ARIYON BURDA EŞŞEK -->
<?php 
$page_title = 'Anasayfa';
include("inc/sidebar.php");

ini_set("display_errors", 0);
error_reporting(0);

$sql = "SELECT * FROM duyuru";
$duyurusentinel = $conn->query($sql);

$sorgu_query = $conn->query("SELECT count FROM sorgu_query");
$count = $sorgu_query->fetch(PDO::FETCH_ASSOC)['count'];

$yetkili_query = $conn->query("SELECT yetkili FROM settings");
$yetkili = $yetkili_query->fetch(PDO::FETCH_ASSOC)['yetkili'];

$yetkiliurl_query = $conn->query("SELECT yetkili_tg FROM settings");
$yetkili_tg = $yetkiliurl_query->fetch(PDO::FETCH_ASSOC)['yetkili_tg'];
?>
<head>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
  <style>
    #example tbody tr:nth-child(even) {
        background-color: #1B242C; 
    }

    #example tbody tr:nth-child(odd) {
        background-color: #232E3A;
    }
</style>
<style>
    body {
        background-image: url('https://static.vecteezy.com/system/resources/previews/013/755/473/non_2x/abstract-dark-background-with-line-grid-gradient-color-applicable-website-banner-poster-corporate-social-media-template-billboard-business-sign-video-film-in-channel-backdrop-techno-background-free-vector.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }

    .card.img-card {
        background-color: #1C2833; 
         box-shadow: 0 0 10px rgba(0, 206, 209, 0.5); 
    }
</style>
 <script>
    document.addEventListener('DOMContentLoaded', function () {
        var cookieName = 'dailyAlertShown';


        var today = new Date();
        var todayString = today.toDateString();


        var alertShownToday = getCookie(cookieName) === todayString;

        
        if (!alertShownToday) {
           
            Swal.fire({
                title: 'Selam!',
                html: 'Telegram kanalımıza gelerek gelişmelerden ve güncel linkten haberdar olabilirsin. <a href="<?php echo $social_link; ?>" target="_blank"><?php echo $socialkısa; ?></a>',
                icon: 'info',
                 footer: '<a href="<?php echo $social_link; ?>"><center>Katılmak için tıkla!</center></a>',
                confirmButtonText: 'Tamam'
            });

           
            setCookie(cookieName, todayString, 1); 
        }
    });

   
    function getCookie(name) {
        var cookies = document.cookie.split('; ');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].split('=');
            if (cookie[0] === name) {
                return cookie[1];
            }
        }
        return null;
    }

    
    function setCookie(name, value, days) {
        var expires = '';
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = '; expires=' + date.toUTCString();
        }
        document.cookie = name + '=' + value + expires + '; path=/';
    }
</script>

	
                           <div class="row">
                           <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Tekrardan hoş geldin.</p>
											<br>
										<h2 class="mb-0 number-font" style="font-size:18px;">
					<style>
  .neon {
    text-shadow: 0 0 10px #00f; 
    animation: neonColorChange 7s infinite; 
  }

  
  @keyframes neonColorChange {
    0% {
      text-shadow: 0 0 10px #00f; 
     
    }
    14% {
      text-shadow: 0 0 10px purple; 
      
    }
    28% {
      text-shadow: 0 0 10px #30d5c8;
      
    }
    42% {
      text-shadow: 0 0 10px yellow; 
     
    }
    57% {
      text-shadow: 0 0 10px green; 
     
    }
    71% {
      text-shadow: 0 0 10px brown; 
     
    85% {
      text-shadow: 0 0 10px pink; 
     
    }
    100% {
      text-shadow: 0 0 10px #00f; 
      
    }
	
  } }
</style>
<a href="profile.js">
<div class="neon">
										<?=$sentinel['key_ad']?></a>
										<?php
if ($sentinel['owner'] == 1) {
    $image = "img/role/owner.png";
} elseif ($sentinel['role'] == 1) {
    $image = "img/role/adminrole.png";
} elseif ($sentinel['role'] == 2) {
    $image = "img/role/premiumrole.png";
} else {
    $image = "img/role/freemium.png"; 
}


echo "<img src='$image' alt='rol_img' width='28' >";
?></div>
										
										
											   </h2>
											</div>
											<div class="ms-auto"> <i class="fa-solid fa-user-secret  text-white fs-30 me-2 mt-2"></i></i> </div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Üyelik Bilgileri :</p>
												<h2 class="mb-0 number-font" style="font-size:15px;">
												
													<br>
													<font size="2px">
													<p>
								<font class="text-primary">Üyelik:</font>
<?php
if ($sentinel['owner'] == 1) {
    echo "OWNER";
} elseif ($sentinel['role'] == 1) {
    echo "Admin";
} elseif ($sentinel['role'] == 2) {
    echo "Premium";
} else {
    echo "Freemium"; 
}
?>
</p>
											

<font class="text-primary">Bitiş:</font>
<?php
date_default_timezone_set('Europe/Istanbul'); 

if ($sentinel['enddate'] != 0) {
    $enddate = strtotime($sentinel['enddate']); 
    $today = time(); 
    $remainingDays = floor(($enddate - $today) / (60 * 60 * 24)); 

    if ($remainingDays > 0) {
        echo $remainingDays . ' gün kaldı';
    } else {
        echo 'Bugün sona eriyor.';
    }
} else {
    echo 'Sınırsız';
}
?>
</p></h2></a></font>	
											</div>
											<div class="ms-auto"> <i class="fa-solid fa-circle-user text-white fs-30 me-2 mt-2"></i> </div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
								<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Toplam Kullanıcı Sayısı : </p>
											<h2 class="mb-0 number-font" style="font-size:15px;">
											<span style='font-size: 16px; color: #3498db; font-weight: bold;'><?php echo $sentinelsayi; ?>  </span>
                                            </h2>
											</div>
											<div class="ms-auto"> <i class="fa solid fa-users text-white fs-30 me-2 mt-2"></i> </div>
										</div>
									</div>
								</div>
						 </div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Banlı Kullanıcı Sayısı : </p>
											<h2 class="mb-0 number-font" style="font-size:15px;">
											<span style='font-size: 16px; color: #3498db; font-weight: bold;'><?php echo $sentinelbanned; ?>         </span>
                                        </h2>

											</h2>
											</div>
											<div class="ms-auto"> <i class="fa-solid fa-ban text-white fs-30 me-2 mt-2"></i> </div>
										</div>
									</div>
								</div>
						</div>
						</div>
						 <div class="row">
                           <div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Toplam Sorgulama Sayısı:</font> </p>
											<h2 class="mb-0 number-font" style="font-size:15px;">
<div id="count-container">
    <span style='font-size: 16px; color: #3498db; font-weight: ;'>
        <?php echo number_format($count, 0, ',', '.'); ?>
    </span>
</div>

<script>
    function refreshCount() {
        $.ajax({
            url: 'server/query.php',
            type: 'GET',
            success: function (data) {
                $('#count-container').html(data);
            }
        });
    }
    setInterval(refreshCount, 3000);
</script>

											</div>
											<div class="ms-auto"> <i class="fa-solid fa-search fa-fade text-white fs-30 me-2 mt-2"></i> </div>
										</div>
									</div>
								</div>
							</div>
                           	<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Yetkili Admin:</p>
											<br>
										<h2 class="mb-0 number-font" style="font-size:18px;">
											
	<style>
    .sentinel {
      text-shadow: 0 0 10px rgba(128, 0, 255, 0.8);
      animation: blink 5s infinite; 
    }

    @keyframes blink {
      0%, 100% {
        opacity: 1;
      }
      50% {
        opacity: 0;
      }
    }
  </style>
<a href="<?php echo $yetkili_tg; ?>">
<div class="sentinel">
									<img src="img/tg.png" width="23">	<?php echo $yetkili; ?></a>
</div>
											</div>
											<div class="ms-auto"> <i class="fa-solid fa-code text-white fs-30 me-2 mt-2"></i></i> </div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Premium Fiyat Listesi:</p>
											<br>
										<h2 class="mb-0 number-font" style="font-size:15px;">
											
	
<a href="vipsatış.js">
Fiyat listesi için tıkla!</a>

											</div>
											<div class="ms-auto"> <i class="fa-solid fa-star text-purple fs-30 me-2 mt-2"></i></i> </div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-6 col-xl-3">
							<div class="card  img-card ">
									<div class="card-body">
										<div class="d-flex">
											<div class="text-white">
											<p class="text-white mb-0">Telegram Adresimiz:</p>
											<br>
										<h2 class="mb-0 number-font" style="font-size:13px;">
											
<a href="<?php echo $social_link; ?>">
									<i class="fa fa-heart text-red" aria-hidden="true"></i>	<?php echo $socialkısa; ?></a>

											</div>
											<div class="ms-auto"> <i class="fa-solid fa-brands fa-telegram text-white fs-30 me-2 mt-2"></i></i> </div>
										</div>
									</div>
								</div>
							</div></div>
				
									<div class="row" >
							<div class="col-md-12 col-lg-12" >
								<div class="card" style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
									<div class="card-header">
							<style>
  .info-icon {
    float: right; 
    
  }
</style>
			<h3 class="card-title"><?php 
$ilk_kelime = strtoupper(trim(explode(' ', $panel_name)[0]));
echo $ilk_kelime; ?> İSPİYONCU&nbsp;&nbsp;<img src="img/ispiyoncu.png" width="30px">    
</h3>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="example" class="table table-striped table-bordered text-nowrap w-100  ">
											
<tbody>
<?php
$sentences = [
    'Yavaş be kardeşim panel görmemiş gibi sorgu atıyosun .',
    'İfşala geçç.',
    'RTE ye sorgu atmayın artık patlayacağız bilader.',
    'Bulabildinmi bari o kızı?',
    'Hadi bulacaksın az kaldı.',
    'Aha sorgu attın amcalar kapında.',
    'Ne güzel sorgu atıyosun öyle.',
    'Enes baturu sorgulayınca eline ne geçti?',
    'Çıkmıyo işte zorlama.',
    'Buldunmu aradığını?',
    'Kayıp anneni buldunmu?',
    'Aradığın kıza yazdınmı bari.',
    'Manitin 2008 li olduğunu öğrenince olur gibi.',
    'Bu sorguladığın 998234. kız mk bizede bırak.',
    'Kardeşim Üvey evlat olduğunu öğrendi, şimdi aile sorguya git ve aileni bul..',
    'Kişisel verilerin korunması kanununu s*kip attı.',
    'Ünlü sorgu sorgu atcağına süt almaya gidip gelmeyen babanı bulsana.',
    'Datalarda veri bırakmadın aq.',
    'Hasmını buldu , vurmaya gidiyor..',
    'Premium al zirvelere çık.',
    'Ünlü sorgu atma ispitlerim bak.',
    'Kendini niye sorguluyosun ki.'
];
$sentences2 = [
    'Geldi yine amk. beyler, herkes sığınaklara koşsun.',
    'Uçmasını bilirsen olursun pilot, istemesini bilirsen iner sana her külot.',
	'Hoş geldin kral. senin için paket oldu diyorlardı.',
    'Hoşgeldin şampiyon. ',
	'Anca işin düşünce gel.',
    'Nerelerdesin reis.',
	'Hoşgeldin dost iyi sorgularr.',
	'HG çerisi şampiyonlar ligi.',
	'Biz çıkalım istersen?',
    'Aramıza katıldığın için teşekkürler.',
    'Hoşgeldin premium sarammı abime?',
    'Adamın geliş efekti var.',
    'Oo hoşgeldin mekan senin reis.',
    'Siteye giren siberci abi sende hoşgeldin.',
    'Oo buralara gelir miydin?',
    'Kim olursan ol yine gel.',
    'Yine tc ni mi unuttun?',
    'Gelmişken premium al bari.',
    'TR nin en hızlı sorgu paneline hoşgeldin. Evet en hızlı.',
    'Hoşgeldin kral işler nasıl?'
];
$sentences3 = [
    'Dost sadece bimde süt markasıymış..',
    'Başka panellerde sorgu atmaya mı gittin yapılırmı bu.',
	'Oh be sunucular rahatladı bu got çıkınca.',
	'Hoşçakal bremın.',
	'Özlettirme kendini.',
	'Zaten piçin tekiydi iyi oldu.',
    'Sonunda çıktı amg 1 saattir sorgu atıyor mitçi sanki pezeveng.',
    'Arkasına bile bakmadı.',
    'Geri gelme.',
    'Sitenin performansı arttı  sen çıkınca geri gelme lütfen.',
    'Alo nereye gidiyosun.'
];

$logsent = $conn->query("SELECT * FROM LOG_sorgu ORDER BY zaman DESC LIMIT 3");
$girislog = $conn->query("SELECT * FROM log ORDER BY login_time DESC LIMIT 1");
$logoutlog = $conn->query("SELECT * FROM logout ORDER BY logout_time DESC LIMIT 1");

$mergedResults = [];

$usedSentences = [];

$mergedResults = [];

while ($angers = $logsent->fetch(PDO::FETCH_ASSOC)) {
    $username = $angers['user'];
    $censoredUsername = substr($username, 0, -3) . '***';

    $randomKey = array_rand($sentences);
    $randomSentence = $sentences[$randomKey];
    unset($sentences[$randomKey]); 
    $usedSentences[] = $randomSentence; 
   $time = new DateTime($angers['zaman']);
    $formattedTime = $time->format('Y-m-d H:i');
    $currentTime = date('Y-m-d H:i');

    $mergedResults[] = [
        'image' => '<img src="img/ispiyoncu1.png" width="25">',
        'icon' => '<i class="fa fa-search" aria-hidden="true"></i>',
        'username' => '<span class="neon">' . $censoredUsername . '</span>',
        'action' => '<font color="#7B68EE"><strong>' . $angers['type'] . '</strong> yaptı. </font>',
        'sentence' => $randomSentence,
        'time' => '<small><font color="gray">' . $formattedTime . '</font></small>',
    ];
}

while ($angers2 = $girislog->fetch(PDO::FETCH_ASSOC)) {
    $username2 = $angers2['key_ad'];
    $censoredgiris = substr($username2, 0, -3) . '***';

    $randomSentence2 = getUnusedSentence($sentences2, $usedSentences);

  $time2 = new DateTime($angers2['login_time']);
    $formattedTime2 = $time2->format('Y-m-d H:i');

    $mergedResults[] = [
        'image' => '<img src="img/ispiyoncu1.png" width="25">',
        'icon' => '<i class="fa fa-sign-in" aria-hidden="true"></i>',
        'username' => '<span class="neon">' . $censoredgiris . '</span>',
        'action' => '<font color="#7B68EE"><strong>giriş yaptı</strong> </font>',
        'sentence' => $randomSentence2,
        'time' => '<small><font color="gray">' . $formattedTime2 . '</font></small>',
    ];
}
while ($angers3 = $logoutlog->fetch(PDO::FETCH_ASSOC)) {
    $username3 = $angers3['user_name'];
    $censoredlogout = substr($username3, 0, -3) . '***';

    $randomSentence3 = getUnusedSentence($sentences3, $usedSentences);


  $time3 = new DateTime($angers3['logout_time']);
    $formattedTime3 = $time3->format('Y-m-d H:i');

    $mergedResults[] = [
        'image' => '<img src="img/ispiyoncu1.png" width="25">',
        'icon' => '<i class="fa fa-sign-out" aria-hidden="true"></i></i>',
        'username' => '<span class="neon">' . $censoredlogout . '</span>',
        'action' => '<font color="#7B68EE"><strong>çıkış yaptı</strong> </font>',
        'sentence' => $randomSentence3,
        'time' => '<small><font color="gray">' . $formattedTime3 . '</font></small>',
    ];
}


usort($mergedResults, function ($a, $b) {
    return strtotime($b['time']) - strtotime($a['time']);
});


shuffle($mergedResults);


foreach ($mergedResults as $result) {
    echo '<tr>';
    echo '<td>' . $result['image'] . '&nbsp;&nbsp;' . $result['icon'] . '&nbsp;&nbsp;' . $result['username'] . '&nbsp;&nbsp;' . $result['action'] . '&nbsp;&nbsp;' . $result['sentence'] . '<br>' . $result['time'] . '</td>';
    echo '</tr>';
}
function getUnusedSentence(&$sourceArray, &$usedArray) {
    $randomKey = array_rand($sourceArray);
    $randomSentence = $sourceArray[$randomKey];
    unset($sourceArray[$randomKey]); 
    $usedArray[] = $randomSentence; 
    return $randomSentence;
}
?>
</tbody>
</table>

									</div>  <i class="fa fa-info-circle info-icon text-purple" aria-hidden="true" onclick="showAlert()"></i>

<script>
    function showAlert() {
        Swal.fire({
            title: 'İspiyoncu Bilgi',
            text: 'İspiyoncu, sitede yapılan son 5 eylemi gösteren bot sistemidir.',
            icon: 'info',
            confirmButtonText: 'Tamam'
        });
    }
</script>
									</div></div>
									</div></div>
						<div class="row">
							<div class="col-md-12 col-lg-12" >
								<div class="card" style="background-color: #1C2833; box-shadow: 0 0 10px rgba(0, 206, 209, 0.5);">
									<div class="card-header">
										<h3 class="card-title">Sistem Duyuruları &nbsp;<img src="img/duyuru.png" width="25px"></h3>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table id="example" class="table table-striped table-bordered text-nowrap w-100">
												<thead>
													<tr>
														<th class="wd-15p">Duyuru Atan</th>
														<th class="wd-15p">Duyuru</th>
														<th class="wd-20p">Duyuru Tarihi</th>
													</tr>
												</thead>
												<tbody>
												<?php while ($angers = $duyurusentinel->fetch(PDO::FETCH_ASSOC)) { ?>
													<tr>
													<td><strong><?=$angers['duyuruatan']?></strong>&nbsp;<img src="img/code.png" width="25"></td>
													<td><?=$angers['atılanduyuru']?></td>
													<td><?=$angers['tarih']?></td>
													</tr>
														
												<?php } ?>
												</tbody>
											</table>
											
											</div>
									</div></div>
									</div></div>
									</div>
									</div></div>
									</div></div>
									</div></div>
									</div></div>
									</div></div>
									</div></div>
									</div>
								</div>
								</div>
							</div>
						</div>
						</div>
       <?php
       include("inc/main_js.php");
	   ?>