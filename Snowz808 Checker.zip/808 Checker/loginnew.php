<?php
require 'server/connect.php';

$connection = new mysqli($servername, $username, $password, $db);

// Bağlantı hatası kontrolü
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$panel_query = $conn->query("SELECT panel_name FROM settings");
$panel_name = $panel_query->fetch(PDO::FETCH_ASSOC)['panel_name'];

$social_query = $conn->query("SELECT social_link FROM settings");
$social_link = $social_query->fetch(PDO::FETCH_ASSOC)['social_link'];

$social_kısa = $conn->query("SELECT social_kısa FROM settings");
$socialkısa = $social_kısa->fetch(PDO::FETCH_ASSOC)['social_kısa'];
?>
<!DOCTYPE html>
<html>
  <head>
<meta name="robots" content="noindex">
    <meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>---</title>
   
    <!--Google Fonts and Icons-->
    <link
      href="https://fonts.googleapis.com/icon?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Round|Material+Icons+Sharp|Material+Icons+Two+Tone"
      rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofGJhuvfNqbr4M2T02//FV/W9E08d6sN5" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200;300;400;500;600;700;800&family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
      rel="stylesheet"/>
     
        <!-- FAVICON -->
        <link rel="shortcut icon" type="image/x-icon" href="img/logo.png" />
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
 <!-- Google Recaptcha -->
 
 <script src="https://www.google.com/recaptcha/api.js" async defer></script>
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@5/dark.css" />

  </head>
  <body>
    <style>
    body {
    width: 100%;
    height: 100vh;
    margin: 0;
    padding: 0;
}

.center {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: url(../images/login-back.png);
    background-size: cover;
}

form {
    width: 380px;
    height: 600px;
    box-sizing: border-box;
    border-radius: 5mm;
    padding: 40px 30px;
    backdrop-filter: blur(5px) saturate(160%);
    -webkit-backdrop-filter: blur(5px) saturate(160%);
    background: #1C2833;
    border: 0.5mm solid rgba(0, 0, 0, 0.65);
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    box-shadow: 0 0 20px 5px rgba(0, 128, 128, 0.5); 
}




.title {
    width: 100%;
    font-family: poppins;
    font-size: 20px;
    text-align: center;
    margin-bottom: 15px;
    color: white;
    text-shadow: 0.5px 0.5px 1px #00FFFF; /* Adjusted shadow size */
    -webkit-text-stroke: 1px black;
    text-stroke: 1px black;
}


.inputs {
    width: 100%;
    height: fit-content;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}

.inputf {
    width: 100%;
    height: fit-content;
    box-sizing: border-box;
    margin: 15px 0;
    position: relative;
}

.input {
    width: 100%;
    height: 45px;
    box-sizing: border-box;
    border: none;
    border-bottom: 0.55mm solid rgb(255, 255, 255);
    background: none;
    padding: 0 15px;
    font-family: poppins;
    font-size: 15px;
    color: white;
    outline: none;
}

.input::placeholder {
    color: rgb(241, 232, 232);
}

.label {
    position: absolute;
    top: 0;
    left: 0;
    color: white;
    font-size: 13px;
    font-weight: 500;
    font-family: poppins;
    opacity: 0;
    z-index: -1;
    transition: 0.25s ease-out;
}

.input:focus + .label {
    top: -20px;
    opacity: 1;
    z-index: 1;
}

.input:focus::placeholder {
    opacity: 0;
}

.input:not(:placeholder-shown) + .label {
    top: -20px;
    opacity: 1;
    z-index: 1;
}

.icon {
    color: white;
    position: absolute;
    right: 0px;
    top: 50%;
    transform: translate(0, -50%);
    font-size: 18px;
}

.links {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 12px;
    font-family: poppins;
    margin-bottom: 50px;
    color: white;
}

.links label {
    display: flex;
    align-items: center;
    justify-content: center;
}

.links a {
    font-weight: 600;
    color: white;
}

.btn {
    width: 100%;
    height: 50px; 
    background-color: #2B547E; 
    color: #ffffff; 
    outline: none;
    border: none;
    cursor: pointer;
    border-radius: 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 15px; 
    transition: background-color 0.3s ease; 
}

.btn:hover {
    background-color: #2980b9;
}

.btn span {
    font-family: 'Poppins', sans-serif;
    font-size: 18px;
    font-weight: 600;
}

.btn:focus {
    box-shadow: 0 0 5px rgba(155, 89, 182, 0.8);
}
.btn:active {
    background-color: #8e44ad;
}


.text {
    width: 100%;
    font-family: poppins;
    font-size: 10px;
    text-align: center;
    color: rgb(240, 240, 240);
}

.text a {
    color: white;
    font-weight: 600;
}

.dots {
    width: fit-content;
    height: fit-content;
    display: flex;
    align-items: center;
    justify-content: center;
}

.dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.1);
    margin: 1px;
    animation: load 0.5s ease-out infinite alternate var(--delay);
}

@keyframes load {
    0% {
      background: rgb(0, 0, 0);
    }
    50%,
    100% {
      background: rgba(0, 0, 0, 0.1);
    }
}

.btn .dots {
    display: none;
}

.btn span {
    display: block;
}

.btn.active .dots {
    display: flex;
}

.btn.active span {
    display: none;
}

.input.active {
    animation: shake 0.25s ease-in-out 3;
}
 body {
        background-image: url('https://static.vecteezy.com/system/resources/previews/013/755/473/non_2x/abstract-dark-background-with-line-grid-gradient-color-applicable-website-banner-poster-corporate-social-media-template-billboard-business-sign-video-film-in-channel-backdrop-techno-background-free-vector.jpg');
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
       
    }

    .card.img-card {
        background-color: #1C2833; 
         box-shadow: 0 0 10px rgba(0, 206, 209, 0.5); 
    }

@keyframes shake {
    0% {
      margin-left: 0px;
    }
    25% {
      margin-left: 5px;
    }
    75% {
      margin-left: -5px;
    }
    100% {
      margin-left: 0px;
    }
}
 
        a {
            color: white;
        }

       
        a:visited {
            color: white;
        }

        
        a:hover {
            color: blue;
        }

        
        a:active {
            color: purple;
        }

</style>


     <div class="center">
    <form>
      <center>
									<img src="img/logo.png" style="width: 150px;">
							
                                     </center>
      <div class="title"><strong><?php echo $panel_name ?></strong></div>
      <div class="inputs">
        <div class="inputf">
          <input type="email" name="user" class="input" placeholder="Kullanıcı adı" style="background-color: #2A3C4D;"/>
          <span class="label">Kullanıcı adı</span>
          <span class="material-icons icon">person</span>
        </div>
        <div class="inputf">
          <input type="password" name="pass" class="input" placeholder="Şifre" style="background-color: #2A3C4D;"/>
          <span class="label">Şifre</span>
          <span class="material-icons icon">lock</span>
        </div>
      </div>
                            <style>
                                    .g-recaptcha {
    transform:scale(0.90);
    transform-origin:1 10;
}
</style>
      <div class="g-recaptcha" data-sitekey="6LcputcnAAAAAFUkKmFThbMUEfzOkhC2kOAamAA7"></div>
<br>
      <button type="button" id="btnSentinel" class="btn">
        <span><img src="https://r.resimlink.com/r5a9AUql7Ym.png" width="15px">&nbsp;&nbsp;Giriş Yap</span>
        <div class="dots">
          <div class="dot" style="--delay: 0s"></div>
          <div class="dot" style="--delay: 0.25s"></div>
          <div class="dot" style="--delay: 0.5s"></div>
        </div>
      </button>

      <div class="text">
       Telegram kanalımıza gelmeyi unutmayın. <a href="<?php echo $social_link ?>"><?php echo $socialkısa ?></a>
      </div>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      
      <script type="text/javascript">
     $(document).ready(function() {
        $('#btnSentinel').click(function() {
        var keyad = $("[name=user]").val();
        var key = $("[name=pass]").val();
        var recaptchaResponse = grecaptcha.getResponse(); 

        if (key == "" && keyad == "") {

            Swal.fire ({
                icon : "error",
                title : "Oopss...",
                html: '<font face="Arial" color="white">Kullanıcı Adı Ve Şifre Boş Bırakılamaz!</font>',
footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                showConfirmButton: false,
                timer: 1500
            })
            
        } else if (recaptchaResponse == "") {
            Swal.fire ({
                icon : "error",
                title : "Lütfen Doğrulamayı Yapın",
                 html: '<font face="Arial" color="white">Ben robot değilim doğrulamasını yapın!</font>',
footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                showConfirmButton: false,
                timer: 1500
            })
        } else {
            $.ajax({
                type : "POST",
                url : "api/login/api.php",
                data : {
                    keyad: keyad,
                    key: key,
                    "g-recaptcha-response": recaptchaResponse 
                },
                success : function(data){
                    var json = data;
                    if (json.login === "success") {
                        Swal.fire({
                            position: 'center',
                            icon : "success",
                            title: '<font face="Arial" color="white"><?php echo $panel_name ?></font>',
                            html: '<font face="Arial" color="white">Giriş Başarılı Yönlendiriliyorsunuz...</font>',
footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                            showConfirmButton: false,
                            timer: 1000
                        })
                        window.setTimeout(function() {
                            window.location.href = '/check.js';
                        }, 1000);
                    }
                    if (json.error === "banned") {

                        Swal.fire({
                            icon : "error",
                            title : '<font face="Arial" color="white">Oopss...</font>',
                            html: '<font face="Arial" color="white">Banlandınız! Banlanma Sebebi : Birden fazla ip den giriş. Yönetici ile iletişime geçiniz.</font>',
footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                            confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.error === "endkey") {

                        Swal.fire({
                            icon : "error",
                             title: '<font face="Arial" color="white">Oopss...</font>',
                            html: '<font face="Arial" color="white">Üyeliğinizin Süresi Bitmiştir Tekrar Satın Almak İçin Lütfen Yöneticiye Başvurunuz !</font>',
footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                            confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.login === "error") {

                        Swal.fire({
                            icon : "error",
                           title: '<font face="Arial" color="white">Oopss...</font>',
                           html: '<font face="Arial" color="white">Kullanıcı Bulunamadı Lütfen Kullanıcı Adını ve Şifreni Kontrol Et...</font>',
                            footer: '<center><a href="<?php echo $social_link; ?>">Şifreni mi Unuttun ?</a></center>',
                          footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',  confirmButtonText: 'Tamam'
                        })

                    }
                    if (json.error === "recaptcha") { 
                        Swal.fire({
                            icon : "error",
                            html: '<font face="Arial" color="white">Robot Doğrulaması Başarısız</font>',
                            text : "Sayfayı yenileyip robot değilim doğrulamasını tekrar yapın.",
footer: '<a href="<?php echo $social_link; ?>"><center><?php echo $socialkısa; ?></center></a>',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                }
            });
        }
    });
       });
</script>

    
  </body>
</html>
<script>
    // Sağ tıklama olayını yakalama
    window.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        alert("klavyeni kullan ");
    });
	
</script>
<script>
    // Klavyeden kısayol tuşlarını yakalama
    window.addEventListener('keydown', function(e) {
        // Klavyeden F12 tuşuna basılırsa
        if (e.keyCode == 123) {
            e.preventDefault(); // Tuşun varsayılan işlevini engelle
        }
    });
</script>
<script type="text/javascript">
        document.addEventListener('contextmenu', event => event.preventDefault());
        document.onkeydown = function(e) {
    if (e.keyCode == 123) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
    if (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
        alert("HOPPP KÖYÜNE DÖN AMINA KODUM.");
        return false;
    }
}
</script>
<script id="Protection">
    // Sağ tıklama engelle
    document.addEventListener('contextmenu', event => event.preventDefault());

    document.onkeydown = function(e) {

        // F12 Engelle
        if (e.keyCode == 123) {
            return false;
        }

        // CTRL+I Engelle
        if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
            return false;
        }

        // CTRL+J Engelle
        if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
            return false;
        }

        // CTRL+S Engelle
        if (e.ctrlKey && e.keyCode == 83) {
            return false;
        }

        // CTRL+U Engelle
        if (e.ctrlKey && e.keyCode == 85) {
            return false;
        }
    }
</script>
